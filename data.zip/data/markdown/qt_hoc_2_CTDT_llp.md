1

<!-- page: 1 -->

# QUY TRÌNH

# HỌC CÙNG LÚC 2 CHƯƠNG TRÌNH ĐÀO TẠO

## I. QUY TRÌNH CÔNG TÁC

### 1. Cơ sở thực hiện

**Mục đích**

Tạo điều kiện cho sinh viên học chương trình đào tạo thứ 2.

**Đối tượng và điều kiện**

Sinh viên chính quy đang học tại Trường Đại học Cần Thơ được chấp thuận cho học chương trình đào tạo thứ 2 khi đạt các điều kiện sau:

- Đã hoàn thành ít nhất học kỳ I của năm thứ nhất.
- Điểm trung bình chung tích lũy đạt từ 2,00 trở lên.
- Đơn vị quản lý chương trình thứ hai còn khả năng tiếp nhận thêm sinh viên.

**Văn bản quy định**

- “Quy chế đào tạo đại học và cao đẳng hệ chính quy theo hệ thống tín chỉ” ban hành kèm theo Quyết định số 43/2007/QĐ-BGDĐT, ngày 15 tháng 8 năm 2007 của Bộ trưởng Bộ Giáo dục và Đào tạo;
- Thông tư số 57/2012/TT-BGDĐT, ngày 27 tháng 12 năm 2012 về việc Sửa đổi, bổ sung một số điều của Quy chế đào tạo đại học và cao đẳng hệ chính quy theo hệ thống tín chỉ ban hành kèm theo Quyết định số 43/2007/QĐ-BGDĐT ngày 15 tháng 8 năm 2007 của Bộ trưởng Bộ Giáo dục và Đào tạo;
- Quy định về công tác học vụ dành cho sinh viên bậc đại học và cao đẳng hệ chính quy hiện hành.

**Giải thích từ ngữ, từ viết tắt:**

- CTĐT : chương trình đào tạo.
- P.ĐT : Phòng Đào tạo.
- QĐ : Quyết định.
- SV : sinh viên.

### 2. Nội dung quy trình

- Trường Thông báo kế hoạch đăng ký học cùng lúc 2 CTĐT: tháng 12 hàng năm;
- SV Đăng ký: tuần đầu của tháng 01 và tháng 8 hàng năm;
- Phòng Đào tạo nhập và rà soát dữ liệu SV đăng ký, chuyển về đơn vị đào tạo;
- Đơn vị đào tạo xét duyệt danh sách và gửi về P. ĐT;
- Phòng Đào tạo trình Hiệu trưởng ký Quyết định cho phép SV học cùng lúc 2 CTĐT và thông báo kết quả;
- SV đăng ký chuyển đổi thông tin sang CTĐT thứ 2: Khi đăng ký xét tốt nghiệp CTĐT thứ 1, SV chọn học tiếp hoặc chọn không trên hệ thống khi đăng ký xét tốt nghiệp CTĐT thứ 1;
- Phòng Đào tạo sẽ chuyển danh sách đăng ký học tiếp CTĐT thứ 2 đến Phòng Công tác SV, Phòng Công tác SV sẽ chuyển đổi thông tin SV sang CTĐT thứ 2.

---

2

<!-- page: 2 -->

## II. LƯU ĐỒ

| Quy trình học cùng lúc 2 chương trình đào tạo / TT | Quy trình học cùng lúc 2 chương trình đào tạo / Lưu đồ | Quy trình học cùng lúc 2 chương trình đào tạo / Nội dung công việc | Quy trình học cùng lúc 2 chương trình đào tạo / Người thực hiện | Quy trình học cùng lúc 2 chương trình đào tạo / Thời gian thực hiện | Quy trình học cùng lúc 2 chương trình đào tạo / Ghi chú |
| ------------------------------------------------------------ | ------------------------------------------------------------------- | ------------------------------------------------------------------------------- | ----------------------------------------------------------------------------- | -------------------------------------------------------------------------------- | ------------------------------------------------------------------ |
| 1                                                            | Kế hoạch đăng kí                                               | Thông báo                                                                     | P.ĐT                                                                         | Tháng 12                                                                        |                                                                    |
| 2                                                            | Sinh viên đăng ký                                               | SV Đăng ký                                                                   | SVP.ĐT                                                                       | Tuần đầu tháng 01 và 8 hàng năm                                           | *Mẫu*                                                           |
| 3                                                            | Xử lý                                                             | - Lập danh sách- Kiểm tra điều kiện gửi đơn vị                        | P.ĐT                                                                         | 6 ngày                                                                          |                                                                    |
| 4                                                            | Duyệt cấp đơn vị                                               | - Kiểm tra- Ký duyệt danh sách đăng ký                                   | Đơn vị đào tạo                                                          | 6 ngày                                                                          |                                                                    |
| 5                                                            | Thông báo kết quả                                               | - Ra QĐ học CTĐT thứ 2- Thông báo kết quả                               | Hiệu trưởngP.ĐT                                                           | 6 ngày                                                                          |                                                                    |
| 6                                                            | SV đăng ký học tập                                             | SV lập kế hoạch học tập, đăng ký theo quy định                        | SV                                                                            |                                                                                  |                                                                    |
| 7                                                            | SV đăng ký học tiếp                                            | SV chọn học tiếp CTĐT 2 trên hệ thống quản lý                          | SV                                                                            | Khi đăng ký xét tốt nghiệp CTĐT 1                                         |                                                                    |
| 8                                                            | Chuyển thông tin SV                                               | Chuyển thông tin sang CTĐT 2                                                 | P.ĐTP. CTSV                                                                  | 2 tuần                                                                          |                                                                    |

---

3

<!-- page: 3 -->

**CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**
**<u>Độc lập – Tự do – Hạnh phúc</u>**

# ĐƠN ĐĂNG KÝ HỌC CÙNG LÚC HAI CHƯƠNG TRÌNH ĐÀO TẠO

**Kính gửi:**

- Ban Giám hiệu;
- Lãnh đạo đơn vị quản lý chương trình thứ hai;
- Phòng Đào tạo;
  Trường Đại học Cần Thơ

* Tôi tên:      Mã số sinh viên:
* Ngành 1:      Mã lớp:
* Ngày sinh:     /    /     Nơi sinh:
* E-mail:      Điện thoại:
* Điểm trung bình chung tích lũy:

Kính đề nghị nhà Trường cho phép tôi được học cùng lúc hai chương trình đào tạo, cụ thể như sau:

* - Tên ngành 2 đăng ký:
* - Tên chuyên ngành (nếu có):
* - Ký hiệu (ghi theo Danh mục CTĐT):
* - Đăng ký theo học chương trình đào tạo khóa:

Trân trọng kính chào./.

Cần Thơ, ngày      tháng      năm 20

**Người viết đơn**
*(ký và ghi rõ họ tên)*

**Lưu ý:**

- *Đơn này chỉ dành cho sinh viên chính quy đang theo học tại Trường;*
- *Thời gian học chương trình 2 được tính trong tổng thời gian học tối đa của chương trình thứ 1;*
- *Nếu sinh viên trước đây đã được cho phép học CTĐT thứ 2, đến nay muốn thay đổi để đăng ký lại ngành khác thì SV nộp đính kèm đơn xin thôi học CTĐT thứ 2 trước đây.*
