# Bản lưu inactive — Quyết định 05/2022/QĐ-TTg về tín dụng học sinh, sinh viên — Năm 2022

*Hà Nội, ngày 23 tháng 3 năm 2022*


## Sửa đổi, bổ sung một số điều của Quyết định số 157/2007/QĐ-TTg ngày 27 tháng 9 năm 2007 của Thủ tướng Chính phủ về tín dụng đối với học sinh, sinh viên

*Căn cứ Luật Tổ chức Chính phủ ngày 19 tháng 6 năm 2015;*

*Căn cứ Luật Tổ chức chính quyền địa phương ngày 19 tháng 6 năm 2015;*

*Căn cứ Luật sửa đổi, bổ sung một số điều của Luật Tổ chức Chính phủ và Luật Tổ chức chính quyền địa phương ngày 22 tháng 11 năm 2019;*

*Căn cứ Luật Các tổ chức tín dụng ngày 16 tháng 6 năm 2010; Luật sửa đổi, bổ sung một số điều của Luật Các tổ chức tín dụng ngày 20 tháng 11 năm 2017;*

*Căn cứ Nghị định số 78/2002/NĐ-CP ngày 04 tháng 10 năm 2002 của Chính phủ về tín dụng đối với người nghèo và các đối tượng chính sách khác;*

*Căn cứ Nghị định số 07/2021/NĐ-CP ngày 27 tháng 01 năm 2021 của Chính phủ về chuẩn nghèo đa chiều giai đoạn 2021 - 2025;*

*Theo đề nghị của Bộ trưởng Bộ Tài chính tại Tờ trình số 11/TTr-BTC ngày 13 tháng 01 năm 2022 và văn bản số 1920/BTC-TCNH ngày 28 tháng 02 năm 2022;*

*Thủ tướng Chính phủ ban hành Quyết định sửa đổi, bổ sung một số điều của Quyết định số 157/2007/QĐ-TTg ngày 27 tháng 9 năm 2007 của Thủ tướng Chính phủ về tín dụng đối với học sinh, sinh viên.*

## Điều 1. Sửa đổi, bổ sung một số điều của Quyết định số 157/2007/QĐ-TTg ngày 27 tháng 9 năm 2007 của Thủ tướng Chính phủ về tín dụng đối với học sinh, sinh viên như sau:

### 1. Sửa đổi khoản 2 Điều 2:
“2. Học sinh, sinh viên là thành viên của hộ gia đình thuộc một trong các đối tượng:

a) Hộ nghèo theo chuẩn quy định của pháp luật.

b) Hộ cận nghèo theo chuẩn quy định của pháp luật.

c) Hộ có mức sống trung bình theo chuẩn quy định của pháp luật.”

### 2. Sửa đổi khoản 1 Điều 5:

“1. Mức vay vốn tối đa là 4.000.000 đồng/tháng/học sinh, sinh viên.”

### 3. Sửa đổi khoản 2 Điều 9:

“Kể từ ngày học sinh, sinh viên kết thúc khóa học 12 tháng theo quy định, đối tượng được vay vốn phải trả nợ gốc và lãi tiền vay lần đầu tiên. Đối tượng được vay vốn có thể trả nợ trước hạn mà không chịu lãi phạt trả nợ trước hạn.”

### 4. Bổ sung điểm c vào khoản 2 Điều 13:

“Bộ Lao động - Thương binh và Xã hội hướng dẫn thực hiện Quyết định theo quy định của pháp luật.”

## Điều 2. Bãi bỏ các quy định

### 1. Điều 10 Quyết định số 157/2007/QĐ-TTg ngày 27 tháng 9 năm 2007 của Thủ tướng Chính phủ về tín dụng đối với học sinh, sinh viên.

### 2. Quyết định số 1656/QĐ-TTg ngày 19 tháng 11 năm 2019 của Thủ tướng Chính phủ về việc điều chỉnh mức cho vay đối với học sinh, sinh viên.

## Điều 3. Điều khoản thi hành

### 1. Quyết định này có hiệu lực từ ngày 19 tháng 5 năm 2022.

### 2. Đối với các hợp đồng vay vốn tín dụng đã ký hợp đồng trước ngày Quyết định này có hiệu lực: Ngân hàng Chính sách xã hội, khách hàng và các bên liên quan tiếp tục được thực hiện theo các cam kết, các quyền hạn và trách nhiệm ghi trong hợp đồng đã ký. Mức vay vốn tối đa tại khoản 2 Điều 1 của Quyết định này được áp dụng đối với các khoản giải ngân mới kể từ ngày Quyết định có hiệu lực thi hành.
### 3. Các Bộ trưởng, Thủ trưởng cơ quan ngang bộ, Thủ trưởng cơ quan thuộc Chính phủ, Chủ tịch Ủy ban nhân dân tỉnh, thành phố trực thuộc trung ương, Chủ tịch Hội đồng quản trị và Tổng giám đốc Ngân hàng Chính sách xã hội chịu trách nhiệm thi hành Quyết định này.
