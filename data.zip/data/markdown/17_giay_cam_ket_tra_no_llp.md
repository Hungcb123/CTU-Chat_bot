1

<!-- page: 1 -->

**CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**
**Độc lập - Tự do - Hạnh phúc**

# GIẤY CAM KẾT TRẢ NỢ

**Kính gửi : Trường (cơ sở đào tạo)**

Họ và tên học sinh, sinh viên:
Ngày sinh:     /    /
Giới tính: Nam □    Nữ □
CMND số:                ngày cấp     /    /     Nơi cấp:
Lớp:            Khoa            Số thẻ HSSV
Khóa     Loại hình đào tạo:
Hệ đào tạo (Đại học, cao đẳng, ……...…..):
Ngày nhập học:     /    /     Ngày ra trường (dự kiến):     /    /
Mã trường theo học (mã quy ước trong quy chế tuyển sinh):
Trong thời gian theo học tôi được (gia đình) vay vốn Ngân hàng để chi phí cho học tập tại trường theo Khế ước (Hợp đồng) vay vốn do                                cư trú tại thôn (ấp, làng..)                                 xã (phường)                                    huyện (thị xã)                             tỉnh (thành phố)                            , đứng tên vay vốn tại Ngân hàng Chính sách xã hội                    cho vay tổng số tiền là:      đồng (bằng chữ                                                    )

**Tôi xin cam kết trách nhiệm với nhà trường và gia đình :**

- Trong thời gian 60 ngày, kể từ ngày được ký hợp đồng lao động, tôi sẽ thông báo địa chỉ đơn vị công tác cho nhà trường và gia đình, đồng thời tôi có trách nhiệm cùng gia đình trả nợ số tiền vay Ngân hàng để cho tôi đi học.
- Nếu không thực hiện cam kết trên, thì Ngân hàng, gia đình và Nhà trường có quyền làm việc với người có trách nhiệm tại đơn vị tôi đang công tác để trừ thu nhập trả nợ cho ngân hàng nơi gia đình (học sinh, sinh viên) đã vay vốn.

              , ngày      tháng      năm 200

**NGƯỜI CAM KẾT**
*(Ký, ghi rõ họ tên)*
