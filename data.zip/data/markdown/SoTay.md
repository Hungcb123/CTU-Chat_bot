1

<!-- page: 1 -->

BỘ GIÁO DỤC VÀ ĐÀO TẠO **CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**
**TRƯỜNG ĐẠI HỌC CẦN THƠ** **Độc lập – Tự do – Hạnh phúc**

Số: 4638 /QĐ-ĐHCT _Cần Thơ, ngày 26 tháng 9 năm 2025_

# QUYẾT ĐỊNH

## Ban hành Sổ tay sinh viên Trường Đại học Cần Thơ

# HIỆU TRƯỞNG TRƯỜNG ĐẠI HỌC CẦN THƠ

Căn cứ Luật Giáo dục đại học ngày 18 tháng 6 năm 2012 và Luật sửa đổi, bổ sung một số điều của Luật Giáo dục đại học ngày 19 tháng 11 năm 2018;

Căn cứ Quyết định số 6175/QĐ-ĐHCT, ngày 10/12/2024 của Hiệu trưởng Trường Đại học Cần Thơ ban hành Quy chế đánh giá kết quả rèn luyện dành cho sinh viên bậc đại học hệ chính quy;

Căn cứ Quy định về công tác học vụ dành cho sinh viên bậc đại học hệ chính quy, ban hành kèm theo Quyết định số 3266/QĐ-ĐHCT, ngày 15/8/2024 của Hiệu trưởng Trường Đại học Cần Thơ;

Xét đề nghị của ông Trưởng phòng Công tác Sinh viên.

# QUYẾT ĐỊNH:

#### Điều 1. Ban hành kèm theo Quyết định này “Sổ tay sinh viên Trường Đại học Cần Thơ”.

#### Điều 2. Quyết định này có hiệu lực kể từ ngày ký và thay thế Quyết định số 937/QĐ-ĐHCT, ngày 14/5/2020 của Hiệu trưởng Trường Đại học Cần Thơ.

#### Điều 3. Chánh văn Phòng Trường Đại học Cần Thơ, các Trưởng phòng: Công tác Sinh viên, Đào tạo; Thủ trưởng các đơn vị có liên quan và sinh viên có trách nhiệm thi hành quyết định này./.

**Nơi nhận:**

- Như Điều 3;
- Lưu: VT, CTSV.

**HIỆU TRƯỞNG**

Signature and stamp of Hiệu trưởng Trường Đại học Cần Thơ, Trần Trung Tính

**Trần Trung Tính**

---

2

<!-- page: 2 -->

BỘ GIÁO DỤC VÀ ĐÀO TẠO
**TRƯỜNG ĐẠI HỌC CẦN THƠ**

**CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**
**Độc lập - Tự do - Hạnh phúc**

# SỔ TAY SINH VIÊN

_(Kèm theo Quyết định số: /QĐ-ĐHCT, ngày tháng 9 năm 2025 của Hiệu trưởng Trường Đại học Cần Thơ)_

# GIỚI THIỆU VỀ ĐẠI HỌC CẦN THƠ

Đại học Cần Thơ (ĐHCT), cơ sở đào tạo đại học và sau đại học trọng điểm của Nhà nước ở ĐBSCL, là trung tâm văn hóa - khoa học kỹ thuật của vùng. Trường đã không ngừng hoàn thiện và phát triển. Hiện nay Trường đào tạo từ trình độ đại học (trong đó có chương trình đào tạo tiên tiến, chương trình đào tạo chất lượng cao), thạc sĩ và tiến sĩ.

Nhiệm vụ chính của Trường là đào tạo, nghiên cứu khoa học (NCKH), chuyển giao công nghệ phục vụ phát triển kinh tế - xã hội trong vùng. Song song với công tác đào tạo, ĐHCT đã tham gia tích cực các chương trình NCKH, ứng dụng những thành tựu khoa học kỹ thuật nhằm giải quyết các vấn đề về khoa học, công nghệ, kinh tế, văn hoá và xã hội của vùng. Từ những kết quả của các công trình NCKH và hợp tác quốc tế, Trường đã tạo ra nhiều sản phẩm, qui trình công nghệ phục vụ sản xuất, đời sống và xuất khẩu, tạo được uy tín trên thị trường trong nước và quốc tế.

Tầm nhìn (Vision)

Đại học Cần Thơ là nơi hội tụ, giao thoa và sản sinh tri thức - văn hóa - khoa học - công nghệ, tác động vào phát triển xã hội bền vững.

Sứ mệnh (Mission)

Đại học Cần Thơ là nơi đào tạo con người tinh hoa trong môi trường học tập khai phóng, nghiên cứu khoa học và chuyển giao công nghệ đương đại, phát triển xã hội thịnh vượng.

Giá trị cốt lõi (Core Values)

Đồng thuận - Tận tâm - Chuẩn mực - Sáng tạo.
Consensus - Devotion - Quality - Innovation.

Chính sách đảm bảo chất lượng (Quality Policy Statement)

Nhận thức tầm quan trọng của nhu cầu nguồn nhân lực chất lượng cao và sự cạnh tranh mạnh mẽ về chất lượng đào tạo trong bối cảnh phát triển mới của quốc gia và quốc tế, Trường ĐHCT cam kết đảm bảo chất lượng thông qua thường xuyên đổi mới và hội nhập trong đào tạo; sáng tạo và năng động trong nghiên cứu và chuyển giao công nghệ; gắn lý thuyết với thực hành để trang bị đầy đủ kiến thức và kỹ năng cho người học khi ra trường đạt hiệu quả cao trong công việc, có năng lực lãnh đạo và thích ứng với thay đổi.

Trường cam kết xây dựng hệ thống quản trị hiệu quả, chuyên nghiệp, trách nhiệm, sáng tạo và luôn đổi mới. Hoạt động quản lý của Trường sẽ được quy trình hóa, tin học hóa, áp dụng các phương thức quản trị cập nhật và được giám sát, đánh giá thường xuyên.

---

3

<!-- page: 3 -->

# SINH VIÊN CẦN BIẾT

### A. Công tác hỗ trợ sinh viên (SV)

### 1. Phòng Công tác Sinh viên (CTSV) - https://dsa.ctu.edu.vn. QR code

- Chế độ miễn, giảm học phí;
- Hỗ trợ chi phí học tập;
- Trợ cấp xã hội;
- Học bổng khuyến khích;
- Trợ cấp đột xuất;
- Vay vốn đi học:
  - Vay vốn theo Quyết định 157;
  - Vay vốn theo Quyết định 29;
  - Vay vốn ở Ngân hàng VietinBank.

- Tư vấn sức khỏe: Điện thoại: (0292) 3 872 115;
- Khen thưởng (năm học, tốt nghiệp, khác);
- Kỷ luật cấp trường;
- Trợ cấp đột xuất;
- Tổ chức Lễ phát Bằng tốt nghiệp;
- Tổ chức các hội diễn văn nghệ truyền thống của Trường;
- Quản lý đội văn nghệ Trường;
- Công tác Bảo vệ - Giữ gìn An ninh trật tự:
  - Tổ bảo vệ: (0292) 3 781 781;
  - Chốt gác cổng A: (0292) 3 872 111;
  - Chốt gác cổng B: (0292) 3 872 112;
  - Chốt gác cổng C: (0292) 3 872 113.

- Quản lý SV ký túc xá (KTX): Nhận đăng ký; Xếp chỗ; Ghi, thu phí điện nước hàng tháng của SV KTX; Giám sát SV thực hiện nội quy, quy định, giữ gìn vệ sinh môi trường, an ninh trật tự trong khu vực KTX;
- Hoạt động tự quản, phong trào của SV nội trú, ngoại trú; Xét khen thưởng cho SV có thành tích trong hoạt động tự quản.
- Công tác Bảo hiểm tai nạn, bảo hiểm y tế (_bắt buộc_)
  - Tra cứu thời hạn BHYT

- Công tác đánh giá điểm rèn luyện (xem Phần C);
- Hỗ trợ đăng ký trực tuyến:
  - Xác nhận là SV vay vốn theo Quyết định 157;
  - Xác nhận là SV vay vốn theo Quyết định 29;
  - Tạm hoãn nghĩa vụ quân sự;
  - Điều chỉnh thông tin cá nhân;
  - Đăng ký nộp bản sao thẻ BHYT do địa phương cấp;
  - Những câu hỏi thường gặp.

---

4

<!-- page: 4 -->

### 2. Hoạt động hỗ trợ đặc thù dành cho SV Trường ĐHCT

QR Code

#### 2.1 Học bổng tài trợ

- Xem thông tin trên website của đơn vị quản lý ngành [https://www.ctu.edu.vn/don-vi-truc-thuoc.html](https://www.ctu.edu.vn/don-vi-truc-thuoc.html)
- Website Phòng CTSV.

#### 2.2 Giao lưu học tập ngắn hạn ở nước ngoài

- Xem thông tin trên website của đơn vị quản lý ngành [https://www.ctu.edu.vn/don-vi-truc-thuoc.html](https://www.ctu.edu.vn/don-vi-truc-thuoc.html)
- Website Phòng CTSV; Phòng hợp tác Quốc tế.

#### 2.3 Các Câu lạc bộ học thuật, đội nhóm sở thích tự nguyện

- Xem thông tin trên website của đơn vị quản lý ngành [https://www.ctu.edu.vn/don-vi-truc-thuoc.html](https://www.ctu.edu.vn/don-vi-truc-thuoc.html)
- Website Đoàn - Hội sinh viên

### 3. Cố vấn học tập (CVHT)

- **Chức năng** của CVHT: Quản lý, tư vấn, hỗ trợ SV, là cầu nối giữa Nhà trường - Gia đình - Xã hội.
- **Hướng dẫn** SV: phương pháp học tập, NCKH; Xây dựng kế hoạch học tập toàn khóa; Hướng dẫn SV đăng ký môn học từng học kỳ.
- **Tổ chức** cho SV:
  QR Code

\* Đánh giá điểm rèn luyện;

\* Xét học bổng, khen thưởng, kỷ luật,...

\* Sinh hoạt CVHT;

\* Tư vấn SV học tập, sinh hoạt, rèn luyện, nghề nghiệp.

### 4. Phòng Đào tạo

- Công tác tuyển sinh;
- Chương trình đào tạo;
- Lập kế hoạch học tập;
- Đăng ký môn học: Đề nghị mở lớp học phần; Xóa học phần; Rút môn học.
- Cấp bảng điểm;
- Công tác xét tốt nghiệp,
- Cấp phát văn bằng và chứng chỉ;
- Đăng ký học cùng lúc 02 chương trình đào tạo;
- Quy định công tác học vụ.

### 5. Đơn vị quản lý đào tạo

- Đơn vị chịu trách nhiệm đào tạo các ngành theo sự phân công của Trường;
- Là đơn vị hành chính đầu tiên của Trường tiếp nhận và xử lý tất cả các yêu cầu của SV (_thuộc ngành học mà đơn vị chịu trách nhiệm quản lý_) đối với nhà trường.

---

5

<!-- page: 5 -->

### B. Các đơn vị hỗ trợ khác

### 1. Phòng Kế hoạch và Tài chính

- Phát tiền học bổng khuyến khích học tập;
- Tạm ứng - thanh toán đề tài NCKH;
- Theo dõi, xử lý lỗi kỹ thuật trong quá trình SV nộp học phí; phí, lệ phí khác qua các tiện ích;
- Tiền khen thưởng.

### 2. Văn phòng Đoàn Thanh niên

- Công tác Đoàn - Hội Sinh viên;
- Hoạt động phong trào trong và ngoài Trường

### 3. Trung tâm Chuyển đổi số và truyền thông

- Xử lý lỗi kỹ thuật, mật khẩu của Tài khoản và email SV.

### 4. Thư viện Đại học Cần Thơ

- Làm thẻ sinh viên, thủ tục mượn sách, trả sách tại Thư viện Đại học Cần Thơ.

### C. Công tác đánh giá điểm rèn luyện trực tuyến

### 1. Quy trình

https://dsa.ctu.edu.vn/images/upload/vbanply/2025/4-Congtacsinhvien.pdf
QR code for Quy trình

### 2. Quy chế đánh giá điểm rèn luyện

<u></u>
QR code for Quy chế

### 3. Nhật ký rèn luyện

Học kỳ (HK): Năm học: -
Kết quả học tập: , rèn luyện:
Các phong trào, hoạt động ngoại khóa SV đã tham gia trong HK:

---

6

<!-- page: 6 -->

Học kỳ (HK): Năm học: -
Kết quả học tập: , rèn luyện:
Các phong trào, hoạt động ngoại khóa SV đã tham gia trong HK:

Học kỳ (HK): Năm học: -
Kết quả học tập: , Kết quả rèn luyện:
Các phong trào, hoạt động ngoại khóa SV đã tham gia trong HK:

Học kỳ (HK): Năm học: -
Kết quả học tập: , Kết quả rèn luyện rèn luyện:
Các phong trào, hoạt động ngoại khóa SV đã tham gia trong HK:

---

7

<!-- page: 7 -->

Học kỳ (HK)............... Năm học:............ -...................
Kết quả học tập: ................ , rèn luyện: ..........
Các phong trào, hoạt động ngoại khóa SV đã tham gia trong HK:

Học kỳ (HK)............... Năm học:............ -...................
Kết quả học tập: ................ , rèn luyện: ..........
Các phong trào, hoạt động ngoại khóa SV đã tham gia trong HK:

---

8

<!-- page: 8 -->

Học kỳ (HK) Năm học: -
Kết quả học tập: , rèn luyện:
Các phong trào, hoạt động ngoại khóa SV đã tham gia trong HK:

Học kỳ (HK) Năm học: -
Kết quả học tập: , rèn luyện:
Các phong trào, hoạt động ngoại khóa SV đã tham gia trong HK:

---

9

<!-- page: 9 -->

Học kỳ (HK) Năm học: -
Kết quả học tập: , rèn luyện:
Các phong trào, hoạt động ngoại khóa SV đã tham gia trong HK:

Học kỳ (HK) Năm học: -
Kết quả học tập: , rèn luyện:
Các phong trào, hoạt động ngoại khóa SV đã tham gia trong HK:
