1

<!-- page: 1 -->

BỘ GIÁO DỤC VÀ ĐÀO TẠO
**TRƯỜNG ĐẠI HỌC CẦN THƠ**
**CỘNG HOÀ XÃ HỘI CHỦ NGHĨA VIỆT NAM**
**Độc lập - Tự do - Hạnh phúc**

Số: 4544/QĐ-ĐHCT
*Cần Thơ, ngày 14 tháng 10 năm 2019*

# QUYẾT ĐỊNH

## Ban hành Quy định công tác học vụ dành cho sinh viên liên thông từ trình độ cao đẳng lên trình độ đại học hệ chính quy

# HIỆU TRƯỞNG TRƯỜNG ĐẠI HỌC CẦN THƠ

Căn cứ Khoản 2, Điều 11, Chương II của “Điều lệ trường đại học” ban hành kèm theo Quyết định số 70/2014/QĐ-TTg ngày 10 tháng 12 năm 2014 của Thủ tướng Chính phủ, quy định về nhiệm vụ, quyền hạn của hiệu trưởng trường đại học;

Căn cứ Quyết định số 18/2017/QĐ-TTg ngày 31 tháng 5 năm 2017 của Thủ tướng Chính phủ ban hành Quy định về liên thông giữa trình độ trung cấp, trình độ cao đẳng với trình độ đại học;

Căn cứ Văn bản hợp nhất số 17/VBHN-BGDĐT ngày 15 tháng 5 năm 2014 của Bộ trưởng Bộ Giáo dục và Đào tạo Quyết định ban hành Quy chế đào tạo đại học và cao đẳng hệ chính quy theo hệ thống tín chỉ;

Căn cứ Thông tư 25/2015/TT-BGDĐT ngày 04 tháng 10 năm 2015 của Bộ trưởng Bộ Giáo dục và Đào tạo ban hành Thông tư Quy định về chương trình môn học Giáo dục thể chất thuộc các chương trình đào tạo trình độ đại học;

Căn cứ Thông tư 10/2016/TT-BGDĐT ngày 05 tháng 4 năm 2016 của Bộ trưởng Bộ Giáo dục và Đào tạo ban hành Quy chế công tác sinh viên đối với chương trình đào tạo đại học hệ chính quy;

Căn cứ Thông tư số 16/2015/TT-BGDĐT ngày 12 tháng 8 năm 2015 của Bộ trưởng Bộ Giáo dục và Đào tạo ban hành Quy chế đánh giá kết quả rèn luyện của người học được đào tạo trình độ đại học hệ chính quy;

Xét đề nghị của Trưởng phòng Đào tạo, Trưởng phòng Công tác Sinh viên,

# QUYẾT ĐỊNH:

#### Điều 1. Ban hành kèm theo Quyết định này Quy định công tác học vụ dành cho sinh viên liên thông từ trình độ cao đẳng lên trình độ đại học hệ chính quy của Trường Đại học Cần Thơ.

#### Điều 2. Quyết định này có hiệu lực kể từ học kỳ I năm học 2019-2020 và thay thế Quyết định số 3666/QĐ-ĐHCT ngày 06 tháng 10 năm 2017 của Hiệu trưởng Trường Đại học Cần Thơ ban hành Quy định công tác học vụ dành cho sinh viên liên thông từ trình độ cao đẳng lên trình độ đại học hệ chính quy.

#### Điều 3. Các Ông Trưởng phòng Đào tạo, Trưởng phòng Công tác Sinh viên, Trưởng khoa, Thủ trưởng các đơn vị có liên quan, công chức, viên chức và sinh viên chịu trách nhiệm thi hành Quyết định này./.

***Nơi nhận:***

- Như Điều 3;
- Công bố website;
- Lưu VT.

**HIỆU TRƯỞNG**
Seal of Can Tho University with signature of Ha Thanh Toan
**Hà Thanh Toàn**

---

2

<!-- page: 2 -->

# QUY ĐỊNH

## Công tác học vụ dành cho sinh viên liên thông từ trình độ cao đẳng lên trình độ đại học hệ chính quy

*(Ban hành kèm theo Quyết định số 4544/QĐ-ĐHCT ngày 14 tháng 10 năm 2019 của Hiệu trưởng Trường Đại học Cần Thơ)*

# Chương I

# NHỮNG VẤN ĐỀ CHUNG

#### Điều 1. Phạm vi điều chỉnh và đối tượng áp dụng

1. Quy định này Quy định về công tác học vụ dành cho sinh viên liên thông từ trình độ cao đẳng lên trình độ đại học hệ chính quy bao gồm: tổ chức đào tạo, đánh giá kết quả học tập, xét và công nhận tốt nghiệp.
2. Quy định này áp dụng đối với sinh viên các ngành, khóa đào tạo liên thông từ trình độ cao đẳng lên trình độ đại học hệ chính quy Trường Đại học Cần Thơ (ĐHCT).

#### Điều 2. Sinh viên

Sinh viên (*SV*) liên thông từ trình độ cao đẳng lên trình độ đại học hệ chính quy của Trường ĐHCT là những người đã trúng tuyển kỳ thi tuyển sinh liên thông hoặc được xét tuyển và có quyết định thu nhận vào Trường. Mỗi SV sẽ được cấp một mã số SV, thẻ SV và địa chỉ thư điện tử (*email*) để sử dụng trong suốt quá trình theo học tại Trường.

Sinh viên Trường ĐHCT phải chấp hành nội quy, quy định của Trường, của Khoa/Viện/Bộ môn trực thuộc Trường (*sau đây gọi chung là Khoa*), của lớp và của các đơn vị khác trong Trường. Khi vào Trường phải mang bảng tên; trang phục sạch sẽ, gọn gàng, kín đáo; phải mặc đồng phục khi tham dự những học phần có yêu cầu. SV phải giữ gìn trật tự, vệ sinh, chấp hành luật giao thông, để xe đúng nơi quy định. SV Trường ĐHCT phải có nếp sống văn minh; không làm ồn, gây mất trật tự; không tụ tập uống rượu bia.

#### Điều 3. Chương trình đào tạo

Chương trình đào tạo (*CTĐT*) liên thông từ trình độ cao đẳng lên trình độ đại học hệ chính quy là CTĐT trình độ đại học hệ chính quy; bao gồm các học phần thuộc khối kiến thức giáo dục đại cương và giáo dục chuyên nghiệp. Tích lũy đủ các học phần của CTĐT, SV sẽ được xét cấp bằng tốt nghiệp.

#### Điều 4. Xét miễn và công nhận điểm học phần

Căn cứ vào kết quả học tập của SV đã học ở trình độ cao đẳng, Hội đồng đào tạo liên thông tổ chức xét miễn và công nhận điểm học phần cho mỗi SV theo quy định hiện hành của Trường.

#### Điều 5. Kế hoạch học tập

Căn cứ kết quả xét miễn và công nhận điểm học phần được phê duyệt, thông qua tư vấn của cố vấn học tập (*CVHT*), SV xây dựng kế hoạch học tập toàn khóa (*KHHTTK*) bằng cách liệt kê các học phần phải học cho từng học kỳ (HK) của khóa học. KHHTTK phải được CVHT phê duyệt. KHHTTK là cơ sở để SV đăng ký học phần trong mỗi HK.

---

3

<!-- page: 3 -->

Sinh viên có thể thay đổi KHHTTK trong quá trình học nhưng phải xin ý kiến tư vấn của CVHT.

#### Điều 6. Thời gian đào tạo

Thời gian để hoàn thành và thời gian được phép học tối đa CTĐT liên thông từ trình độ cao đẳng lên trình độ đại học được xác định theo bảng dưới đây:

| Chương trình đào tạo đại học | Thời gian hoàn thành chương trình liên thông | Thời gian được phép học tối đa |
| ------------------------------------- | ---------------------------------------------------- | -------------------------------------- |
| 4 năm                                | 2 năm                                               | 4 năm                                 |
| Trên 4 năm                          | 2,5 năm                                             | 5 năm                                 |

Những SV được hưởng ưu tiên theo đối tượng quy định tại Quy chế tuyển sinh đại học, cao đẳng hệ chính quy không giới hạn thời gian tối đa để hoàn thành CTĐT.

#### Điều 7. Học kỳ

Mỗi năm học được tổ chức thành 3 học kỳ:

\* Học kỳ I và học kỳ II là các HK chính kéo dài 20 tuần; trong đó gồm 15 tuần học, 1 tuần dự trữ và thi những học phần lẻ, 2 tuần thi học phần chung, 1 tuần xử lý kết quả và 1 tuần nghỉ giữa 2 học kỳ. Học kỳ I bắt đầu từ tháng 8 đến cuối tháng 12, HK II bắt đầu từ tháng 1 đến cuối tháng 5.

\* Học kỳ III là HK phụ kéo dài 8 tuần; trong đó gồm 5 tuần học, 3 tuần thi và xử lý kết quả. Học kỳ III bắt đầu từ giữa tháng 5 đến cuối tháng 6. Học kỳ III giúp SV rút ngắn thời gian học, cải thiện kết quả học tập. Không bắt buộc SV phải học HK III. Kết quả học tập của HK III không dùng để xét học bổng, khen thưởng, kỷ luật SV.

#### Điều 8. Học phần, lớp học phần và lớp chuyên ngành

1. Học phần là lượng kiến thức tương đối trọn vẹn được dạy trong một HK. Mỗi học phần có tên riêng và được ký hiệu bằng một mã số.
2. Học phần bắt buộc là học phần SV phải tích lũy.
3. Học phần tự chọn là học phần SV tự lựa chọn để tích lũy.
4. Học phần tiên quyết của học phần HPxxx là học phần mà SV phải tích lũy mới được đăng ký học học phần HPxxx.
5. Học phần song hành của học phần HPxxx là học phần mà sinh viên phải học trước hoặc học cùng lúc với học phần HPxxx.
6. Học phần điều kiện là học phần mà SV phải hoàn thành nhưng kết quả học phần không dùng để tính điểm trung bình chung tích lũy (ĐTBCTL); ngoài ra, điểm học phần Giáo dục thể chất (GDTC) không dùng để tính điểm trung bình chung học kỳ (ĐTBCHK) và điểm trung bình chung năm học (ĐTBCNH). Các học phần điều kiện bao gồm: Giáo dục Quốc phòng và An ninh (GDQP&AN), GDTC, Ngoại ngữ căn bản, Tin học căn bản.
7. Lớp học phần là lớp bao gồm những SV đăng ký theo học cùng học phần trong 1 học kỳ. Mỗi học phần có thể có nhiều lớp học phần với mã số khác nhau.

---

4

<!-- page: 4 -->

8. Lớp chuyên ngành là lớp được hình thành từ đầu khóa học cho đến cuối khóa học. Tổ chức lớp chuyên ngành để duy trì những sinh hoạt đoàn thể, lao động, xét kết quả rèn luyện, xét khen thưởng, phổ biến những thông tin của Trường, khoa đến SV. Mỗi lớp chuyên ngành có mã số riêng và được bố trí một CVHT để giúp đỡ SV.

#### Điều 9. Tín chỉ và tiết học

1. Kiến thức của mỗi học phần và toàn khóa học được đo lường bằng tín chỉ (TC). Thời lượng của TC được quy định như sau:

1 TC = 15 tiết học lý thuyết và 30 tiết tự học, chuẩn bị cá nhân có hướng dẫn; hoặc 30 tiết thực hành, thí nghiệm, thảo luận, seminar... và 15 tiết tự học, chuẩn bị cá nhân có hướng dẫn; hoặc 45 tiết thực tập tại cơ sở, làm tiểu luận, bài tập lớn, đồ án, niên luận, tiểu luận tốt nghiệp, luận văn tốt nghiệp.

2. Một tiết học được tính bằng 50 phút.

#### Điều 10. Học bổng và trợ cấp xã hội

1. Học bổng khuyến khích học tập

a) Học bổng khuyến khích học tập (*HBKKHT*) được xét cấp theo HK dựa trên cơ sở ĐTBCHK (*xem Điều 23*) và điểm rèn luyện (*ĐRL - xem Điều 24*) của HK chính trước đó. Học bổng được cấp cho SV từ cao xuống thấp theo mức học bổng (*xem điểm d khoản 1 Điều 10 này*), trong từng mức ưu tiên theo ĐTBCHK (*trường hợp SV có cùng ĐTBCHK thì xét ưu tiên theo ĐRL*).

b) Quỹ học bổng cấp cho SV từng lớp chuyên ngành được công bố từ đầu khóa học và sẽ được điều chỉnh nếu nguồn quỹ học bổng của Trường có thay đổi.

c) Điều kiện để được xét học bổng:

- Có số TC đăng ký tối thiểu trong HK chính trước đó là 15 TC (*trừ trường hợp do Trường bố trí*);
- Học kỳ chính trước đó, SV có kết quả học tập, rèn luyện đạt từ loại khá trở lên, trong đó không có học phần dưới điểm D (*xem Điều 21*);
- Không bị kỷ luật từ hình thức khiển trách cấp Trường trở lên.

d) Tiêu chuẩn cho từng mức học bổng được xác định như sau:

- Mức học bổng loại xuất sắc: ĐTBCHK và ĐRL đạt loại xuất sắc.
- Mức học bổng loại giỏi: ĐTBCHK đạt từ loại giỏi và ĐRL đạt từ loại tốt trở lên.
- Mức học bổng loại khá: ĐTBCHK và ĐRL đạt từ loại khá trở lên.

e) Học bổng cho SV đi học tập ở nước ngoài: SV được cấp HBKKHT còn được xét cấp học bổng để đi học nước ngoài theo Quy chế số 770/QĐ-ĐHCT, ngày 15/3/2017 của Hiệu trưởng Trường Đại học Cần Thơ.

f) Mức học bổng do Hiệu trưởng quyết định.

2. Học bổng tài trợ: Hằng năm, Trường xét cấp học bổng tài trợ từ nguồn tài trợ của các cơ quan, doanh nghiệp, tổ chức, cá nhân,... trong và ngoài nước theo quy định về quản lý và cấp phát học bổng tài trợ.

---

5

<!-- page: 5 -->

3. Quỹ hỗ trợ sinh viên: Khi gặp khó khăn đột xuất về kinh tế, SV có thể làm đơn trình bày rõ hoàn cảnh khó khăn, có xác nhận của CVHT và trưởng khoa để Hiệu trưởng xem xét.
4. Trợ cấp xã hội: Đối tượng được hưởng trợ cấp xã hội là SV dân tộc ít người ở vùng cao; SV mồ côi cả cha lẫn mẹ; SV tàn tật trên 41%; SV thuộc hộ nghèo, hộ đói.

#### Điều 11. Học phí, miễn, giảm học phí và hỗ trợ chi phí học tập

1. Học phí đóng theo HK và tính theo tổng số TC mà SV đã đăng ký học ở HK đó. Mức học phí do Hiệu trưởng quyết định.
2. Đối tượng được miễn, giảm học phí và được hỗ trợ chi phí học tập thực hiện theo các quy định hiện hành và các văn bản hướng dẫn có liên quan.

*(Hồ sơ hướng dẫn thực hiện miễn, giảm học phí và hỗ trợ chi phí học tập tại website Phòng Công tác Sinh viên).*

Sau thời hạn đóng học phí, SV không đóng học phí sẽ bị hủy kết quả học tập những học phần nợ học phí trong HK đó và buộc phải đóng học phí còn nợ cùng lúc với học phí của HK tiếp theo. Không đóng học phí 2 HK liên tiếp sẽ bị buộc thôi học.

#### Điều 12. Bảo hiểm y tế, bảo hiểm tai nạn và tín dụng sinh viên

1. Bảo hiểm y tế (BHYT): SV phải nộp BHYT theo các quy định hiện hành của Luật Bảo hiểm y tế số 25/2008/QH12, ngày 14/11/2008 và các văn bản hướng dẫn có liên quan.
2. Bảo hiểm tai nạn (BHTN): Trường khuyến khích SV tham gia nộp BHTN.
3. Tín dụng sinh viên: SV có thể xin vay tín dụng từ các Ngân hàng Chính sách xã hội tại địa phương nơi gia đình SV cư trú. Trường sẽ cấp giấy xác nhận để SV bổ sung hồ sơ xin vay vốn.

## Chương II

## TỔ CHỨC ĐÀO TẠO

#### Điều 13. Trách nhiệm của Trường và SV trong việc đăng ký học phần

1. Trách nhiệm của Trường:

a) Đầu khóa học, Trường cung cấp cho mỗi SV CTĐT của ngành học có xác định những học phần được xét miễn và công nhận điểm, Quy định công tác học vụ và bố trí CVHT cho từng lớp chuyên ngành.

b) Cán bộ làm CVHT chịu trách nhiệm quản lý SV, tư vấn SV xây dựng KHHTTK và thực hiện quá trình học tập theo đúng quy định của Trường.

c) Đầu mỗi HK, Trường thông báo cho SV những học phần sẽ giảng dạy trong HK đó và thời khóa biểu *(TKB)* của từng học phần tương ứng.

2. Trách nhiệm của SV: Sinh viên phải thực hiện đăng ký học phần trước khi HK mới bắt đầu. Các học phần đăng ký phải theo KHHTTK (xem Điều 5).

#### Điều 14. Số tín chỉ đăng ký trong một học kỳ

Để đảm bảo tiến độ thời gian hoàn thành khóa học và đảm bảo chất lượng học tập, mỗi học kỳ SV chỉ đăng ký với số lượng TC như sau:

---

6

<!-- page: 6 -->

1. Học kỳ chính:

a) SV đăng ký học tối đa 20 TC. Những SV chỉ còn lại ≤ 25 TC của CTĐT được đăng ký tối đa 25 TC.

b) SV bị cảnh báo học vụ (*Điểm a, Khoản 2, Điều 18*) chỉ được phép đăng ký tối đa 14 TC.

2. Học kỳ phụ: SV đăng ký tối đa 8 TC. Trường không bắt buộc SV phải học HK này.

Tuỳ theo năng lực học tập và điều kiện cá nhân, sinh viên nên đăng ký học với số TC phù hợp để đạt kết quả học tập tốt.

#### Điều 15. Quy trình đăng ký học phần

Sinh viên dựa vào KHHTTK và TKB các học phần giảng dạy trong HK do Trường công bố để đăng ký học phần trực tuyến theo kế hoạch chung. Sau tuần lễ thứ 2 của HK, SV vào hệ thống quản lý trực tuyến để in "Kết quả đăng ký học phần".

**Lưu ý:**

- Danh mục các học phần sẽ mở ở HK được quy định trong danh mục tra cứu CTĐT và được công bố 6 tuần trước khi bắt đầu HK.
- Danh mục các học phần đủ điều kiện tổ chức giảng dạy sẽ được công bố 1 tuần trước khi bắt đầu HK.
- Trong 1 tuần đầu của HK, SV có thể xóa những học phần đã đăng ký; hoặc đăng ký bổ sung những học phần mới (*trừ các học phần thực hành, thí nghiệm, thực tập tại cơ sở, GDQP&AN, GDTC*) thay cho các học phần mà Trường không thể mở được. Sau thời gian trên, kết quả đăng ký học phần của SV sẽ được cố định.
- Chậm nhất là tuần lễ thứ 8 của HK chính và tuần lễ thứ 2 của HK phụ nếu thấy việc học khó khăn có thể dẫn đến kết quả kém, SV có thể rút bớt học phần đã đăng ký nhưng không được trả lại học phí. Muốn rút bớt học phần, SV vào hệ thống quản lý trực tuyến của Trường để thực hiện. Những học phần đã rút sẽ nhận điểm W trong bảng điểm HK.
- Sinh viên đã đăng ký học phần nhưng không đi học hoặc không dự thi kết thúc học phần sẽ bị điểm F của học phần đó.

#### Điều 16. Xóa và mở thêm lớp học phần

1. Xóa lớp học phần: Trường sẽ xóa những lớp học phần có số lượng đăng ký ít hơn 25 SV, những trường hợp đặc biệt do Hiệu trưởng quyết định. Trong tuần đầu HK, những SV đã đăng ký các học phần bị xóa do không đủ điều kiện mở lớp được phép đăng ký học phần khác để thay thế (trừ các học phần thực hành, thí nghiệm, thực tập tại cơ sở, GDQP&AN, GDTC).
2. Mở thêm lớp học phần: Trong thời gian quy định đăng ký học phần của HK, nếu có nhiều hơn 25 SV có nguyện vọng học, được trưởng bộ môn và trưởng khoa quản lý học phần đó chấp thuận, Trường sẽ mở thêm lớp học phần theo đề nghị.

#### Điều 17. Đăng ký học lại

1. Các học phần có điểm F sẽ không được tính tích lũy. Nếu là học phần bắt buộc, SV phải đăng ký học lại những học phần này; nếu là học phần tự chọn, SV có thể đăng ký học lại hoặc chọn học phần tự chọn khác.

---

7

<!-- page: 7 -->

2. Sinh viên có thể đăng ký học để cải thiện kết quả. Điểm của học phần sẽ là điểm cao nhất trong các lần học. Số tín chỉ của học phần học cải thiện bị điểm F sẽ không tính giảm một mức hạng tốt nghiệp theo Điểm a, Khoản 2, Điều 32.
3. Đối với học phần tự chọn, nếu SV tích lũy số TC nhiều hơn yêu cầu của nhóm học phần tự chọn, khi xét tốt nghiệp SV có thể lựa chọn học phần có điểm cao để tính vào ĐTBCTL.

#### Điều 18. Nghỉ học tạm thời, cảnh báo học vụ, đình chỉ học tập và buộc thôi học

1. Nghỉ học tạm thời: SV có thể làm đơn xin phép nghỉ học tạm thời trong các trường hợp sau đây:

a) Được điều động vào các lực lượng vũ trang.

b) Ốm đau, tai nạn phải điều trị trong thời gian dài (có xác nhận của cơ quan y tế).

c) Vì nhu cầu cá nhân (*hoàn cảnh gia đình neo đơn, việc riêng...*). Trường hợp này chỉ giải quyết khi SV đã học ít nhất 1 học kỳ ở Trường, không rơi vào tình trạng bị buộc thôi học và phải có ĐTBCTL không dưới 2,00. Thời gian nghỉ học tạm thời trong trường hợp này được tính vào quỹ thời gian để hoàn thành CTĐT.

Nếu được chấp thuận, SV sẽ được nhận quyết định cho phép nghỉ học của Hiệu trưởng. Khi hết thời gian nghỉ học tạm thời và chậm nhất là 2 tuần trước khi HK mới bắt đầu, SV phải nộp hồ sơ xin học lại. Nếu đủ điều kiện, Hiệu trưởng sẽ có quyết định thu nhận SV học lại.

2. Cảnh báo học vụ là hình thức cảnh báo SV trong các trường hợp:

a) Có ĐTBCHK đạt dưới 0,80 đối với học kỳ đầu của khóa học, dưới 1,00 đối với các học kỳ tiếp theo.

b) Không đăng ký học trong HK chính mà không được sự cho phép của Hiệu trưởng.

3. Đình chỉ học tập 1 học kỳ trong các trường hợp:

a) Bị kỷ luật ở mức đình chỉ học tập.

b) Có ĐRL yếu, kém trong 2 học kỳ liên tiếp.

4. Đình chỉ học tập 1 năm trong trường hợp bị kỷ luật ở mức đình chỉ học tập.
5. Buộc thôi học trong các trường hợp:

a) Bị kỷ luật ở mức buộc thôi học.

b) Đã bị cảnh báo học vụ và HK chính kế tiếp có ĐTBCHK dưới 1,00. Những trường hợp đặc biệt sẽ do Hiệu trưởng quyết định.

c) Nghỉ học tạm thời quá thời hạn cho phép.

d) Không đăng ký học trong 2 học kỳ chính liên tiếp mà không được sự cho phép của Hiệu trưởng.

e) Không đóng học phí 2 học kỳ liên tiếp.

f) Có ĐRL yếu, kém 2 học kỳ liên tiếp lần thứ hai.

g) Đã hết thời gian tối đa được phép học.

Những trường hợp bị buộc thôi học tại Điểm b, Điểm g, SV có thể xin xét chuyển sang học các chương trình giáo dục thường xuyên tương ứng (*nếu có*).

---

8

<!-- page: 8 -->

CVHT thông báo về gia đình những trường hợp SV bị cảnh báo học vụ và bị xử lý kỷ luật. Trường gửi về địa phương và gia đình các trường hợp SV bị đình chỉ học tập hoặc buộc thôi học.

#### Điều 19. Giờ lên lớp

Sinh viên phải dự 100% số tiết đối với các học phần thực hành, thí nghiệm, thực tập tại cơ sở, GDQP&AN, GDTC; phải tham dự tối thiểu 80% số tiết đối với các học phần lý thuyết. SV vắng lên lớp nhiều hơn thời gian quy định sẽ bị cấm thi. Giảng viên (GV) giảng dạy học phần đề nghị trưởng khoa duyệt danh sách SV bị cấm thi và cho điểm F vào bảng điểm.

Vào buổi học đầu tiên, GV thông báo cho SV biết đề cương chi tiết học phần (*nội dung học phần, phương pháp giảng dạy, hình thức kiểm tra, đánh giá, cách tính điểm...*).

Công tác giảng dạy, học tập được thực hiện 6 ngày/tuần (*trừ Chủ nhật*). Thời gian giảng dạy trong ngày được phân bổ như bảng dưới đây:

| BUỔI HỌC | TIẾT HỌC | GIỜ HỌC                | THỜI GIAN NGHỈ  |
| ---------- | ---------- | ------------------------ | ----------------- |
| SÁNG      | 1          | 07:00 – 07:50           | Không            |
| SÁNG      | 2          | 07:50 – 08:40           | 10 phút          |
| SÁNG      | 3          | 08:50 – 09:40           | 10 phút          |
| SÁNG      | 4          | 09:50 – 10:40           | Không            |
| SÁNG      | 5          | **10:40 – 11:30** |                   |
| CHIỀU     | 6          | **13:30** – 14:20 | Không            |
| CHIỀU     | 7          | 14:20 – 15:10           | 10 phút          |
| CHIỀU     | 8          | 15:20 – 16:10           | Không            |
| CHIỀU     | 9          | **16:10 – 17:00** |                   |
| TỐI       | 10         | Tiết nghỉ chung        | Tiết nghỉ chung |
| TỐI       | 11         | **18:20** – 19:10 | Không            |
| TỐI       | 12         | 19:10 –**20:00**  |                   |

# Chương III

# ĐÁNH GIÁ KẾT QUẢ HỌC TẬP

#### Điều 20. Đánh giá học phần

1. Học phần lý thuyết hoặc lý thuyết kết hợp thực hành: Điểm học phần được tính từ các điểm thành phần bao gồm: điểm bài tập, điểm kiểm tra giữa kỳ, điểm thực hành, điểm đánh giá nhận thức, điểm tham gia thảo luận, điểm chuyên cần, điểm đồ án và điểm thi kết thúc học phần. Thi kết thúc học phần là bắt buộc và điểm phải có trọng số không dưới 50%.
2. Học phần thực hành: Điểm học phần được tính bằng điểm trung bình của các bài thực hành.

Hình thức đánh giá học phần, trọng số các điểm thành phần do GV đề xuất, trưởng bộ môn, trưởng khoa quản lý học phần duyệt và công bố trong đề cương chi tiết học phần.

---

9

<!-- page: 9 -->

#### Điều 21. Điểm học phần

1. Điểm đánh giá thành phần và điểm thi kết thúc học phần được chấm theo thang điểm 10 (từ 0 đến 10), làm tròn đến một chữ số thập phân.
2. Điểm học phần là tổng số điểm của tất cả các điểm đánh giá thành phần của học phần nhân với trọng số tương ứng. Điểm học phần được tính theo thang điểm 10 và làm tròn đến một chữ số thập phân. GV phụ trách học phần nhập điểm vào hệ thống quản lý trực tuyến, hệ thống quy đổi sang điểm chữ và điểm số theo thang điểm 4. Cách quy đổi điểm được thực hiện theo bảng dưới đây:

| Điểm sốtheo thang điểm 10 | Điểm chữ | Điểm sốtheo thang điểm 4 |
| ------------------------------ | ----------- | ----------------------------- |
| 9,0 – 10,0                    | A           | 4,0                           |
| 8,0 – 8,9                     | B +         | 3,5                           |
| 7,0 – 7,9                     | B           | 3,0                           |
| 6,5 – 6,9                     | C +         | 2,5                           |
| 5,5 – 6,4                     | C           | 2,0                           |
| 5,0 – 5,4                     | D +         | 1,5                           |
| 4,0 – 4,9                     | D           | 1,0                           |
| nhỏ hơn 4,0                  | F           | 0,0                           |

3. Học phần chỉ được tính tích lũy khi đạt từ điểm D trở lên.
4. Điểm học phần sẽ được công bố và ghi nhận với điểm số theo thang điểm 10 và điểm chữ. Điểm chữ được quy đổi sang điểm số theo thang điểm 4 để tính ĐTBCHK và ĐTBCTL (xem Điều 23).
5. Các điểm học phần khác

a) Điểm M: Dùng để xác nhận học phần SV được miễn học do đã tích lũy được bằng các hình thức khác. Điểm M không được tính vào ĐTBCHK và ĐTBCTL. Số TC của học phần có điểm M được tính vào tổng số TC tích lũy. Để nhận điểm M, SV phải làm đơn có ý kiến của CVHT và trưởng khoa xem xét theo từng HK, kèm theo giấy tờ hợp lệ.

b) Điểm I: Dành cho các trường hợp chưa hoàn thành đầy đủ yêu cầu của học phần (*SV đã dự học, dự các lần kiểm tra giữa HK, đã thực hiện các hoạt động liên quan đến học phần như thí nghiệm, thực hành nhưng vì lý do bất khả kháng như ốm đau, tai nạn... đã vắng mặt trong buổi thi kết thúc học phần và được GV phụ trách học phần chấp thuận cho bổ sung điểm*). Điểm I không được tính vào ĐTBCHK ở HK đó. Để nhận được điểm I, SV phải làm đơn kèm theo hồ sơ hợp lệ nộp cho GV giảng dạy học phần xem xét và trình trưởng khoa duyệt. Thời hạn bổ sung điểm của học phần do GV quy định nhưng không quá 1 năm kể từ ngày thi lần trước. Quá thời hạn trên, nếu SV không hoàn thành thì sẽ bị điểm F.

c) Điểm W: Dành cho các học phần mà SV được phép rút theo quy định (*xem Điều 15*). Điểm W không tính vào ĐTBCHK và ĐTBCTL.

8

---

10

<!-- page: 10 -->

#### Điều 22. Số lần thi, tổ chức thi và vắng thi

1. Kỳ thi kết thúc học phần được tổ chức 1 lần. Lịch thi kết thúc học phần phải được thông báo tới tất cả SV chậm nhất 1 tuần trước ngày thi.
2. Thời gian tổ chức thi được thực hiện theo quy định (xem Điều 7). Đối với các học phần riêng lẻ, GV tự sắp xếp để tổ chức thi; đối với các học phần có nhiều SV, được giảng dạy nhiều lớp học phần thì sẽ thi theo lịch chung do khoa quản lý học phần xếp.
3. Trong thời gian thi kết thúc học phần, nếu SV có lý do chính đáng không thể dự thi, được CVHT và GV giảng dạy học phần chấp thuận thì được phép vắng thi. SV được phép vắng thi sẽ được hưởng điểm I theo quy định (xem Điểm b, Khoản 5, Điều 21).

#### Điều 23. Điểm trung bình chung học kỳ, điểm trung bình chung năm học và điểm trung bình chung tích lũy

1. Số TC tích lũy là tổng số TC của các học phần đã tích lũy.
2. Điểm trung bình chung học kỳ là trung bình có trọng số của điểm các học phần mà SV đã học trong HK (kể cả các học phần bị điểm F và học phần điều kiện trừ học phần GDTC), với trọng số là số TC của các học phần đó. ĐTBCHK là cơ sở để đánh giá kết quả học tập, xét học bổng, khen thưởng, cảnh báo học vụ sau mỗi HK. ĐTBCHK được tính theo công thức tính như sau:

$$
ĐTBCHK = \frac{\sum_{i=1}^{n} a_i X_i}{\sum_{i=1}^{n} a_i}
$$

Trong đó: $X_i$ là điểm học phần thứ i;
$a_i$ là số TC của học phần thứ i;
$n$ là số học phần SV đăng ký học trong HK.

3. Điểm trung bình chung năm học là trung bình có trọng số của điểm các học phần mà SV đã học trong 2 HK chính của năm học (kể cả các học phần bị điểm F và học phần điều kiện trừ học phần GDTC).
4. Điểm trung bình chung tích lũy là trung bình có trọng số của điểm các học phần đã tích lũy tính đến thời điểm xét (không bao gồm các học phần bị điểm F và học phần điều kiện). ĐTBCTL là cơ sở để đánh giá kết quả học tập trong suốt thời gian học, xếp loại học tập, xếp hạng tốt nghiệp.
5. Xếp loại học tập HK căn cứ vào ĐTBCHK; xếp loại học tập năm học căn cứ vào ĐTBCNH theo bảng sau:

| Xếp loại       | ĐTBCHK/ĐTBCNH |
| ---------------- | --------------- |
| Xuất sắc       | 3,60 - 4,00     |
| Giỏi            | 3,20 - 3,59     |
| Khá             | 2,50 - 3,19     |
| Trung bình      | 2,00 - 2,49     |
| Trung bình yếu | 1,00 - 1,99     |
| Kém             | < 1,00          |

---

11

<!-- page: 11 -->

#### Điều 24. Điểm rèn luyện

1. Mức độ rèn luyện của SV được đánh giá từng HK của 2 học kỳ chính và đo lường bằng ĐRL được chấm theo thang điểm 100 dựa vào các quy định hiện hành. ĐRL cả năm là trung bình cộng của ĐRL 2 học kỳ chính. HK phụ không tính ĐRL.
2. Sinh viên bị kỷ luật mức khiển trách cấp Trường, khi đánh giá kết quả rèn luyện không được vượt quá loại khá.
3. Sinh viên bị kỷ luật mức cảnh cáo cấp Trường, khi đánh giá kết quả rèn luyện không được vượt quá loại trung bình.
4. Sinh viên không thực hiện bảng đánh giá kết quả rèn luyện hoặc không nộp bảng đánh giá đúng thời gian quy định sẽ bị xếp loại kém ở HK đó.
5. Sinh viên bị xếp loại rèn luyện yếu, kém trong 2 học kỳ liên tiếp sẽ bị đình chỉ học tập 1 học kỳ.
6. Sinh viên bị xếp loại rèn luyện yếu, kém trong 2 học kỳ liên tiếp lần thứ hai thì sẽ bị buộc thôi học.
7. Sử dụng điểm rèn luyện:

a) Điểm rèn luyện toàn khóa học được lưu trong hồ sơ quản lý SV, ghi vào bảng điểm học tập toàn khóa của SV khi ra trường.

b) Điểm rèn luyện của SV từng HK là tiêu chí để xét HBKKHT, xếp loại và khen thưởng cuối mỗi năm học.

#### Điều 25. Xếp loại và khen thưởng

1. Xếp loại: SV học đủ số TC theo quy định (từ 15 TC trở lên cho mỗi HK), có tiến độ học tập trong khung thời gian thiết kế CTĐT, không vi phạm kỷ luật từ hình thức khiển trách cấp Trường trở lên, đạt thành tích cao trong học tập và rèn luyện sẽ được xếp loại như sau:

a) Loại xuất sắc: Học tập và rèn luyện đạt loại xuất sắc.

b) Loại giỏi: Học tập đạt từ loại giỏi và rèn luyện đạt từ loại tốt trở lên.

c) Loại khá: Học tập và rèn luyện đạt từ loại khá trở lên.

2. Khen thưởng

a) SV tốt nghiệp đúng hoặc sớm hơn thời gian thiết kế của CTĐT:

- SV đạt từ loại khá toàn khóa trở lên được xét thủ khoa của ngành/chuyên ngành đào tạo sẽ được cấp giấy khen và phần thưởng.
- SV đạt từ loại giỏi toàn khoá trở lên sẽ được cấp giấy khen.

b) Khen thưởng SV cuối mỗi năm học: Hiệu trưởng xét cấp giấy khen và phần thưởng cho mỗi lớp chuyên ngành 1 sinh viên được xếp từ loại giỏi trở lên.

Trường hợp SV có cùng kết quả học tập thì ưu tiên chọn SV có ĐRL cao hơn.

3. Định mức khen thưởng do Hiệu trưởng quyết định.

#### Điều 26. Quy định về thi và kiểm tra

Sinh viên có trách nhiệm chấp hành các quy định về thi và kiểm tra, cụ thể như sau:

1. Thực hiện đúng lịch kiểm tra và thi của Trường, của khoa, của bộ môn. Phải có mặt đúng giờ, nếu đến trễ 15 phút sau khi mở đề SV sẽ không được dự thi và xem như vắng thi không lý do, sẽ nhận điểm F cho học phần đó.

---

12

<!-- page: 12 -->

2. Phải mang bảng tên (hoặc xuất trình giấy tờ khác có ảnh, được đóng dấu giáp lai) khi vào phòng thi. Tuyệt đối phục tùng sự kiểm tra, quản lý và hướng dẫn của cán bộ coi thi (CBCT). Túi xách, tài liệu, phương tiện kỹ thuật thu, phát, truyền tin, ghi âm... phải để tập trung đúng nơi quy định.
3. Không được ra khỏi phòng thi trong thời gian làm bài. Các trường hợp đặc biệt cần cho ra ngoài đều phải lập biên bản.
4. Bài thi phải làm trên giấy thi thống nhất, viết rõ ràng, sạch sẽ. Được sử dụng bút mực hoặc bút bi màu xanh dương, đen hoặc tím; thước kẻ; thước tính; máy tính điện tử không có thẻ nhớ và không soạn thảo được văn bản; giấy nháp có chữ ký của CBCT.
5. Trong giờ thi SV phải giữ trật tự, nghiêm túc làm bài và bảo vệ bài làm của mình, không để người khác chép bài của mình. Nếu có thắc mắc phải hỏi công khai. Nếu ốm đau bất thường phải báo cáo để CBCT giải quyết.
6. Những bài thi sau đây là không hợp lệ và không được chấm điểm:

a) Làm bài trên giấy thi khác với giấy thi quy định.

b) Không có chữ ký của CBCT.

c) Viết bằng bút chì, mực đỏ (*hình vẽ có thể dùng bút chì*).

d) Các bài làm giống nhau.

e) Vẽ bậy, viết bậy trong bài thi.

7. Hết giờ làm bài, SV phải ngừng viết, để bài làm trước mặt và im lặng chờ CBCT thu bài. Khi nộp bài phải ghi rõ số tờ giấy thi đã nộp và ký tên vào danh sách dự thi.

SV vi phạm các quy định trên đây sẽ bị CBCT lập biên bản. Tùy theo mức độ nặng nhẹ xử lý kỷ luật theo quy định (*xem Điều 27*).

#### Điều 27. Các hình thức xử lý SV vi phạm quy định về thi và kiểm tra

1. Khiển trách khi SV vi phạm một trong các lỗi:

a) Nhìn bài của người khác.

b) Trao đổi, thảo luận với người khác.

Sinh viên bị khiển trách sẽ bị trừ 25% điểm số của lần thi/kiểm tra đó. SV bị khiển trách 2 lần trong một năm học sẽ bị kỷ luật cảnh cáo toàn khoa.

2. Cảnh cáo khi SV vi phạm một trong các lỗi sau:

a) Đã bị khiển trách một lần nhưng vẫn tiếp tục vi phạm trong một buổi thi.

b) Trao đổi giấy nháp cho nhau nhưng chưa sử dụng (*xử lý cả 2 SV*).

c) Chép bài của người khác hoặc để cho người khác chép bài của mình.

d) Không phục tùng sự quản lý, nhắc nhở của CBCT hoặc có thái độ vô lễ đối với CBCT.

Sinh viên bị cảnh cáo sẽ bị trừ 50% điểm số của lần thi/kiểm tra đó. SV bị cảnh cáo thi 2 lần trong một năm học sẽ bị kỷ luật cảnh cáo toàn Trường.

3. Đình chỉ thi khi SV vi phạm một trong các lỗi sau:

a) Đã bị cảnh cáo một lần nhưng vẫn tiếp tục vi phạm trong một buổi thi.

b) Sau khi mở đề thi bị phát hiện vẫn còn mang theo người (*hoặc nơi ngồi của mình*) những vật dụng không được phép mang vào phòng thi.

---

13

<!-- page: 13 -->

c) Sử dụng giấy nháp hoặc bài làm của người khác *(xử lý cả 2 SV)*.

d) Đưa đề thi ra ngoài nhờ người khác làm hộ hoặc nhận bài giải từ ngoài vào phòng thi.

e) Có hành động gây rối hoặc đe dọa CBCT hoặc SV khác.

Sinh viên bị đình chỉ thi bị nhận điểm 0 cho lần thi/kiểm tra đó. SV bị đình chỉ thi 2 lần trong một năm học sẽ bị đình chỉ học tập 1 năm sau đó. Nếu tái phạm sẽ bị buộc thôi học.

4. Xử lý thi hộ: áp dụng cho cả người thi hộ và người nhờ thi hộ:

a) Vi phạm lần thứ nhất:

- Người nhờ thi hộ: nhận điểm 0 học phần đó, đình chỉ học tập 1 năm.
- Người thi hộ: đình chỉ học tập 1 năm.

b) Vi phạm lần thứ hai *(trong cả khóa học)*: buộc thôi học.

Các trường hợp vi phạm khác tùy mức độ nặng nhẹ sẽ do Hội đồng kỷ luật của Trường xử lý.

#### Điều 28. Thông báo kết quả học tập

1. Giảng viên chịu trách nhiệm: trả bài kiểm tra và bài thi tại lớp; nhập điểm học phần vào hệ thống quản lý trực tuyến và in thành hai (02) bản, ký tên, gửi khoa quản lý học phần. Khoa quản lý học phần lưu một (01) bản và gửi về Phòng Đào tạo một (01) bản chậm nhất là 10 ngày sau ngày thi của học phần. Trưởng khoa quản lý học phần xử lý tất cả khiếu nại liên quan đến kết quả học tập của học phần do khoa quản lý và chỉ thực hiện trong thời gian 1 tuần kể từ ngày công bố điểm.
2. Đơn vị quản lý học phần lưu giữ các bài thi viết, tiểu luận, bài tập lớn ít nhất là 02 năm kể từ ngày thi hoặc ngày nộp tiểu luận.
3. Kết thúc khoá học, Trường cấp bảng điểm học tập toàn khóa cho SV được công nhận tốt nghiệp.
4. Trong quá trình học tập, SV có thể đăng ký cấp bảng điểm cá nhân theo nhu cầu riêng; mức chi phí do Trường quy định.

### Chương IV

### XÉT VÀ CÔNG NHẬN TỐT NGHIỆP

#### Điều 29. Luận văn, tiểu luận tốt nghiệp và tích lũy tín chỉ tốt nghiệp

Tùy theo tính chất của ngành đào tạo, SV được hướng dẫn thực hiện một trong ba hình thức sau:

1. Luận văn tốt nghiệp (LVTN): LVTN có khối lượng 10 TC (CTĐT 140 TC) hoặc 15 TC (CTĐT từ 155 TC trở lên). Sau khi hoàn thành luận văn, SV sẽ bảo vệ trước hội đồng gồm 3 thành viên, trong đó có cán bộ hướng dẫn của SV đó. Điểm LVTN của SV là trung bình cộng của 3 thành viên hội đồng (trọng số bằng nhau). Hội đồng bảo vệ LVTN do trưởng khoa quyết định.

12

---

14

<!-- page: 14 -->

2. Tiểu luận tốt nghiệp (TLTN): TLTN có khối lượng 4 TC (CTĐT 140 TC) hoặc 6 TC (CTĐT từ 155 TC trở lên). TLTN do cán bộ hướng dẫn và 1 cán bộ khác chấm, không phải bảo vệ trước hội đồng. Cán bộ chấm TLTN do trưởng khoa quyết định.
3. Tích lũy TC tốt nghiệp: SV có thể chọn hình thức không làm LVTN hoặc TLTN. Những SV này phải học thêm các học phần tự chọn để đủ số TC theo yêu cầu của CTĐT.

Để được nhận đề tài LVTN hoặc TLTN, SV phải thỏa mãn các điều kiện do khoa quy định. Cuối mỗi HK, khoa xét và công bố hình thức thực hiện cuối khóa cho SV ở HK tiếp theo. SV làm LVTN hay TLTN đều phải đăng ký học phần như các học phần khác.

Sinh viên nhận điểm F của LVTN hay TLTN phải đăng ký làm lại hoặc đăng ký các học phần thay thế để hoàn thành CTĐT.

#### Điều 30. Điều kiện tốt nghiệp và công nhận tốt nghiệp

1. Sinh viên có đủ các điều kiện sau đây được xét công nhận tốt nghiệp:

a) Tích lũy đủ các học phần và số TC quy định trong CTĐT; ĐTBCTL của các học phần đạt từ 2,00 trở lên *(theo thang điểm 4)*;

b) Hoàn thành các học phần điều kiện. Ngoài ra, điểm trung bình chung các học phần GDQP&AN phải đạt từ 5,0 trở lên *(theo thang điểm 10)*;

c) Không bị truy cứu trách nhiệm hình sự, không bị kỷ luật ở mức đình chỉ học tập trong năm học cuối.

2. Hằng năm, SV được xét TN vào tháng 1, tháng 6 và tháng 8. SV được nhận bằng tốt nghiệp 30 ngày kể từ ngày có quyết định công nhận tốt nghiệp. Lễ trao bằng tốt nghiệp được tổ chức vào tháng 4 và tháng 9; riêng các khoa có đào tạo giáo viên tổ chức vào tháng 8.
3. Sinh viên đăng ký xét tốt nghiệp thông qua hệ thống quản lý trực tuyến của Trường.
4. Hội đồng xét tốt nghiệp chịu trách nhiệm xét tốt nghiệp đúng thời hạn, đúng đối tượng và đề nghị Hiệu trưởng công nhận những SV đủ điều kiện tốt nghiệp.
5. Phòng Đào tạo và Phòng Công tác Sinh viên chịu trách nhiệm thẩm định và trình Hiệu trưởng ký quyết định công nhận tốt nghiệp.
6. Sinh viên đủ điều kiện tốt nghiệp được nhận quyết định công nhận tốt nghiệp, bảng điểm học tập toàn khóa và bằng tốt nghiệp. Sinh viên phải nộp chi phí thực hiện bản sao bằng tốt nghiệp do Trường quy định (nếu có yêu cầu).

#### Điều 31. Xử lý sinh viên quá hạn thời gian đào tạo

1. Khi hết thời gian tối đa được phép học, những SV không đủ điều kiện tốt nghiệp sẽ bị xóa tên, trừ những SV được hưởng ưu tiên theo đối tượng quy định tại Quy chế tuyển sinh đại học, cao đẳng hệ chính quy.
2. Sinh viên không đủ điều kiện tốt nghiệp sẽ được cấp bảng điểm các học phần đã học.
3. Sinh viên còn nợ các học phần GDQP&AN, GDTC, nhưng đã hết thời gian tối đa được phép học, trong thời hạn 5 năm SV trở về Trường trả nợ để có đủ điều kiện xét tốt nghiệp.

---

15

<!-- page: 15 -->

#### Điều 32. Bằng tốt nghiệp và hạng tốt nghiệp

1. Bằng tốt nghiệp được cấp theo ngành đào tạo.
2. Hạng tốt nghiệp được xác định căn cứ vào ĐTBCTL theo các mức trong bảng sau:

| Hạng tốt nghiệp | ĐTBCTL             |
| ------------------ | ------------------- |
| Loại xuất sắc   | từ 3,60 đến 4,00 |
| Loại giỏi        | từ 3,20 đến 3,59 |
| Loại khá         | từ 2,50 đến 3,19 |
| Loại trung bình  | từ 2,00 đến 2,49 |

Hạng tốt nghiệp loại xuất sắc và giỏi sẽ bị giảm một mức nếu rơi vào một trong các trường hợp sau:

a) Có khối lượng các học phần bị điểm F vượt quá 5% tổng số TC của CTĐT (*không tính khối lượng học phần học cải thiện điểm bị điểm F*).

b) Đã bị kỷ luật từ mức cảnh cáo cấp Trường trong thời gian học.

#### Điều 33. Thủ tục ra trường

Sau khi có quyết định tốt nghiệp, SV liên hệ khoa quản lý ngành để thực hiện thủ tục thanh toán ra trường.

#### Điều 34. Quản lý bằng tốt nghiệp

Bằng tốt nghiệp chỉ cấp một lần. Trường hợp bằng tốt nghiệp bị mất hoặc bị hỏng, SV có thể nộp đơn cho Trường (thông qua Phòng Đào tạo) để nghị cấp bản sao bằng tốt nghiệp./.

Seal of Can Tho University with signature of Ha Thanh Toan

Hà Thanh Toàn
