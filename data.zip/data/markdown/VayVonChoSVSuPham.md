# Nghị định 116/2020/NĐ-CP — Hỗ trợ học phí, sinh hoạt phí và bồi hoàn đối với sinh viên sư phạm — Từ năm học 2021-2022

Các bảng ở phần phụ lục là biểu mẫu thực hiện chính sách hỗ trợ và bồi hoàn theo Nghị định 116/2020/NĐ-CP; ô trống là phần người làm hồ sơ phải điền hoặc nội dung nguồn không quy định.

CHÍNH PHỦ
_______________________
Hà Nội, ngày 25 tháng 9 năm 2020


## Quy định về chính sách hỗ trợ tiền đóng học phí, chi phí sinh hoạt đối với sinh viên sư phạm
__________

Căn cứ Luật Tổ chức Chính phủ ngày 19 tháng 6 năm 2015; Luật sửa đổi, bổ sung một số điều của Luật Tổ chức Chính phủ và Luật Tổ chức Chính quyền địa phương ngày 22 tháng 11 năm 2019;

Căn cứ Luật Giáo dục ngày 14 tháng 6 năm 2019;

Căn cứ Luật Giáo dục đại học ngày 18 tháng 6 năm 2012; Luật sửa đổi, bổ sung một số điều của Luật Giáo dục đại học ngày 19 tháng 11 năm 2018;

Căn cứ Luật Viên chức ngày 15 tháng 11 năm 2010; Luật sửa đổi, bổ sung một số điều của Luật Cán bộ, Công chức và Luật Viên chức;

Căn cứ Luật Ngân sách nhà nước ngày 25 tháng 6 năm 2015;

Theo đề nghị của Bộ trưởng Bộ Giáo dục và Đào tạo;

Chính phủ ban hành Nghị định quy định về chính sách hỗ trợ tiền đóng học phí, chi phí sinh hoạt đối với sinh viên sư phạm.

## Chương I — Những quy định chung

## Điều 1. Phạm vi điều chỉnh và đối tượng áp dụng

1. Nghị định này quy định về chính sách hỗ trợ tiền đóng học phí, chi phí sinh hoạt đối với sinh viên học các ngành đào tạo giáo viên tại các đại học, học viện, trường đại học, trường cao đẳng được phép đào tạo giáo viên (sau đây gọi chung là cơ sở đào tạo giáo viên) thực hiện theo phương thức giao nhiệm vụ, đặt hàng hoặc đấu thầu và đào tạo theo nhu cầu xã hội.

2. Nghị định này áp dụng đối với:

a) Sinh viên học trình độ đại học, cao đẳng các ngành đào tạo giáo viên theo hình thức đào tạo chính quy, liên thông chính quy và sinh viên học văn bằng thứ 2 theo hình thức đào tạo chính quy trình độ đại học, cao đẳng các ngành đào tạo giáo viên **có kết quả học lực văn bằng thứ 1 đạt loại giỏi** (sau đây gọi chung là sinh viên sư phạm).

b) Ủy ban nhân dân tỉnh, thành phố trực thuộc trung ương (sau đây gọi chung là Ủy ban nhân dân cấp tỉnh) hoặc cơ quan trực thuộc được ủy quyền giao nhiệm vụ, đặt hàng hoặc đấu thầu đào tạo sinh viên sư phạm (sau đây gọi chung là cơ quan giao nhiệm vụ, đặt hàng hoặc đấu thầu); các cơ sở đào tạo giáo viên và các tổ chức, cá nhân có nhu cầu đào tạo.

3. Nghị định này không áp dụng đối với giáo viên được cử đi đào tạo, bồi dưỡng để nâng trình độ chuẩn được đào tạo theo quy định tại Nghị định số 71/2020/NĐ-CP ngày 30 tháng 6 năm 2020 của Chính phủ quy định lộ trình thực hiện nâng trình độ chuẩn được đào tạo của giáo viên mầm non, tiểu học, trung học cơ sở.

## Điều 2. Giải thích từ ngữ

Trong Nghị định này, các từ ngữ dưới đây được hiểu như sau:

### 1. Số tháng làm tròn khi tính thời gian làm việc trong ngành giáo dục được xác định như sau: số ngày làm việc trong tháng từ 15 ngày trở lên được tính là một tháng.

### 2. Sinh viên sư phạm sau khi tốt nghiệp công tác trong ngành giáo dục, bao gồm:

a) Giáo viên, giảng viên làm nhiệm vụ giảng dạy, nghiên cứu hoặc chuyên môn, viên chức làm công tác quản lý trong các cơ sở giáo dục thuộc hệ thống giáo dục quốc dân, các cơ sở giáo dục khác được cấp có thẩm quyền cho phép thành lập, các cơ quan nghiên cứu khoa học về giáo dục và

đào tạo;

b) Công chức, viên chức làm việc tại các cơ quan quản lý nhà nước về giáo dục theo quy định của Nghị định quy định trách nhiệm quản lý nhà nước về giáo dục.

### 3. Thẩm quyền xác nhận thời gian làm việc trong ngành giáo dục là thủ trưởng các cơ quan, đơn vị quy định tại khoản 2 Điều này.

## Điều 3. Xác định nhu cầu đào tạo, giao nhiệm vụ, đặt hàng hoặc đấu thầu

### 1. Hằng năm, Ủy ban nhân dân cấp tỉnh rà soát tính toán và xác định nhu cầu tuyển dụng và đào tạo giáo viên tại địa phương của từng trình độ, cấp học, ngành học, môn học cho năm tuyển sinh gửi Bộ Giáo dục và Đào tạo trước ngày 31 tháng 01 hằng năm và công khai trên các phương tiện thông tin, truyền thông.

Trên cơ sở nhu cầu tuyển dụng giáo viên theo trình độ, ngành đào tạo của địa phương và nhu cầu xã hội, điều kiện bảo đảm chất lượng và năng lực đào tạo của cơ sở đào tạo giáo viên, Bộ Giáo dục và Đào tạo xác định và thông báo chỉ tiêu cho các cơ sở đào tạo giáo viên để thực hiện tuyển sinh.

2. Căn cứ chỉ tiêu được Bộ Giáo dục và Đào tạo thông báo, cơ sở đào tạo giáo viên thông báo công khai rộng rãi cho các địa phương, tổ chức, cá nhân có nhu cầu đào tạo giáo viên và thông báo lên Cổng thông tin điện tử của Bộ Giáo dục và Đào tạo, trang thông tin điện tử của cơ sở đào tạo giáo viên.

### 3. Căn cứ vào chỉ tiêu được thông báo của các cơ sở đào tạo giáo viên và nhu cầu đào tạo giáo viên của địa phương, cơ quan giao nhiệm vụ, đặt hàng hoặc đấu thầu có nhu cầu quyết định thực hiện giao nhiệm vụ, đặt hàng hoặc đấu thầu đào tạo giáo viên với cơ sở đào tạo giáo viên theo một trong các hình thức sau:

a) Thực hiện giao nhiệm vụ đào tạo giáo viên cho cơ sở đào tạo giáo viên trực thuộc;

b) Đặt hàng đào tạo giáo viên cho cơ sở đào tạo giáo viên;

c) Đấu thầu lựa chọn cơ sở đào tạo giáo viên cung cấp dịch vụ đào tạo giáo viên.

### 4. Quyết định giao nhiệm vụ, hợp đồng đào tạo giáo viên giữa cơ quan giao nhiệm vụ, đặt hàng hoặc đấu thầu với các cơ sở đào tạo giáo viên phải căn cứ trên cơ sở nhu cầu và kế hoạch đào tạo giáo viên theo từng năm, phù hợp với lộ trình kế hoạch phát triển giáo dục, kế hoạch đào tạo đội ngũ giáo viên hằng năm và dài hạn của địa phương.

5. Đơn giá thực hiện giao nhiệm vụ, đặt hàng hoặc đấu thầu đào tạo giáo viên được xác định theo quy định tại Điều 4 Nghị định này.

### 6. Các quy định khác về giao nhiệm vụ, đặt hàng hoặc đấu thầu chưa được quy định cụ thể tại Nghị định này thì thực hiện theo quy định tại Nghị định số 32/2019/NĐ-CP ngày 10 tháng 4 năm 2019 của Chính phủ quy định giao nhiệm vụ, đặt hàng hoặc đấu thầu cung cấp sản phẩm, dịch vụ công sử dụng ngân sách nhà nước.

## Chương II — Chính sách hỗ trợ học phí, chi phí sinh hoạt và bồi hoàn kinh phí hỗ trợ

## Điều 4. Mức hỗ trợ và thời gian hỗ trợ

### 1. Mức hỗ trợ:

a) Sinh viên sư phạm được nhà nước hỗ trợ tiền đóng học phí bằng mức thu học phí của cơ sở đào tạo giáo viên nơi theo học;

b) Sinh viên sư phạm được nhà nước hỗ trợ 3,63 triệu đồng/tháng để chi trả chi phí sinh hoạt trong thời gian học tập tại trường.

### 2. Thời gian hỗ trợ tiền đóng học phí và chi phí sinh hoạt được xác định theo số tháng thực tế học tập tại trường theo quy định, nhưng không quá 10 tháng/năm học. Trong trường hợp tổ chức giảng dạy theo học chế tín chỉ, cơ sở đào tạo giáo viên có thể quy đổi mức hỗ trợ cho phù hợp với học chế tín chỉ. Tổng kinh phí hỗ trợ của cả khóa học theo học chế tín chỉ không vượt quá mức hỗ trợ quy định cho khóa học theo năm học.

## Điều 5. Lập dự toán, chi trả kinh phí hỗ trợ

### 1. Lập dự toán:

a) Đối với sinh viên sư phạm đào tạo theo phương thức giao nhiệm vụ, đặt hàng hoặc đấu thầu (sau đây gọi chung là thuộc đối tượng giao nhiệm vụ, đặt hàng hoặc đấu thầu): Căn cứ vào nhu cầu đào tạo giáo viên của địa phương và các định mức hỗ trợ quy định tại Điều 4 Nghị định này, hằng năm cơ quan giao nhiệm vụ, đặt hàng hoặc đấu thầu lập dự toán kinh phí đào tạo giáo viên báo cáo cơ quan có thẩm quyền phê duyệt kinh phí để chi trả hỗ trợ tiền đóng học phí và chi phí sinh hoạt cho sinh viên sư phạm qua cơ sở đào tạo giáo viên;

b) Đối với sinh viên sư phạm đào tạo theo nhu cầu xã hội (không thuộc đối tượng giao nhiệm vụ, đặt hàng hoặc đấu thầu): Căn cứ vào số chỉ tiêu còn lại trong phạm vi chỉ tiêu của Bộ Giáo dục và Đào tạo thông báo sau khi trừ đi chỉ tiêu giao nhiệm vụ, đặt hàng hoặc đấu thầu, hằng năm cơ sở đào tạo giáo viên lập dự toán kinh phí và gửi cơ quan cấp trên tổng hợp báo cáo cơ quan tài chính bố trí dự toán theo quy định của Luật Ngân sách nhà nước. Kinh phí hỗ trợ tiền đóng học phí và chi phí sinh hoạt cho sinh viên sư phạm đào tạo theo nhu cầu xã hội được cấp cho cơ sở đào tạo giáo viên theo hình thức giao dự toán theo quy định.

### 2. Chi trả kinh phí hỗ trợ từ ngân sách nhà nước:

a) Kinh phí hỗ trợ tiền đóng học phí và chi phí sinh hoạt cho sinh viên sư phạm được bố trí trong dự toán ngân sách nhà nước hằng năm chi cho giáo dục, đào tạo tại các địa phương, bộ, ngành theo các quy định hiện hành;

b) Cơ quan giao nhiệm vụ, đặt hàng hoặc đấu thầu chi trả trực tiếp cho cơ sở đào tạo giáo viên kinh phí hỗ trợ tiền đóng học phí và chi phí sinh hoạt của sinh viên sư phạm theo cơ chế Nhà nước giao nhiệm vụ, đặt hàng hoặc đấu thầu đối với các sinh viên sư phạm thuộc đối tượng giao nhiệm vụ, đặt hàng hoặc đấu thầu.

Đối với kinh phí hỗ trợ tiền đóng học phí và chi phí sinh hoạt cho sinh viên sư phạm trong chỉ tiêu Bộ Giáo dục và Đào tạo thông báo nhưng không thuộc đối tượng giao nhiệm vụ, đặt hàng hoặc đấu thầu, được bố trí trong dự toán hằng năm của cơ sở đào tạo giáo viên được cấp có thẩm quyền giao theo quy định của Luật Ngân sách nhà nước;

c) Cơ sở đào tạo giáo viên có trách nhiệm chi trả tiền hỗ trợ chi phí sinh hoạt cho sinh viên sư phạm thông qua tài khoản tiền gửi của sinh viên tại ngân hàng.

### 3. Việc lập dự toán, chấp hành dự toán và thanh quyết toán kinh phí thực hiện chính sách hỗ trợ tiền đóng học phí, chi phí sinh hoạt đối với sinh viên sư phạm tại Nghị định này thực hiện theo quy định tại Luật Ngân sách nhà nước và các văn bản hướng dẫn thực hiện.

## Điều 6. Bồi hoàn kinh phí hỗ trợ

### 1. Đối tượng phải bồi hoàn kinh phí hỗ trợ tiền đóng học phí và chi phí sinh hoạt gồm:

a) Sinh viên sư phạm đã hưởng chính sách không công tác trong ngành giáo dục sau 02 năm kể từ ngày có quyết định công nhận tốt nghiệp;

b) Sinh viên sư phạm đã hưởng chính sách và công tác trong ngành giáo dục nhưng không đủ thời gian công tác theo quy định tại điểm a khoản 2 Điều này;

c) Sinh viên sư phạm được hưởng chính sách đang trong thời gian đào tạo nhưng chuyển sang ngành đào tạo khác, tự thôi học, không hoàn thành chương trình đào tạo hoặc bị kỷ luật buộc thôi học.

### 2. Đối tượng không phải bồi hoàn kinh phí hỗ trợ tiền đóng học phí và chi phí sinh hoạt gồm:

a) Trong thời hạn 02 năm kể từ ngày có quyết định công nhận tốt nghiệp, sinh viên sư phạm công tác trong ngành giáo dục và có thời gian công tác tối thiểu gấp hai lần thời gian đào tạo tính từ ngày được tuyển dụng;

b) Sinh viên sư phạm sau khi tốt nghiệp đang công tác trong ngành giáo dục, nhưng chưa đủ thời gian theo quy định tại điểm a khoản 2 Điều này và được cơ quan nhà nước có thẩm quyền điều động bố trí công tác ngoài ngành giáo dục;

c) Sinh viên sư phạm sau khi tốt nghiệp tiếp tục được cơ quan đặt hàng, giao nhiệm vụ hoặc đấu thầu cử đi đào tạo giáo viên trình độ cao hơn và tiếp tục công tác trong ngành giáo dục đủ thời gian quy định tại điểm a khoản 2 Điều này.

### 3. Sinh viên sư phạm nghỉ học tạm thời, bị đình chỉ học tập tạm thời sẽ không được hưởng chính sách hỗ trợ trong thời gian nghỉ học hoặc bị đình chỉ học.

### 4. Sinh viên sư phạm dừng học do ốm đau, tai nạn, học lại, lưu ban (không quá một lần) hoặc dừng học vì lý do khác không do kỷ luật hoặc tự thôi học, được cơ sở đào tạo giáo viên xem xét cho tiếp tục học tập theo quy định, thì tiếp tục được hưởng chính sách hỗ trợ quy định tại Nghị định này nhưng thời gian hưởng không vượt quá thời gian tối đa hoàn thành chương trình đào tạo.

## Điều 7. Thủ tục đăng ký hỗ trợ tiền đóng học phí và chi phí sinh hoạt

1. Hằng năm, căn cứ vào chỉ tiêu được Bộ Giáo dục và Đào tạo thông báo, cơ sở đào tạo giáo viên thông báo cho các thí sinh trúng tuyển vào các ngành đào tạo giáo viên để đăng ký theo đối tượng giao nhiệm vụ, đặt hàng hoặc đấu thầu hoặc đào tạo theo nhu cầu xã hội trong phạm vi chỉ tiêu được Bộ Giáo dục và Đào tạo thông báo.

2. Trong thời hạn 30 ngày kể từ ngày nhận được thông báo trúng tuyển, sinh viên sư phạm nộp Đơn đề nghị hưởng và cam kết bồi hoàn học phí, chi phí sinh hoạt đến cơ sở đào tạo giáo viên (Mẫu số 01 tại Phụ lục ban hành kèm theo Nghị định này) theo hình thức nộp trực tiếp hoặc qua bưu điện hoặc trực tuyến (nếu có).

Sinh viên chỉ nộp 01 bộ hồ sơ cho 01 lần đầu đề nghị hỗ trợ trong cả thời gian học tại cơ sở đào tạo giáo viên.

### 3. Các cơ sở đào tạo giáo viên tổng hợp và thông báo cho các địa phương đã giao nhiệm vụ, đặt hàng hoặc đấu thầu để thống nhất xét hỗ trợ cho sinh viên sư phạm thuộc đối tượng giao nhiệm vụ, đặt hàng hoặc đấu thầu.

### 4. Cơ quan giao nhiệm vụ, đặt hàng hoặc đấu thầu xây dựng tiêu chí tuyển chọn sinh viên sư phạm đã trúng tuyển, phối hợp với cơ sở đào tạo giáo viên xét chọn bảo đảm công bằng, công khai, minh bạch.

### 5. Trong thời hạn 15 ngày kể từ ngày kết thúc nhận đơn đăng ký, cơ sở đào tạo giáo viên thống nhất với cơ quan giao nhiệm vụ, đặt hàng hoặc đấu thầu để xác nhận và thông báo cho sinh viên sư phạm được hưởng chính sách hỗ trợ thuộc đối tượng giao nhiệm vụ, đặt hàng hoặc đấu thầu và xét duyệt các đối tượng hưởng chính sách hỗ trợ đối với sinh viên sư phạm trong phạm vi chỉ tiêu Bộ Giáo dục và Đào tạo thông báo và không thuộc chỉ tiêu đặt hàng.

6. Danh sách sinh viên sư phạm được hưởng chính sách hỗ trợ học phí và chi phí sinh hoạt được công khai trên trang thông tin điện tử của cơ sở đào tạo giáo viên đồng thời gửi cơ quan giao nhiệm vụ, đặt hàng hoặc đấu thầu để thực hiện.

## Điều 8. Chi phí bồi hoàn và cách tính chi phí bồi hoàn

### 1. Chi phí bồi hoàn bao gồm kinh phí hỗ trợ tiền đóng học phí và chi phí sinh hoạt đã được ngân sách nhà nước hỗ trợ cho người học.

### 2. Sinh viên sư phạm thuộc đối tượng quy định tại điểm a và điểm c khoản 1 Điều 6 của Nghị định này phải bồi hoàn toàn bộ kinh phí đã được ngân sách nhà nước hỗ trợ.

### 3. Sinh viên sư phạm thuộc đối tượng quy định tại điểm b khoản 1 Điều 6 của Nghị định này phải bồi hoàn một phần kinh phí hỗ trợ. Cách tính chi phí bồi hoàn theo công thức sau:

$$S = (F / T1) \times (T1 - T2)$$

Trong đó:

- S là chi phí bồi hoàn;
- F là khoản học phí và chi phí sinh hoạt được nhà nước hỗ trợ;
- T1 là tổng thời gian làm việc trong ngành giáo dục theo quy định tính bằng số tháng làm tròn;
- T2 là thời gian đã làm việc trong ngành giáo dục được tính bằng số tháng làm tròn.

## Điều 9. Thu hồi chi phí bồi hoàn

1. Hằng năm, căn cứ vào kết quả rèn luyện, học tập của sinh viên sư phạm, cơ sở đào tạo giáo viên thông báo danh sách sinh viên thuộc đối tượng quy định tại điểm c khoản 1 Điều 6 Nghị định này cho Ủy ban nhân dân cấp tỉnh để thông báo thu hồi kinh phí đã hỗ trợ cho sinh viên sư

phạm và gia đình theo quy định tại khoản 2 Điều 8 Nghị định này.

### 2. Đối với sinh viên sư phạm thuộc đối tượng phải bồi hoàn kinh phí theo quy định tại điểm a và điểm b khoản 1 Điều 6 Nghị định này, Ủy ban nhân dân cấp tỉnh ra thông báo thu hồi kinh phí hỗ trợ để sinh viên sư phạm hoặc gia đình thực hiện nộp trả đầy đủ khoản tiền phải bồi hoàn theo quy định tại Điều 8 Nghị định này.

### 3. Trong thời hạn 30 ngày, kể từ ngày nhận được quyết định của cơ quan nhà nước có thẩm quyền, sinh viên hoặc gia đình phải có trách nhiệm liên hệ với cơ quan thu hồi kinh phí bồi hoàn để làm thủ tục bồi hoàn.

Thời hạn phải thực hiện nghĩa vụ bồi hoàn kinh phí hỗ trợ tối đa là 4 năm, kể từ khi sinh viên sư phạm nhận được thông báo bồi hoàn kinh phí.

Trường hợp sinh viên hoặc gia đình chậm thực hiện nghĩa vụ bồi hoàn quá thời hạn quy định thì phải chịu lãi suất tối đa áp dụng đối với tiền gửi không kỳ hạn do Ngân hàng Nhà nước Việt Nam quy định đối với khoản tiền chậm bồi hoàn. Trường hợp Ngân hàng Nhà nước không quy định lãi suất tối đa áp dụng đối với tiền gửi không kỳ hạn thì phải chịu lãi suất áp dụng đối với tiền gửi không kỳ hạn của Ngân hàng Thương mại cổ phần Công thương Việt Nam tại thời điểm thực hiện nghĩa vụ bồi hoàn.

### 4. Sinh viên sư phạm phải bồi hoàn kinh phí theo quy định tại khoản 1 Điều 6 Nghị định này, nếu thuộc đối tượng chính sách, khó khăn thì căn cứ vào điều kiện cụ thể, đặc thù của sinh viên sư phạm, Ủy ban nhân dân cấp tỉnh quyết định phương thức thu hồi, chính sách miễn, giảm hoặc xóa kinh phí bồi hoàn.

### 5. Số tiền thu hồi từ chi phí bồi hoàn của sinh viên sư phạm được nộp vào ngân sách nhà nước theo phân cấp quản lý ngân sách hiện hành và theo quy định của Luật Ngân sách nhà nước về quản lý khoản thu hồi nộp ngân sách.

### 6. Sinh viên sư phạm hoặc gia đình không thực hiện nghĩa vụ bồi hoàn thì cơ quan thu hồi kinh phí bồi hoàn có quyền khởi kiện tại Tòa án theo quy định pháp luật.

## Chương III — Tổ chức thực hiện

## Điều 10. Trách nhiệm của các bộ, ngành
### 1. Bộ Giáo dục và Đào tạo:
a) Chủ trì, phối hợp với các bộ, ngành liên quan chỉ đạo, hướng dẫn các địa phương triển khai thực hiện các nội dung quy định tại Nghị định này;
b) Xác định và thông báo chỉ tiêu tuyển sinh đối với các ngành đào tạo giáo viên cho các cơ sở đào tạo giáo viên;
c) Tổ chức kiểm tra, đánh giá việc thực hiện Nghị định này đối với các cơ sở đào tạo giáo viên theo quy định;
d) Chỉ đạo các cơ sở đào tạo giáo viên phối hợp với Ủy ban nhân dân cấp tỉnh, các bộ, ngành liên quan thực hiện chính sách hỗ trợ cho sinh viên sư phạm hiệu quả.

### 2. Các bộ, ngành liên quan: Trong phạm vi chức năng, nhiệm vụ được giao phối hợp với Bộ Giáo dục và Đào tạo triển khai thực hiện các nội dung quy định tại Nghị định này.

## Điều 11. Trách nhiệm của Ủy ban nhân dân cấp tỉnh
### 1. Hằng năm, căn cứ thực trạng thừa thiếu giáo viên để xác định nhu cầu đào tạo, bố trí ngân sách thực hiện giao nhiệm vụ, đặt hàng hoặc đấu thầu với cơ sở đào tạo giáo viên, xây dựng tiêu chí tuyển chọn sinh viên sư phạm phù hợp nhu cầu sử dụng.

### 2. Thực hiện công khai nhu cầu đào tạo giáo viên, kết quả giao nhiệm vụ, đặt hàng hoặc đấu thầu với các cơ sở đào tạo giáo viên, kế hoạch tuyển dụng và bố trí vị trí việc làm trong các cơ sở giáo dục.

3. Chi trả kinh phí thực hiện quyết định giao nhiệm vụ, hợp đồng đào tạo giáo viên với các cơ sở đào tạo giáo viên theo đúng định mức quy định tại Điều 4 Nghị định này.

### 4. Chỉ đạo, hướng dẫn tổ chức thực hiện chính sách hỗ trợ sinh viên sư phạm theo quy định

của Nghị định này tại địa phương; kiểm tra, giám sát việc thực hiện và báo cáo tình hình thực hiện định kỳ hằng năm với Bộ Giáo dục và Đào tạo, Bộ Tài chính.

### 5. Thực hiện hoặc phân cấp thực hiện việc tuyển dụng sinh viên sư phạm tốt nghiệp thuộc đối tượng giao nhiệm vụ, đặt hàng hoặc đấu thầu và bố trí vị trí việc làm phù hợp với chuyên ngành đào tạo trong các cơ sở giáo dục theo quy định hiện hành về tuyển dụng, sử dụng viên chức.

### 6. Hướng dẫn thủ tục theo dõi, đôn đốc và thu hồi tiền bồi hoàn kinh phí hỗ trợ tiền đóng học phí, chi phí sinh hoạt đối với các trường hợp phải bồi hoàn theo quy định tại khoản 1 Điều 6 Nghị định này và xử lý các trường hợp không thực hiện việc bồi hoàn theo quy định của pháp luật.

### 7. Hằng năm, báo cáo kết quả thực hiện quyết định giao nhiệm vụ, hợp đồng đào tạo giáo viên, kinh phí hỗ trợ, tình hình tuyển dụng giáo viên của địa phương với Bộ Giáo dục và Đào tạo, Bộ Tài chính.

## Điều 12. Trách nhiệm của cơ sở đào tạo giáo viên

### 1. Căn cứ chỉ tiêu đào tạo được thông báo, thực hiện tuyển sinh, đào tạo giáo viên theo đúng quy định hiện hành.

### 2. Thực hiện đầy đủ các chế độ, chính sách đối với sinh viên sư phạm theo quy định.

### 3. Định kỳ hằng năm thông báo cho cơ quan thu hồi kinh phí bồi hoàn về kết quả học tập, rèn luyện và thời gian tốt nghiệp của sinh viên sư phạm, danh sách sinh viên đang học tại trường vi phạm phải bồi hoàn kinh phí hỗ trợ tiền đóng học phí và chi phí sinh hoạt theo quy định tại khoản 1 Điều 6 Nghị định này.

4. Có trách nhiệm công khai mức thu học phí theo từng năm học và học phí dự kiến cả khoá học, chi phí đào tạo, chuẩn đầu ra, kết quả học tập, tổ chức tuyển chọn và thực hiện đào tạo giáo viên theo phương thức giao nhiệm vụ, đặt hàng, đấu thầu với địa phương có nhu cầu theo quy định.

5. Thực hiện thanh quyết toán kinh phí đào tạo giáo theo quy định.

### 6. Bảo đảm chất lượng đào tạo và chịu trách nhiệm trước cơ quan quản lý cấp trên về chất lượng đào tạo do đơn vị thực hiện.

### 7. Định kỳ hằng năm báo cáo kết quả đào tạo, kinh phí hỗ trợ đào tạo giáo viên với Bộ Giáo dục và Đào tạo, Bộ Tài chính.

## Điều 13. Trách nhiệm của gia đình và người được cử đi đào tạo

### 1. Chấp hành các quy định của pháp luật và nội quy, quy chế của các cơ sở đào tạo giáo viên; hoàn thành chương trình đào tạo theo ngành được cử đi học.

Sau khi tốt nghiệp, sinh viên thông báo cho cơ quan giao nhiệm vụ, đặt hàng hoặc đấu thầu về kết quả học tập để được tư vấn, hỗ trợ về định hướng việc làm trong ngành giáo dục theo quy định tại khoản 2 Điều 2 Nghị định này.

### 2. Sau khi có quyết định công nhận tốt nghiệp, định kỳ trước ngày 31 tháng 12 hằng năm của năm tiếp theo cho đến năm đủ thời gian không phải thực hiện nghĩa vụ bồi hoàn kinh phí hỗ trợ quy định tại điểm a khoản 2 Điều 6, báo cáo tình hình việc làm của bản thân (Mẫu số 02 tại Phụ lục ban hành kèm theo Nghị định này) tới cơ quan thu hồi kinh phí bồi hoàn để thông báo xóa hoặc thu hồi khoản kinh phí hỗ trợ.

### 3. Sinh viên sư phạm thuộc đối tượng quy định tại khoản 1 Điều 6 Nghị định này hoặc gia đình có trách nhiệm nộp trả kinh phí đã được hỗ trợ cho cơ quan thu hồi kinh phí bồi hoàn theo quy định tại Điều 9 Nghị định này để nộp trả ngân sách nhà nước.

**Chương IV**
**ĐIỀU KHOẢN THI HÀNH**

## Điều 14. Quy định chuyển tiếp

Sinh viên sư phạm đã trúng tuyển và đào tạo từ năm học 2020 - 2021 trở về trước thì tiếp tục thực hiện theo quy định tại Điều 6 của Nghị định số 86/2015/NĐ-CP ngày 02 tháng 10 năm 2015 của Chính phủ quy định về cơ chế thu, quản lý học phí đối với cơ sở giáo dục thuộc hệ thống giáo dục quốc dân và chính sách miễn, giảm học phí, hỗ trợ chi phí học tập từ năm học 2015 - 2016 đến năm học 2020 - 2021 cho đến khi tốt nghiệp.

## Điều 15. Hiệu lực và trách nhiệm thi hành

1. Nghị định này có hiệu lực thi hành từ ngày 15 tháng 11 năm 2020 và áp dụng bắt đầu từ khóa tuyển sinh năm học 2021 - 2022.

### 2. Các Bộ trưởng, Thủ trưởng cơ quan ngang bộ, Thủ trưởng cơ quan thuộc Chính phủ, Chủ tịch Ủy ban nhân dân tỉnh, thành phố trực thuộc trung ương và các cơ quan, tổ chức liên quan chịu trách nhiệm thi hành Nghị định này./.

| Nơi nhận:                                               |                  | TM. CHÍNH PHỦ |
| ------------------------------------------------------- | ---------------- | ------------- |
| - Ban Bí thư Trung ương Đảng;                           | THỦ TƯỚNG        |               |
| - Thủ tướng, các Phó Thủ tướng Chính phủ;               |                  |               |
| - Các bộ, cơ quan ngang bộ, cơ quan thuộc Chính phủ;    |                  |               |
| - HĐND, UBND các tỉnh, thành phố trực thuộc trung ương; |                  |               |
| - Văn phòng Trung ương và các Ban của Đảng;             |                  |               |
| - Văn phòng Tổng Bí thư;                                | Nguyễn Xuân Phúc |               |
| - Văn phòng Chủ tịch nước;                              |                  |               |
| - Hội đồng Dân tộc và các Ủy ban của Quốc hội;          |                  |               |
| - Văn phòng Quốc hội;                                   |                  |               |
| - Tòa án nhân dân tối cao;                              |                  |               |
| - Viện kiểm sát nhân dân tối cao;                       |                  |               |
| - Ủy ban Giám sát tài chính Quốc gia;                   |                  |               |
| - Kiểm toán Nhà nước;                                   |                  |               |
| - Ngân hàng Chính sách xã hội;                          |                  |               |
| - Ngân hàng Phát triển Việt Nam;                        |                  |               |
| - Ủy ban Trung ương Mặt trận Tổ quốc Việt Nam;          |                  |               |
| - Cơ quan trung ương của các đoàn thể;                  |                  |               |
| - VPCP: BTCN, các PCN, Trợ lý TTg, TGĐ Cổng TTĐT, các   |                  |               |
| Vụ, Cục, đơn vị trực thuộc, Công báo;                   |                  |               |
| - Lưu: VT, KGVX (2b).                                   |                  |               |

**Phụ lục**
*(Kèm theo Nghị định số 116/2020/NĐ-CP ngày 25 tháng 9 năm 2020 của Chính phủ)*
***

| Mẫu số 01 | Đơn đề nghị hưởng và cam kết bồi hoàn học phí, chi phí sinh hoạt |
| --------- | ---------------------------------------------------------------- |
| Mẫu số 02 | Giấy xác nhận thời gian công tác trong ngành giáo dục            |

**Mẫu số 01**

\________________________

*(Lưu ý: Mẫu đơn đính kèm đã được ẩn để tối ưu dữ liệu, sinh viên vui lòng xem file gốc)*
