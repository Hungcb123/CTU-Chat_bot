1

<!-- page: 1 -->

BỘ GIÁO DỤC VÀ ĐÀO TẠO
**TRƯỜNG ĐẠI HỌC CẦN THƠ**

**CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**
**Độc lập - Tự do - Hạnh phúc**

Số: 3627/QĐ-ĐHCT *Cần Thơ, ngày 27 tháng 10 năm 2020*

# QUYẾT ĐỊNH

## Về mục tiêu giáo dục của Trường Đại học Cần Thơ

### HIỆU TRƯỞNG TRƯỜNG ĐẠI HỌC CẦN THƠ

Căn cứ Luật Giáo dục đại học số 08/2012/QH13 ngày 18 tháng 6 năm 2012 của Quốc hội và Luật số 34/2018/QH14 ngày 19 tháng 11 năm 2018 của Quốc hội sửa đổi, bổ sung một số điều của Luật Giáo dục đại học;

Căn cứ Nghị định số 43/2006/NĐ-CP ngày 25 tháng 4 năm 2006 của Chính phủ quy định quyền tự chủ, tự chịu trách nhiệm về thực hiện nhiệm vụ, tổ chức bộ máy, biên chế và tài chính đối với đơn vị sự nghiệp công lập;

Trên cơ sở nội dung kết luận về mục tiêu giáo dục của Trường Đại học Cần Thơ tại Biên bản họp số 2526/BB-ĐHCT-HĐKHĐT ngày 20 tháng 10 năm 2020 của Hội đồng Khoa học và Đào tạo;

Theo đề nghị của ông Giám đốc Trung tâm Quản lý Chất lượng.

# QUYẾT ĐỊNH:

#### Điều 1. Mục tiêu giáo dục của Trường Đại học Cần Thơ được thực hiện theo mục tiêu của giáo dục đại học được quy định tại Điều 39 của Luật Giáo dục năm 2019 với nội dung như sau:

***“Đào tạo nhân lực trình độ cao, nâng cao dân trí, bồi dưỡng nhân tài; nghiên cứu khoa học và công nghệ tạo ra tri thức, sản phẩm mới, phục vụ nhu cầu phát triển kinh tế - xã hội, bảo đảm quốc phòng, an ninh, hội nhập quốc tế.***

***Đào tạo người học phát triển toàn diện về đức, trí, thể, mỹ; có tri thức, kỹ năng, trách nhiệm nghề nghiệp; có khả năng nắm bắt tiến bộ khoa học và công nghệ tương ứng với trình độ đào tạo, khả năng tự học, sáng tạo, thích nghi với môi trường làm việc; có tinh thần lập nghiệp, có ý thức phục vụ Nhân dân.”***

#### Điều 2. Mục tiêu giáo dục được sử dụng nhằm định hướng thiết kế các hoạt động dạy và học phù hợp, thúc đẩy việc rèn luyện các kỹ năng và nâng cao khả năng học tập suốt đời của người học.

#### Điều 3. Quyết định này có hiệu lực thi hành kể từ ngày ký. Các ông (bà) thủ trưởng các đơn vị: Phòng Đào tạo, Khoa Sau Đại học, Trung tâm Liên Kết Đào tạo, Trung tâm Quản lý chất lượng, các đơn vị đào tạo cùng các đơn vị và cá nhân có liên quan khác trong trường chịu trách nhiệm thi hành quyết định này./. [signature]

**Nơi nhận:**
- Như Điều 3;
- Lưu: VT, QLCL.

**HIỆU TRƯỞNG** [signature]
Seal of Can Tho University with signature of Ha Thanh Toan
**Hà Thanh Toàn**
