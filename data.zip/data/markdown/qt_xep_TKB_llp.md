1

<!-- page: 1 -->

# QUY TRÌNH PHỐI HỢP XẾP THỜI KHÓA BIỂU HỌC KỲ

## I. QUY TRÌNH CÔNG TÁC:

### 1. Cơ sở thực hiện:

Quy trình này bắt đầu khi kết thúc thời gian nhập kế hoạch học tập của sinh viên.

**Mục đích, phạm vi áp dụng:**

* Lập kế hoạch giảng dạy từng học kỳ.
* Đảm bảo đáp ứng nhu cầu học tập của sinh viên.
* Đảm bảo tính hợp lý thời khóa biểu của giảng viên.
* Đảm bảo tổ chức giảng dạy tốt các học phần và các lớp đặc biệt.
* Áp dụng cho các bộ môn quản lý học phần.

**Yêu cầu và các văn bản quy định:**

* Lập kế hoạch mở lớp đúng với nhu cầu của sinh viên đã nhập trong KHHT.
* Xếp thời khóa biểu hợp lý cho từng giảng viên, đảm bảo cho giảng viên có thể giảng dạy cho nhiều hệ đào tạo khác nhau.
* Đảm bảo cho việc giảng dạy các lớp đặc biệt thực hiện tốt không mâu thuẫn.
* Mỗi học kỳ chính có 15 tuần, học kỳ 3 có 5 tuần (trừ các tuần nghỉ Lễ, Tết,...).
* Tùy theo điều kiện của đơn vị, khuyến khích hạn chế xếp TKB vào thứ bảy.
* Không xếp Thời khóa biểu vào tiết 9 ngày thứ bảy.
* Quy định về công tác học vụ đang áp dụng.

**Giải thích từ ngữ, viết tắt.**

* SV : Sinh viên
* CTĐT : Chương trình đào tạo
* KHHT : Kế hoạch học tập
* TKB : Thời khóa biểu
* GV : Giảng viên
* PĐT : Phòng Đào tạo
* BM : Bộ môn

### 2. Nội dung quy trình:

* PĐT công bố kế hoạch phối hợp xếp thời khoá biểu đến các đơn vị.
* Các đơn vị xây dựng CTĐT học kỳ đối với các lớp có kế hoạch học tập ưu tiên (Năm thứ nhất, các lớp học Giáo dục quốc phòng an ninh, Thực tập sư phạm, Kiến tập sư phạm, Thực tập thực tế,...).
* PĐT xếp TKB các lớp ưu tiên.
* Các Khoa phối hợp với PĐT xếp thời khóa biểu học kỳ đối với các học phần do đơn vị quản lý.
* PĐT kiểm tra tính hợp lý TKB của các đơn vị.
* PĐT công bố lịch giảng cho GV điều chỉnh.
* PĐT công bố TKB chính thức cho SV đăng ký học phần trên Hệ thống quản lý.

---

2

<!-- page: 2 -->

## II. LƯU ĐỒ:

| Quy trình phối hợp xếp thời khóa biểu học kỳ / Bước | Quy trình phối hợp xếp thời khóa biểu học kỳ / Lưu đồ | Quy trình phối hợp xếp thời khóa biểu học kỳ / Nội dung công việc     | Quy trình phối hợp xếp thời khóa biểu học kỳ / Người thực hiện | Quy trình phối hợp xếp thời khóa biểu học kỳ / Thời gian thực hiện | Quy trình phối hợp xếp thời khóa biểu học kỳ / Ghi chú |
| -------------------------------------------------------------- | ----------------------------------------------------------------- | --------------------------------------------------------------------------------- | --------------------------------------------------------------------------- | ------------------------------------------------------------------------------ | ---------------------------------------------------------------- |
| 1                                                              | PĐT công bố kế hoạch phối hợp                              | Ban hành công văn qui định thời gian và các công việc phối hợp        | PĐT                                                                        | Trước khi tổ chức đăng ký học phần cho SV2 tháng                     |                                                                  |
| 2                                                              | BM gửi kế hoạch đào tạo học kỳ                            | Xây dựng CTĐT học kỳ đối với các lớp có kế hoạch học tập ưu tiên | BM quản lý chuyên ngành                                                 | Trước khi tổ chức đăng ký học phần cho SV2 tháng                     |                                                                  |
| 3                                                              | Tiếp nhận và xếp TKB                                          | Xếp TKB các lớp ưu tiên                                                      | PĐT                                                                        | 4 tuần                                                                        |                                                                  |
| 4                                                              | Các đơn vị xếp TKB                                           | Xếp TKB học kỳ của đơn vị                                                  | Các đơn vị quản lý học phần                                         | 2 tuần                                                                        |                                                                  |
| 5                                                              | Kiểm tra                                                         | Kiểm tra tính hợp lý TKB của các đơn vị                                  | PĐT                                                                        | 1 tuần                                                                        |                                                                  |
| 6                                                              | Điều chỉnh TKB                                                 | Công bố lịch giảng dự kiến cho cán bộ giảng dạy để điều chỉnh      | - GV- PĐT                                                                  | 2 tuần                                                                        |                                                                  |
| 7                                                              | Công bố lớp HP mở trong HK                                    | Công bố TKB đăng ký học phần trên Hệ thống quản lý                    | PĐT                                                                        | Trước khi bắt đầu đăng ký học phần1 tuần                            |                                                                  |
