# Quyết định 29/2025/QĐ-TTg — Tín dụng cho người học ngành khoa học, công nghệ, kỹ thuật và toán — Năm 2025

*Hà Nội, ngày 28 tháng 8 năm 2025*


## Về tín dụng đối với học sinh, sinh viên, học viên thạc sĩ, nghiên cứu sinh học các ngành khoa học, công nghệ, kỹ thuật và toán

*Căn cứ Luật Tổ chức Chính phủ số 63/2025/QH15;*

*Căn cứ Luật Tổ chức chính quyền địa phương số 72/2025/QH15;*

*Căn cứ Luật Các tổ chức tín dụng số 32/2024/QH15 được sửa đổi, bổ sung bởi Luật số 43/2024/QH15;*

*Căn cứ Nghị định số 78/2002/NĐ-CP ngày 04 tháng 10 năm 2002 của Chính phủ về tín dụng đối với người nghèo và các đối tượng chính sách khác;*

*Theo đề nghị của Bộ trưởng Bộ Tài chính;*

*Thủ tướng Chính phủ ban hành Quyết định về tín dụng đối với học sinh, sinh viên, học viên thạc sĩ, nghiên cứu sinh học các ngành khoa học, công nghệ, kỹ thuật và toán.*

## Điều 1. Phạm vi điều chỉnh

### 1. Quyết định này quy định về chính sách tín dụng đối với học sinh, sinh viên, học viên thạc sĩ, nghiên cứu sinh học các ngành khoa học, công nghệ, kỹ thuật và toán để hỗ trợ trang trải học phí, sinh hoạt phí và chi phí học tập khác trong thời gian theo học tại các cơ sở giáo dục đại học, cơ sở giáo dục nghề nghiệp thuộc hệ thống giáo dục quốc dân được thành lập và hoạt động theo quy định của pháp luật Việt Nam.

### 2. Các ngành khoa học, công nghệ, kỹ thuật và toán quy định tại Quyết định này bao gồm các ngành, lĩnh vực đào tạo cụ thể sau: khoa học sự sống, khoa học tự nhiên, máy tính và công nghệ thông tin, công nghệ kỹ thuật, kỹ thuật, kiến trúc và xây dựng, sản xuất và chế biến, toán và thống kê, công nghệ tài chính theo quy định của Thủ tướng Chính phủ về việc ban hành Danh mục giáo dục, đào tạo của hệ thống giáo dục quốc dân và các văn bản quy phạm pháp luật hướng dẫn liên quan; các ngành đào tạo công nghệ then chốt khác theo quy định của pháp luật.
## Điều 2. Đối tượng áp dụng

### 1. Ngân hàng Chính sách xã hội.

### 2. Khách hàng vay vốn theo quy định tại Quyết định này.

### 3. Các tổ chức, cá nhân khác có liên quan.

## Điều 3. Đối tượng vay vốn

Học sinh, sinh viên, học viên thạc sĩ, nghiên cứu sinh là công dân Việt Nam đang theo học các ngành khoa học, công nghệ, kỹ thuật và toán theo quy định tại Quyết định này tại các cơ sở giáo dục đại học, cơ sở giáo dục nghề nghiệp thuộc hệ thống giáo dục quốc dân được thành lập và hoạt động theo quy định của pháp luật Việt Nam (sau đây gọi chung là người học).

## Điều 4. Điều kiện vay vốn

### 1. Học sinh, sinh viên phải tốt nghiệp trung học phổ thông theo quy định của pháp luật và đáp ứng điều kiện sau tại thời điểm Ngân hàng Chính sách xã hội xem xét, quyết định phê duyệt cho vay vốn theo quy định tại Quyết định này:

a) Đối với học sinh, sinh viên năm thứ nhất: Có đồng thời cả ba năm học trung học phổ thông (3 năm) được đánh giá kết quả học tập đạt từ mức khá trở lên theo quy định của pháp luật; hoặc đạt điểm trung bình môn năm lớp 12 của các môn toán, vật lí, hóa học, sinh học từ 8 điểm trở lên;

b) Đối với học sinh, sinh viên từ năm thứ hai trở đi: Có kết quả học tập trung bình các môn học đạt loại giỏi trở lên theo quy định của pháp luật tại năm trước liền kề với năm đề nghị Ngân hàng Chính sách xã hội cho vay vốn.

### 2. Học viên thạc sĩ, nghiên cứu sinh được các cơ sở giáo dục đại học công nhận là học viên thạc sĩ, nghiên cứu sinh theo quy định của pháp luật.

### 3. Tại thời điểm đề nghị Ngân hàng Chính sách xã hội cho vay vốn, người học phải điền Tờ khai thông tin theo mẫu quy định tại Phụ lục I Quyết định này, xin xác nhận của cơ sở giáo dục đại học, cơ sở giáo dục nghề nghiệp và cung cấp đầy đủ hồ sơ, tài liệu có liên quan cho Ngân hàng Chính sách xã hội.

### 4. Hằng năm, người học phải điền Tờ khai thông tin theo mẫu quy định tại Phụ lục II Quyết định này, xin xác nhận của cơ sở giáo dục đại học, cơ sở giáo dục nghề nghiệp và cung cấp cho Ngân hàng Chính sách xã hội làm căn cứ để giải ngân vốn vay.

## Điều 5. Mục đích sử dụng vốn vay

Khách hàng vay vốn để trang trải học phí, sinh hoạt phí và chi phí học tập khác trong thời gian theo học các ngành khoa học, công nghệ, kỹ thuật và toán quy định tại Quyết định này.
## Điều 6. Phương thức cho vay

### 1. Ngân hàng Chính sách xã hội thực hiện cho vay thông qua hộ gia đình. Đại diện hộ gia đình của người học là người đứng tên vay vốn và giao dịch với Ngân hàng Chính sách xã hội.

### 2. Trường hợp hộ gia đình không còn thành viên nào từ đủ 18 tuổi trở lên hoặc thành viên còn lại không có khả năng lao động hoặc không có năng lực hành vi dân sự đầy đủ theo quy định của pháp luật, người học trực tiếp đứng tên vay vốn tại Ngân hàng Chính sách xã hội.

## Điều 7. Mức vốn cho vay

### 1. Mức vốn cho vay tối đa đối với 01 người học để hỗ trợ trang trải tiền học phí, tiền sinh hoạt phí và chi phí học tập khác trong thời gian còn lại của khóa học, bao gồm:

a) Toàn bộ tiền học phí phải đóng của người học (sau khi trừ các khoản học bổng và hỗ trợ tài chính khác của nhà trường nếu có) theo xác nhận của nhà trường;

b) Tiền sinh hoạt phí và chi phí học tập khác tối đa là 5 triệu đồng/tháng.

### 2. Căn cứ vào quy định tại khoản 1 Điều này, Ngân hàng Chính sách xã hội thỏa thuận thống nhất với khách hàng vay vốn để xem xét, quyết định mức vốn cho vay cụ thể đối với từng người học.

## Điều 8. Lãi suất cho vay

### 1. Lãi suất cho vay là 4,8%/năm.

### 2. Lãi suất nợ quá hạn được tính bằng 130% lãi suất khi cho vay.

## Điều 9. Đồng tiền cho vay và trả nợ

Đồng tiền cho vay và trả nợ là đồng Việt Nam.

## Điều 10. Thời hạn cho vay

### 1. Thời hạn cho vay bao gồm: thời hạn giải ngân vốn vay, thời gian kể từ ngày người học kết thúc khóa học đến khi bắt đầu trả khoản nợ vay đầu tiên và thời hạn trả nợ.

### 2. Thời hạn giải ngân vốn vay là khoảng thời gian tính từ ngày khách hàng vay vốn nhận khoản vay đầu tiên cho đến ngày người học kết thúc khóa học, kể cả thời gian người học được các trường cho phép nghỉ học tạm thời và được bảo lưu kết quả học tập (nếu có):
a) Thời hạn giải ngân vốn vay được chia thành các kỳ hạn giải ngân vốn vay do Ngân hàng Chính sách xã hội quy định hoặc thỏa thuận với khách hàng vay vốn;

b) Ngân hàng Chính sách xã hội không giải ngân vốn vay trong thời gian người học được các trường cho phép nghỉ học tạm thời và được bảo lưu kết quả học tập (nếu có);

c) Trong thời hạn giải ngân vốn vay, khách hàng vay vốn chưa phải trả nợ gốc và lãi.

### 3. Kể từ ngày người học kết thúc khóa học 12 tháng theo quy định, khách hàng vay vốn phải trả nợ gốc và lãi tiền vay lần đầu tiên. Khách hàng vay vốn có thể trả nợ trước hạn mà không chịu lãi phạt trả nợ trước hạn.

### 4. Thời hạn trả nợ do Ngân hàng Chính sách xã hội quyết định, tối đa bằng thời hạn giải ngân vốn vay trừ đi thời gian người học được các trường cho phép nghỉ học tạm thời và được bảo lưu kết quả học tập (nếu có). Thời hạn trả nợ được chia thành các kỳ hạn trả nợ với mức trả nợ mỗi kỳ do Ngân hàng Chính sách xã hội quyết định.

## Điều 11. Gia hạn nợ, chuyển nợ quá hạn

### 1. Trường hợp khách hàng vay vốn không trả được nợ đúng hạn theo kỳ hạn trả nợ cuối cùng và có văn bản đề nghị gia hạn nợ, Ngân hàng Chính sách xã hội xem xét, quyết định gia hạn nợ cho khách hàng vay vốn; thời gian gia hạn nợ tối đa bằng 1/2 thời hạn trả nợ quy định tại khoản 4 Điều 10 Quyết định này.

### 2. Trường hợp khách hàng vay vốn sử dụng vốn vay không đúng mục đích hoặc không trả được nợ đúng hạn và không được chấp thuận điều chỉnh kỳ hạn trả nợ hoặc gia hạn nợ, Ngân hàng Chính sách xã hội thực hiện chuyển nợ quá hạn đối với số dư nợ gốc sử dụng không đúng mục đích hoặc số dư nợ gốc không trả đúng hạn của khách hàng vay vốn. Ngân hàng Chính sách xã hội phối hợp với chính quyền địa phương, các tổ chức chính trị - xã hội và các cơ quan, đơn vị liên quan thực hiện các biện pháp thu hồi nợ vay theo quy định.

### 3. Ngân hàng Chính sách xã hội hướng dẫn chi tiết việc gia hạn nợ và chuyển nợ quá hạn.

## Điều 12. Bảo đảm thực hiện nghĩa vụ trả tiền vay

### 1. Khách hàng vay vốn đến 500 triệu đồng/người học thì không phải thực hiện bảo đảm thực hiện nghĩa vụ trả tiền vay.

### 2. Khách hàng vay vốn trên 500 triệu đồng/người học thì phải thực hiện bảo đảm thực hiện nghĩa vụ trả tiền vay bằng tài sản theo quy định của pháp luật về bảo đảm thực hiện nghĩa vụ và quy định của Ngân hàng Chính sách xã hội.
## Điều 13. Nguồn vốn cho vay

### 1. Nguồn vốn cho vay theo quy định tại Quyết định này bao gồm: Ngân sách trung ương cấp 50% nguồn vốn từ nguồn vốn đầu tư công theo quy định của pháp luật, Ngân hàng Chính sách xã hội đáp ứng 50% nguồn vốn từ nguồn vốn huy động theo quy định của pháp luật.

### 2. Nguồn vốn ủy thác từ ngân sách địa phương cho Ngân hàng Chính sách xã hội theo quy định của pháp luật.

## Điều 14. Phân loại nợ và xử lý nợ bị rủi ro

Việc phân loại nợ và xử lý nợ bị rủi ro đối với các khoản vay theo quy định tại Quyết định này được thực hiện theo quy định của pháp luật về phân loại nợ và xử lý nợ bị rủi ro tại Ngân hàng Chính sách xã hội.

## Điều 15. Chế độ báo cáo

### 1. Báo cáo định kỳ hằng năm về kết quả thực hiện cho vay:

a) Cơ quan gửi báo cáo: Ngân hàng Chính sách xã hội;

b) Cơ quan nhận báo cáo: Bộ Tài chính, Bộ Giáo dục và Đào tạo và Ngân hàng Nhà nước Việt Nam;

c) Mẫu biểu báo cáo: Theo Phụ lục III ban hành kèm theo Quyết định này;

d) Thời hạn gửi báo cáo: Chậm nhất là 60 ngày kể từ ngày kết thúc năm;

đ) Thời gian chốt số liệu: Thời điểm bắt đầu lấy số liệu là ngày đầu tiên của năm báo cáo; thời điểm kết thúc lấy số liệu là ngày cuối cùng của năm báo cáo;

e) Phương thức gửi báo cáo thực hiện theo một trong các phương thức sau: Gửi trực tiếp dưới hình thức văn bản giấy; gửi qua dịch vụ bưu chính dưới hình thức văn bản giấy; gửi qua hệ thống thư điện tử hoặc hệ thống phần mềm thông tin báo cáo chuyên dùng; các phương thức khác theo quy định của pháp luật.

### 2. Ngoài báo cáo định kỳ hằng năm tại khoản 1 Điều này, Ngân hàng Chính sách xã hội báo cáo đột xuất kết quả thực hiện cho vay theo yêu cầu của cấp có thẩm quyền.

## Điều 16. Tổ chức thực hiện

### 1. Ngân hàng Chính sách xã hội:

a) Hướng dẫn chi tiết về hồ sơ vay vốn, trình tự và thủ tục cho vay, kỳ hạn trả nợ, mức trả nợ, cơ cấu lại thời hạn trả nợ, chuyển nợ quá hạn, bảo đảm tiền vay và các nội dung liên quan khác, đảm bảo đơn giản, rõ ràng, dễ thực hiện, tuân thủ đúng quy định của pháp luật;
b) Quản lý và sử dụng nguồn vốn, thực hiện cho vay đúng đối tượng, đủ điều kiện, đúng mục đích, rõ ràng, công khai và minh bạch; định kỳ chủ trì, phối hợp với các tổ chức chính trị - xã hội, các cơ sở giáo dục đại học, cơ sở giáo dục nghề nghiệp và cơ quan liên quan để thực hiện việc kiểm tra, giám sát quá trình sử dụng vốn vay của khách hàng nhằm bảo đảm việc sử dụng vốn vay đúng mục đích, tạo điều kiện thuận lợi cho người học trong việc vay vốn và khả năng thu hồi vốn vay;

c) Định kỳ rà soát, kiểm tra, đánh giá tình hình thực hiện cho vay theo quy định tại Quyết định này để kịp thời phát hiện những khó khăn, vướng mắc, tồn tại, hạn chế, những vấn đề rủi ro có thể phát sinh để xử lý theo thẩm quyền hoặc báo cáo cấp có thẩm quyền xem xét, xử lý theo quy định của pháp luật;

d) Báo cáo Bộ Tài chính, Bộ Giáo dục và Đào tạo và Ngân hàng Nhà nước Việt Nam về kết quả thực hiện cho vay theo quy định tại Điều 15 Quyết định này;

đ) Báo cáo Bộ Tài chính để trình cấp có thẩm quyền xem xét, bố trí nguồn vốn đầu tư công cấp cho Ngân hàng Chính sách xã hội để thực hiện cho vay theo quy định tại Quyết định này;

e) Phối hợp với các bộ, ngành báo cáo cấp có thẩm quyền để kịp thời xử lý những khó khăn, vướng mắc trong quá trình thực hiện cho vay theo quy định tại Quyết định này.

### 2. Bộ Tài chính:

a) Chủ trì, phối hợp với các bộ, cơ quan liên quan và Ngân hàng Chính sách xã hội báo cáo Thủ tướng Chính phủ xử lý các vấn đề phát sinh trong quá trình thực hiện Quyết định này và đề xuất sửa đổi, bổ sung Quyết định này (nếu cần thiết);

b) Trên cơ sở báo cáo của Ngân hàng Chính sách xã hội, chủ trì, phối hợp với các bộ, cơ quan liên quan báo cáo cấp có thẩm quyền xem xét, bố trí nguồn vốn đầu tư công để cấp cho Ngân hàng Chính sách xã hội thực hiện cho vay theo quy định tại Quyết định này.

### 3. Bộ Giáo dục và Đào tạo: Hướng dẫn các cơ sở giáo dục phối hợp với Ủy ban nhân dân các cấp và Ngân hàng Chính sách xã hội tổ chức thực hiện chính sách và tuyên truyền chính sách theo quy định tại Quyết định này.

**4. Ủy ban nhân dân các cấp:**

a) Hằng năm, báo cáo cấp có thẩm quyền xem xét, phê duyệt bố trí nguồn vốn ngân sách địa phương ủy thác cho Ngân hàng Chính sách xã hội theo quy định của pháp luật để cho vay theo Quyết định này;
b) Phối hợp với Ngân hàng Chính sách xã hội và các cơ sở giáo dục trên địa bàn để tổ chức tuyên truyền và thực hiện chính sách theo quy định tại Quyết định này;

c) Phối hợp với Ngân hàng Chính sách xã hội thực hiện các biện pháp thu hồi nợ vay theo quy định.

### 5. Các cơ sở giáo dục đại học, cơ sở giáo dục nghề nghiệp:

a) Thực hiện việc xác nhận cho người học tại Tờ khai thông tin theo mẫu tại Phụ lục I và Phụ lục II ban hành kèm theo Quyết định này;

b) Thông báo cho Ngân hàng Chính sách xã hội trong trường hợp người học không tiếp tục theo học các ngành khoa học, công nghệ, kỹ thuật và toán theo quy định tại Quyết định này sau khi được vay vốn;

c) Phối hợp với Ủy ban nhân dân các cấp và Ngân hàng Chính sách xã hội tổ chức tuyên truyền và thực hiện chính sách theo quy định tại Quyết định này;

d) Phối hợp với Ngân hàng Chính sách xã hội thực hiện việc kiểm tra, giám sát quá trình sử dụng vốn vay của khách hàng nhằm bảo đảm việc sử dụng vốn vay đúng mục đích, tạo điều kiện thuận lợi cho người học trong việc vay vốn và khả năng thu hồi vốn vay.

### 6. Khách hàng vay vốn có trách nhiệm sử dụng vốn vay đúng mục đích, phải hoàn trả nợ gốc và lãi tiền vay đúng thời hạn đã thỏa thuận.

## Điều 17. Điều khoản thi hành

### 1. Quyết định này có hiệu lực thi hành kể từ ngày ký ban hành.

### 2. Trường hợp người học đồng thời thuộc đối tượng vay vốn và đáp ứng điều kiện vay vốn theo quy định tại Quyết định này và quy định tại Quyết định số 157/2007/QĐ-TTg ngày 27 tháng 9 năm 2007 của Thủ tướng Chính phủ về tín dụng đối với học sinh, sinh viên và các văn bản sửa đổi, bổ sung, thay thế (nếu có) thì được lựa chọn áp dụng một trong hai cơ chế vay vốn theo nhu cầu.

### 3. Trường hợp khách hàng đang vay vốn theo quy định tại Quyết định số 157/2007/QĐ-TTg và các văn bản sửa đổi, bổ sung, thay thế (nếu có), nếu thuộc đối tượng, đáp ứng đủ điều kiện và có nhu cầu vay vốn theo quy định tại Quyết định này thì được chuyển sang áp dụng cơ chế vay vốn theo quy định tại Quyết định này trong thời gian học còn lại mà không phải trả trước hạn khoản nợ vay theo Quyết định số 157/2007/QĐ-TTg.
### 4. Các Bộ trưởng, Thủ trưởng cơ quan ngang bộ, Thủ trưởng cơ quan thuộc Chính phủ, Chủ tịch Ủy ban nhân dân tỉnh, thành phố trực thuộc trung ương, Chủ tịch Hội đồng quản trị và Tổng Giám đốc Ngân hàng Chính sách xã hội chịu trách nhiệm thi hành Quyết định này.
