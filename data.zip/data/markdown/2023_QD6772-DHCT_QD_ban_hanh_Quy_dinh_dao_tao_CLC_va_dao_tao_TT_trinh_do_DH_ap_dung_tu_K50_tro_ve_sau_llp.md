1

<!-- page: 1 -->

B GIÁO DỤC VÀ ĐÀO TẠO  
**TRƯỜNG ĐẠI HỌC CẦN THƠ**

**CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM**  
**Độc lập - Tự do - Hạnh phúc**

Số: 6772 /QĐ-ĐHCT  
*Cần Thơ, ngày 30 tháng 11 năm 2023*

# QUYẾT ĐỊNH

**Ban hành Quy định đào tạo chất lượng cao và đào tạo tiên tiến**  
**trình độ đại học hình thức chính quy áp dụng đối với khóa tuyển sinh**  
**từ ngày 01 tháng 12 năm 2023 (Khóa 50) trở về sau**  
**của Trường Đại học Cần Thơ**

### HIỆU TRƯỞNG TRƯỜNG ĐẠI HỌC CẦN THƠ

*Căn cứ Luật Giáo dục đại học ngày 18 tháng 6 năm 2012 và Luật sửa đổi, bổ sung một số điều của Luật Giáo dục đại học ngày 19 tháng 11 năm 2018;*

*Căn cứ Nghị định số 99/2019/NĐ-CP ngày 30 tháng 12 năm 2019 của Chính phủ quy định chi tiết và hướng dẫn thi hành một số điều của Luật sửa đổi, bổ sung một số điều của Luật Giáo dục đại học;*

*Căn cứ Nghị định số 84/2020/NĐ-CP ngày 17 tháng 7 năm 2020 của Chính phủ quy định chi tiết một số điều của Luật Giáo dục;*

*Căn cứ Nghị định số 109/2022/NĐ-CP ngày 30 tháng 12 năm 2022 của Chính phủ quy định về hoạt động khoa học và công nghệ trong cơ sở giáo dục đại học;*

*Căn cứ Thông tư số 01/2014/TT-BGDĐT ngày 24 tháng 01 năm 2014 của Bộ trưởng Bộ Giáo dục và Đào tạo ban hành Khung năng lực ngoại ngữ 6 bậc dùng cho Việt Nam;*

*Căn cứ Thông tư số 17/2015/TT-BGDĐT ngày 01 tháng 9 năm 2015 của Bộ trưởng Bộ Giáo dục và Đào tạo ban hành Khung năng lực tiếng Việt dùng cho người nước ngoài;*

*Căn cứ Thông tư số 30/2018/TT-BGDĐT ngày 24 tháng 12 năm 2018 của Bộ trưởng Bộ Giáo dục và Đào tạo ban hành Quy chế quản lý người nước ngoài học tập tại Việt Nam;*

*Căn cứ Thông tư số 08/2021/TT-BGDĐT ngày 18 tháng 03 năm 2021 của Bộ trưởng Bộ Giáo dục và Đào tạo ban hành Quy chế đào tạo trình độ đại học;*

*Căn cứ Thông tư số 17/2021/TT-BGDĐT ngày 22 tháng 6 năm 2021 của Bộ trưởng Bộ Giáo dục và Đào tạo Quy định về chuẩn chương trình đào tạo; xây dựng, thẩm định và ban hành chương trình đào tạo các trình độ của giáo dục đại học;*

*Căn cứ Nghị quyết số 99/NQ-HĐT ngày 19 tháng 4 năm 2023 của Hội đồng trường về việc Ban hành Quy chế tổ chức và hoạt động của Trường Đại học Cần Thơ;*

*Căn cứ Quyết định số 4799/QĐ-ĐHCT ngày 21 tháng 10 năm 2022 của Hiệu trưởng Trường Đại học Cần Thơ ban hành Quy định điều kiện, trình tự, thủ tục mở ngành đào tạo, đình chỉ hoạt động của ngành đào tạo trình độ đại học, thạc sĩ, tiến sĩ của Trường Đại học Cần Thơ;*

*Căn cứ Biên bản số 4424 /BB-ĐHCT-HĐKHĐT, ngày 29 tháng 11 năm 2023 của Hội đồng Khoa học và Đào tạo Trường Đại học Cần Thơ;*

---

2

<!-- page: 2 -->

*Theo đề nghị của Trưởng phòng Đào tạo, Trưởng phòng Công tác sinh viên, Trưởng phòng Tài chính, Trưởng phòng Quản trị - Thiết bị, Trưởng phòng Quản lý khoa học, Trưởng phòng Hợp tác quốc tế, Trưởng phòng Tổ chức - Cán bộ, Trưởng phòng Thanh tra - Pháp chế, Chánh văn phòng Trường, Giám đốc Trung tâm Quản lý chất lượng, Giám đốc Trung tâm Học liệu, Giám đốc Trung tâm Thông tin và Quản trị mạng, Giám đốc Trung tâm Đánh giá năng lực ngoại ngữ và Trưởng khoa Ngoại ngữ.*

# QUYẾT ĐỊNH:

#### Điều 1. Ban hành kèm theo Quyết định này “Quy định đào tạo chất lượng cao và đào tạo tiên tiến trình độ đại học hình thức chính quy áp dụng đối với khóa tuyển sinh từ ngày 01 tháng 12 năm 2023 (Khóa 50) trở về sau của Trường Đại học Cần Thơ”.

#### Điều 2. Quyết định này có hiệu lực thi hành kể từ ngày 01 tháng 12 năm 2023 và áp dụng đối với các khóa tuyển sinh từ ngày 01 tháng 12 năm 2023 (từ Khóa 50) trở về sau của Trường Đại học Cần Thơ.

#### Điều 3. Trưởng phòng Đào tạo, Trưởng phòng Công tác sinh viên, Trưởng phòng Tài chính, Trưởng phòng Quản trị - Thiết bị, Trưởng phòng Quản lý khoa học, Trưởng phòng Hợp tác quốc tế, Trưởng phòng Tổ chức - Cán bộ, Trưởng phòng Thanh tra - Pháp chế, Chánh văn phòng Trường, Giám đốc Trung tâm Quản lý chất lượng, Giám đốc Trung tâm Học liệu, Giám đốc Trung tâm Thông tin và Quản trị mạng, Giám đốc Trung tâm Đánh giá năng lực ngoại ngữ, Trưởng khoa Ngoại ngữ, Trưởng các đơn vị, viên chức và sinh viên có liên quan chịu trách nhiệm thi hành Quyết định này./. [signature]

**Nơi nhận:**

- Như Điều 3;

- Ban Giám hiệu;

- Hội đồng KH&ĐT;

- Công bố tại website Trường;

- Lưu: VT, PĐT.

**KT. HIỆU TRƯỞNG**
**PHÓ HIỆU TRƯỞNG**

Signature and seal of Can Tho University

**Trần Trung Tính**

---

3

<!-- page: 3 -->

# QUY ĐỊNH

**Đào tạo chất lượng cao và đào tạo tiên tiến trình độ đại học hình thức chính quy áp dụng đối với khóa tuyển sinh từ ngày 01 tháng 12 năm 2023 (Khóa 50) trở về sau của Trường Đại học Cần Thơ**

*(Ban hành kèm theo Quyết định số 6772 /QĐ-ĐHCT ngày 30 tháng 11 năm 2023 của Hiệu trưởng Trường Đại học Cần Thơ)*

## CHƯƠNG I

## NHỮNG QUY ĐỊNH CHUNG

#### Điều 1. Phạm vi điều chỉnh và đối tượng áp dụng

1. Văn bản này quy định về đào tạo chất lượng cao (ĐTCLC) và đào tạo tiên tiến (ĐTTT) trình độ đại học hình thức chính quy áp dụng đối với khóa tuyển sinh từ ngày 01 tháng 12 năm 2023 (Khóa 50) trở về sau của Trường Đại học Cần Thơ (ĐHCT), bao gồm: mục tiêu đào tạo, chương trình đào tạo (CTĐT), bản mô tả CTĐT và chương trình dạy học; tuyển sinh, điều kiện chuyển sang học một chương trình, một ngành đào tạo khác; quản lý và tổ chức đào tạo; giảng viên và trợ giảng; sinh viên; cơ sở vật chất; nghiên cứu khoa học (NCKH); hợp tác quốc tế; bảo đảm chất lượng; học phí và học bổng; khen thưởng và kỷ luật.

2. Quy định này áp dụng đối với các đơn vị, viên chức và sinh viên tham gia quá trình ĐTCLC và ĐTTT của Trường ĐHCT đối với các khóa tuyển sinh từ ngày 01 tháng 12 năm 2023 (từ Khóa 50) trở về sau của Trường Đại học Cần Thơ.

3. Những nội dung khác liên quan đến ĐTCLC và ĐTTT không được quy định trong Quy định này sẽ áp dụng theo Quy định công tác học vụ dành cho sinh viên trình độ đại học hình thức chính quy của Trường ĐHCT có hiệu lực hiện hành.

#### Điều 2. Giải thích thuật ngữ

Trong Quy định này, các từ ngữ dưới đây được hiểu như sau:

1. Chương trình đào tạo đại trà (hoặc gọi là chương trình đào tạo chuẩn) là CTĐT trình độ đại học đang được thực hiện tại Trường ĐHCT, đáp ứng tối thiểu chuẩn CTĐT theo quy định của Bộ Giáo dục và Đào tạo (GD&ĐT).

2. Chương trình đào tạo chất lượng cao (CTĐTCLC) và Chương trình đào tạo tiên tiến (CTĐTTT) là CTĐT có các điều kiện bảo đảm chất lượng và chuẩn đầu ra cao hơn CTĐT đại trà tương ứng, đồng thời đáp ứng các tiêu chí và điều kiện tại Quy định này.

3. Chương trình đào tạo nước ngoài là CTĐT đang được áp dụng ở một trường đại học trong khu vực hoặc trên thế giới đã được công nhận đạt chất lượng bởi tổ chức kiểm định chất lượng có uy tín hoặc được cơ quan có thẩm quyền của nước đó cho phép thực hiện và cấp văn bằng, được tham khảo để xây dựng và phát triển CTĐTCLC và CTĐTTT của Trường ĐHCT.

---

4

<!-- page: 4 -->

#### Điều 3. Mục tiêu đào tạo chất lượng cao và đào tạo tiên tiến

1. Nâng cao chất lượng đào tạo ở những đơn vị có đủ điều kiện nhằm đào tạo nguồn nhân lực có tính cạnh tranh cao trên thị trường lao động trong thời kỳ hội nhập quốc tế; đáp ứng nhu cầu của người học được ĐTCLC và ĐTTT trình độ đại học trong điều kiện tự chủ trong đào tạo.

2. CTĐTCLC và CTĐTTT được Trường ưu tiên về cơ sở vật chất, CTĐT, giáo trình và tài liệu tham khảo, đội ngũ giảng dạy và cán bộ quản lý, tổ chức và quản lý đào tạo, tạo điều kiện áp dụng phương pháp giảng dạy tiên tiến, NCKH, đổi mới sáng tạo và khởi nghiệp, hợp tác quốc tế... để từng bước đạt chuẩn chất lượng CTĐT của tổ chức kiểm định có uy tín của Việt Nam, của khu vực hoặc thế giới nhằm thu hút sinh viên trong nước và quốc tế.

3. Thông qua ĐTCLC và ĐTTT tăng cường hoạt động trao đổi sinh viên và giảng viên; hợp tác chuyên môn học thuật, NCKH và những hoạt động hợp tác khác của Trường ĐHCT với các cơ sở đào tạo uy tín trong và ngoài nước.

#### Điều 4. Chương trình đào tạo, bản mô tả chương trình đào tạo và chương trình dạy học

1. Chuẩn đầu ra của CTĐTCLC và CTĐTTT phải cao hơn chuẩn đầu ra của CTĐT đại trà tương ứng về năng lực chuyên môn; năng lực ứng dụng công nghệ thông tin; năng lực dẫn dắt, chủ trì và làm việc nhóm; khả năng thích nghi với môi trường làm việc; riêng năng lực ngoại ngữ tối thiểu phải đạt bậc 4/6 đối với CTĐT không chuyên ngữ và bậc 5/6 đối với các CTĐT chuyên ngữ theo Khung năng lực ngoại ngữ 6 bậc dùng cho Việt Nam (sinh viên phải có kết quả học phần thi đánh giá năng lực ngoại ngữ do Trường ĐHCT tổ chức đạt từ bậc 4/6 trở lên đối với CTĐT không chuyên ngữ và bậc 5/6 đối với CTĐT chuyên ngữ; hoặc có các chứng chỉ ngoại ngữ từ tương đương trở lên). Loại chứng chỉ và cấp độ ngoại ngữ đạt được tối thiểu để được xét tương đương trình độ bậc 4/6 đối với CTĐT không chuyên ngữ và bậc 5/6 đối với CTĐT chuyên ngữ do Hiệu trưởng quy định (xem Phụ lục).

2. CTĐTCLC được xây dựng và phát triển trên nền của CTĐT đại trà; CTĐTTT được phát triển trên cơ sở CTĐT của một cơ sở đào tạo uy tín nước ngoài thuộc Đề án đào tạo chương trình tiên tiến đã được Bộ GD&ĐT phê duyệt (ngành Công nghệ sinh học và ngành Nuôi trồng thủy sản). CTĐTCLC và CTĐTTT được tổ chức đào tạo theo phương thức tín chỉ của Trường ĐHCT; cấu trúc từ các học phần (thuộc chương trình ngoại ngữ tăng cường dành cho CTĐT không chuyên ngữ, khối kiến thức giáo dục đại cương và giáo dục chuyên nghiệp), trong đó có đủ các học phần bắt buộc và đáp ứng chuẩn CTĐT theo quy định hiện hành của Bộ GD&ĐT; có tham khảo CTĐT nước ngoài; có sự tham gia và góp ý của đội ngũ giảng viên thực hiện CTĐTCLC và CTĐTTT, giảng viên có kinh nghiệm, chuyên gia nước ngoài, bộ phận bảo đảm chất lượng; được lấy ý kiến đóng góp của cựu sinh viên, đại diện của các đơn vị sử dụng lao động, đại diện của các hội nghề nghiệp (nếu có); và có đủ các điều kiện như sau:

a) Có ít nhất 3 khóa sinh viên đại học tốt nghiệp và đã công bố chuẩn đầu ra của CTĐT đại trà tương ứng;

b) Có chương trình trao đổi giảng viên, sinh viên với các trường đại học nước ngoài;

c) Có hợp tác với các tổ chức, doanh nghiệp và cơ sở sản xuất liên quan đến CTĐTCLC và CTĐTTT; có các giảng viên thỉnh giảng, báo cáo viên đến từ tổ chức, doanh nghiệp và cơ sở sản xuất;

---

5

<!-- page: 5 -->

CTĐTCLC và CTĐTTT được thiết kế có khối lượng tối thiểu (*chưa tính khối lượng chương trình ngoại ngữ tăng cường đối với CTĐT không chuyên ngữ*) và thời gian học tập tối đa cho phép để sinh viên hoàn thành CTĐT như sau:

| Thời gian thiết kế CTĐT | Khối lượng CTĐT tối thiểu | Thời gian học tập tối đa để sinh viên hoàn thành CTĐT |
| --- | --- | --- |
| 4 năm | 130 tín chỉ | 8 năm |
| 4,5 năm | 145 tín chỉ | 9 năm |
| 5 năm | 160 tín chỉ | 10 năm |

Ngoài khối lượng của CTĐT như nêu trên, CTĐTCLC và CTĐTTT thuộc các ngành không chuyên ngữ có thiết kế chương trình ngoại ngữ tăng cường có khối lượng 20 tín chỉ (*với nội dung giảng dạy đến trình độ tương đương bậc 3/6 theo Khung năng lực ngoại ngữ 6 bậc dùng cho Việt Nam và rèn luyện những kỹ năng cần thiết cho người học*) và học phần thi đánh giá năng lực ngoại ngữ 02 tín chỉ (*ôn tập và đánh giá năng lực ngoại ngữ của người học*). Vào đầu khóa học, sinh viên tham gia chương trình ngoại ngữ tăng cường do Trường ĐHCT bố trí lịch học để đạt năng lực ngoại ngữ và những kỹ năng tối thiểu theo học CTĐTCLC và CTĐTTT. Vào đầu khóa học và trong thời gian tổ chức học chương trình ngoại ngữ tăng cường, những sinh viên có chứng chỉ ngoại ngữ (*ngoại ngữ chính được sử dụng để giảng dạy CTĐTCLC, CTĐTTT*) đạt trình độ 3/6 theo Khung năng lực ngoại ngữ 6 bậc dùng cho Việt Nam hoặc tương đương trở lên (xem Phụ lục) được Trường xem xét cho phép miễn học phí hoặc miễn học chương trình ngoại ngữ tăng cường nếu sinh viên có đơn đề nghị (*sinh viên được Trường đồng ý cho phép miễn học chương trình ngoại ngữ tăng cường được đơn vị quản lý đào tạo phối hợp với Phòng Đào tạo sắp xếp học các học phần khác thuộc CTĐT*). Trong quá trình theo học CTĐTCLC và CTĐTTT, sinh viên phải có kế hoạch tự học hoặc có thể theo học các khóa học ngoại ngữ do Trung tâm Ngoại ngữ Trường ĐHCT tổ chức để tiếp tục nâng cao năng lực ngoại ngữ đạt trình độ 4/6 theo Khung năng lực ngoại ngữ 6 bậc dùng cho Việt Nam hoặc tương đương trở lên (xem Phụ lục).

Sinh viên phải tích lũy đủ các học phần và khối lượng tín chỉ theo yêu cầu của CTĐT để được xét tốt nghiệp.

3. Đề cương chi tiết các học phần của CTĐTCLC và CTĐTTT khi xây dựng hoặc điều chỉnh phải có sự tham gia của đội ngũ giảng viên thực hiện CTĐTCLC và CTĐTTT, bộ phận bảo đảm chất lượng và lấy ý kiến đóng góp của cựu sinh viên, đại diện của các đơn vị sử dụng lao động, đại diện của các hội nghề nghiệp (nếu có). Một số học phần thuộc CTĐT có thể được tổ chức lớp học bằng phương thức dạy và học trực tuyến một phần hoặc toàn bộ học phần khi đáp ứng các quy định hiện hành. Những nội dung dạy và học trực tuyến được ghi trong đề cương chi tiết học phần. Tổng khối lượng (tính theo tín chỉ) được thực hiện bằng phương thức dạy và học trực tuyến không quá 30% khối lượng của CTĐT. Trong trường hợp thiên tai, dịch bệnh phức tạp và các trường hợp bất khả kháng khác, Trường ĐHCT có thể thực hiện việc dạy và học bằng phương thức trực tuyến theo yêu cầu và hướng dẫn của Nhà nước.

4. Bản mô tả CTĐT và chương trình dạy học được xây dựng căn cứ vào CTĐT, gồm các nội dung: thông tin chung về CTĐT; thông tin về đối sánh giữa CTĐT với các chương trình tương tự trong và ngoài nước; thông tin về kết quả đánh giá hoặc kiểm định chất lượng CTĐT; mục tiêu đào tạo của CTĐT; chuẩn đầu ra của CTĐT; tiêu chí

---

6

<!-- page: 6 -->

tuyển sinh; cấu trúc chương trình dạy học; khung CTĐT (*là CTĐT với các học phần được bố trí theo khối kiến thức*); kế hoạch dạy học (*là CTĐT với các học phần được bố trí theo học kỳ trong thời gian thiết kế của CTĐT; gọi là kế hoạch học tập chuẩn toàn khóa*); tóm tắt các học phần (*đính kèm đề cương chi tiết các học phần*); phương pháp giảng dạy và học tập; phương pháp đánh giá.

5. CTĐT, Bản mô tả CTĐT và chương trình dạy học của CTĐTCLC và CTĐTTT được công bố trên trang thông tin điện tử của Trường ĐHCT, đơn vị quản lý CTĐTCLC và CTĐTTT để sinh viên và các bên liên quan dễ dàng tiếp cận.

6. Đề án ĐTCLC, quy trình xây dựng, thẩm định và ban hành CTĐTCLC được thực hiện theo các quy định hiện hành về điều kiện, trình tự, thủ tục mở ngành đào tạo, đình chỉ hoạt động của ngành đào tạo trình độ đại học, thạc sĩ, tiến sĩ của Bộ GD&ĐT và của Trường ĐHCT.

7. Đối với CTĐT, Bản mô tả CTĐT và chương trình dạy học (có bao gồm đề cương chi tiết học phần) của CTĐTCLC và CTĐTTT đang áp dụng cho Khóa 49 trở về trước được rà soát, đánh giá, cập nhật theo Quy định này; được Hiệu trưởng ban hành áp dụng cho Khóa 50 trở về sau.

# CHƯƠNG II

CHỈ TIÊU, ĐỐI TƯỢNG, ĐIỀU KIỆN VÀ ƯU TIÊN TUYỂN SINH, QUY TRÌNH TUYỂN SINH, ĐIỀU KIỆN CHUYỂN SANG HỌC MỘT CHƯƠNG TRÌNH, MỘT NGÀNH ĐÀO TẠO KHÁC

#### Điều 5. Chỉ tiêu, đối tượng, điều kiện và ưu tiên tuyển sinh

1. Chỉ tiêu tuyển sinh CTĐTCLC và CTĐTTT nằm trong tổng chỉ tiêu tuyển sinh đã xác định hàng năm của Trường ĐHCT theo quy định của Bộ GD&ĐT. Hiệu trưởng quyết định chỉ tiêu tuyển sinh của từng ngành ĐTCLC và ĐTTT.

2. Đối tượng tuyển sinh và điều kiện tuyển sinh

a) Thí sinh là người Việt Nam và người nước ngoài đáp ứng điều kiện tham gia tuyển sinh theo quy chế tuyển sinh trình độ đại học hình thức chính quy hiện hành và thông báo tuyển sinh của Trường ĐHCT.

b) Thí sinh phải đáp ứng các điều kiện khác về tuyển sinh do Trường ĐHCT quy định (được ghi trong thông báo tuyển sinh hàng năm).

3. Những ưu tiên tuyển sinh của từng ngành ĐTCLC và ĐTTT (nếu có) do Hiệu trưởng quyết định và được ghi trong thông báo tuyển sinh của Trường ĐHCT.

#### Điều 6. Quy trình tuyển sinh

1. Hàng năm, Hiệu trưởng ban hành quyết định thành lập Hội đồng tuyển sinh Trường ĐHCT. Hội đồng tuyển sinh có nhiệm vụ tổ chức xét tuyển sinh viên vào học các CTĐTCLC và CTĐTTT đúng với Quy định này và thông báo tuyển sinh.

2. Thông báo tuyển sinh vào học CTĐTCLC và CTĐTTT được Hội đồng tuyển sinh đăng công khai trên trang thông tin điện tử của Trường ĐHCT.

---

7

<!-- page: 7 -->

3. Thí sinh nộp hồ sơ và lệ phí đăng ký xét tuyển vào học CTĐTCLC và CTĐTTT, các giấy tờ khác theo thông báo tuyển sinh cho Hội đồng tuyển sinh. Lệ phí đăng ký xét tuyển vào học CTĐTCLC và CTĐTTT do Hiệu trưởng quy định.

4. Căn cứ chỉ tiêu tuyển sinh của năm, Hội đồng tuyển sinh tổ chức xét tuyển trên cơ sở hồ sơ thí sinh đăng ký xét tuyển vào học CTĐTCLC và CTĐTTT. Kết quả xét tuyển được công bố công khai trên trang thông tin điện tử của Trường ĐHCT.

5. Hàng năm, sau mỗi kỳ tuyển sinh, kết quả tuyển sinh CTĐTCLC và CTĐTTT được gửi cho Bộ GD&ĐT để báo cáo.

#### Điều 7. Điều kiện chuyển sang học một chương trình, một ngành đào đạo khác

Sinh viên CTĐTCLC, CTĐTTT và CTĐT đại trà được xem xét chuyển sang học một CTĐTCLC, CTĐTTT và CTĐT đại trà khác nếu đáp ứng các điều kiện theo Quy định công tác học vụ dành cho sinh viên trình độ đại học hình thức chính quy của Trường ĐHCT hiện hành và hướng dẫn khác (*nếu có*) của Trường ĐHCT. Riêng đối với trường hợp sinh viên học CTĐT đại trà chuyển sang học CTĐTCLC hoặc CTĐTTT được yêu cầu thêm điều kiện là phải có trình độ ngoại ngữ được sử dụng để giảng dạy CTĐTCLC và CTĐTTT tương đương bậc 3/6 trở lên theo Khung năng lực ngoại ngữ 6 bậc dùng cho Việt Nam.

# CHƯƠNG III
# QUẢN LÝ VÀ TỔ CHỨC ĐÀO TẠO

#### Điều 8. Quản lý chương trình đào tạo chất lượng cao và chương trình đào tạo tiên tiến

Hiệu trưởng thành lập các tổ chức quản lý cấp Trường và cấp đơn vị để thực hiện công tác quản lý CTĐTCLC và CTĐTTT.

1. Quản lý CTĐTCLC và CTĐTTT cấp Trường là "Ban quản lý Chương trình đào tạo chất lượng cao" hoặc "Ban quản lý Chương trình đào tạo tiên tiến" do Hiệu trưởng làm Trưởng ban, một Phó hiệu trưởng là Phó trưởng ban, lãnh đạo đơn vị quản lý CTĐTCLC hoặc CTĐTTT làm Ủy viên thường trực, lãnh đạo các đơn vị: Phòng Đào tạo, Phòng Công tác sinh viên, Phòng Tài chính, Phòng Quản trị - Thiết bị, Phòng Quản lý khoa học, Phòng Hợp tác quốc tế, Phòng Tổ chức - Cán bộ, Văn phòng Trường, Trung tâm Quản lý chất lượng, Trung tâm Học liệu Trung tâm Đánh giá năng lực ngoại ngữ, Trung tâm Thông tin và quản trị mạng và đơn vị phụ trách chuyên môn ngành đào tạo (Khoa thuộc Trường chuyên ngành/Bộ môn thuộc Khoa hoặc Viện thuộc Trường ĐHCT) làm Ủy viên. Ban quản lý CTĐTCLC và CTĐTTT có nhiệm vụ và quyền hạn trong việc chỉ đạo, quản lý, hỗ trợ các đơn vị thực hiện đúng Quy định này và các quy định hiện hành khác nhằm đạt hiệu quả quản lý từ Trường đến đơn vị; xem xét và xử lý những khó khăn, vướng mắc và phát sinh vượt quá khả năng, quyền hạn giải quyết của đơn vị quản lý CTĐT. Căn cứ đề xuất của đơn vị quản lý CTĐTCLC và CTĐTTT, của Phòng Đào tạo và Phòng Tổ chức - Cán bộ, Hiệu trưởng ban hành quyết định thành lập "Ban quản lý Chương trình đào tạo chất lượng cao" và "Ban quản lý Chương trình đào tạo tiên tiến".

2. Quản lý CTĐTCLC và CTĐTTT của đơn vị thuộc Trường là "Tổ quản lý Chương trình đào tạo chất lượng cao" hoặc "Tổ quản lý Chương trình đào tạo tiên tiến" do lãnh đạo đơn vị là Ủy viên thường trực Ban quản lý CTĐTCLC hoặc CTĐTTT làm

---

8

<!-- page: 8 -->

Tổ trưởng, lãnh đạo bộ môn (*hoặc đơn vị tương đương*) có CTĐTCLC hoặc CTĐTTT làm Tổ phó và các thành viên khác do đơn vị đề xuất. Tổ quản lý CTĐTCLC và Tổ quản lý CTĐTTT có nhiệm vụ và quyền hạn trong việc tổ chức quản lý CTĐTCLC và CTĐTTT đúng với Quy định này và những quy định khác hiện hành có liên quan; sử dụng hiệu quả nguồn lực được Trường phân giao; việc thực hiện bảo đảm chất lượng đào tạo; đề xuất viên chức đảm nhiệm công tác cố vấn học tập, giảng viên tham gia giảng dạy và trợ giảng; kết nối và liên kết với doanh nghiệp, nhà sử dụng lao động hỗ trợ đào tạo và người học; định kỳ mỗi học kỳ tổ chức gặp gỡ, tiếp xúc với sinh viên để lắng nghe ý kiến của sinh viên; truyền thông quảng bá và tư vấn tuyển sinh,...; kịp thời báo cáo và đề xuất đến Ban quản lý CTĐTCLC và CTĐTTT những khó khăn, vướng mắc và phát sinh vượt quá khả năng, quyền hạn của đơn vị. Căn cứ đề xuất của đơn vị và Phòng Tổ chức - Cán bộ, Hiệu trưởng ban hành quyết định thành lập “Tổ quản lý Chương trình đào tạo chất lượng cao” và “Tổ quản lý Chương trình đào tạo tiên tiến”.

3. Người tham gia Tổ quản lý CTĐTCLC và CTĐTTT phải có đủ năng lực chuyên môn hoặc có kinh nghiệm trong quản lý đào tạo, bảo đảm chất lượng; sử dụng thành thạo các phần mềm quản lý liên quan; có năng lực ngoại ngữ đáp ứng yêu cầu công việc.

#### Điều 9. Cố vấn học tập

1. Cố vấn học tập phải là giảng viên có tham gia giảng dạy CTĐTCLC và CTĐTTT; phải nắm vững CTĐT, quy định về ĐTCLC và ĐTTT; Quy định công tác học vụ dành cho sinh viên trình độ đại học hình thức chính quy; có khả năng tổ chức và quản lý lớp; có khả năng hỗ trợ, tư vấn cho sinh viên của lớp được phân công trong quá trình học tập; có năng lực ngoại ngữ đáp ứng yêu cầu công việc. Danh sách cố vấn học tập do Hiệu trưởng quyết định trên cơ sở đề nghị của đơn vị quản lý CTĐTCLC và CTĐTTT và Phòng Công tác sinh viên.

2. Cố vấn học tập chịu trách nhiệm tổ chức và quản lý lớp được phân công phụ trách. Ngoài giờ lên lớp, cố vấn học tập phải bố trí thời gian trả lời, giải quyết các vấn đề vướng mắc của sinh viên về CTĐT, nội dung học tập, quy định công tác học vụ và các vấn đề khác sinh viên cần tư vấn và hỗ trợ. Cố vấn học tập phải báo cáo kịp thời đến Tổ quản lý CTĐTCLC và Tổ quản lý CTĐTTT các vấn đề vượt quá khả năng hỗ trợ, tư vấn và giải quyết; các ý kiến, phản ánh của sinh viên, phụ huynh và viên chức.

#### Điều 10. Lớp quản lý sinh viên

1. Lớp quản lý sinh viên CTĐTCLC và CTĐTTT được tổ chức theo CTĐTCLC, CTĐTTT và khóa học. Căn cứ vào số lượng sinh viên của từng CTĐTCLC và CTĐTTT của khóa học, Hiệu trưởng quyết định việc phân chia thành một lớp hoặc nhiều lớp để quản lý sinh viên. Mỗi lớp có một mã số lớp để phân biệt CTĐTCLC, CTĐTTT và khóa học.

2. Mỗi lớp có một cố vấn học tập đảm nhiệm công tác tổ chức và quản lý lớp; tư vấn và hỗ trợ sinh viên.

#### Điều 11. Tổ chức và quản lý đào tạo

Ngoài việc tuân theo các quy định chung về tổ chức và quản lý đào tạo trình độ đại học hiện hành, tổ chức và quản lý đào tạo CTĐTCLC và CTĐTTT phải đảm bảo:

1. Tổ chức thực hiện theo phương thức đào tạo tín chỉ, sử dụng triệt để phương pháp giảng dạy mới theo hướng phát huy năng lực cá nhân của sinh viên, tăng cường

---

9

<!-- page: 9 -->

rèn luyện kỹ năng mềm, kỹ năng sử dụng các trang thiết bị hiện đại và các phần mềm chuyên dụng để giải quyết các nội dung chuyên môn. Chuẩn đầu ra và CTĐTCLC, CTĐTTT được Tổ quản lý CTĐTCLC và Tổ quản lý CTĐTTT phổ biến và giải thích rõ đến sinh viên thuộc CTĐTCLC, CTĐTTT vào đầu khóa học. Mục tiêu, chuẩn đầu ra, nội dung, phương pháp giảng dạy, phương pháp đánh giá kết quả học tập, tài liệu và nguồn tài liệu học tập học phần được ghi rõ trong đề cương chi tiết học phần và được giảng viên phổ biến cụ thể trong buổi học đầu tiên của học phần.

2. Có ít nhất 30% số tín chỉ các học phần thuộc khối kiến thức cơ sở ngành, ngành và chuyên ngành được dạy bằng ngoại ngữ, trong đó có ít nhất 1/2 số tín chỉ nêu trên do giảng viên được quy định tại điểm d khoản 1 Điều 14 của Quy định này đảm nhiệm (trừ những ngành chỉ đào tạo ở Việt Nam).

3. Tổ chức cho sinh viên tham quan, thực hành, thực tập tại các cơ quan, tổ chức, doanh nghiệp, công ty, cơ sở sản xuất trong hoặc ngoài nước theo kế hoạch; mời các giảng viên thỉnh giảng và báo cáo viên là các chuyên gia, nhà khoa học, doanh nhân, nghệ nhân đến từ cơ quan, tổ chức, doanh nghiệp ở trong nước hoặc nước ngoài tham gia giảng dạy, báo cáo chuyên đề, hướng dẫn thực hành, thí nghiệm, tư vấn phát triển nghề nghiệp; hợp tác với các đơn vị sử dụng lao động, doanh nghiệp liên quan để mời tham gia, hỗ trợ hoạt động đào tạo và NCKH.

4. Áp dụng các phương pháp đánh giá kết quả học tập và chuẩn đầu ra hiện đại theo hướng chú trọng phát triển năng lực thực hành, phân tích, sáng tạo, tự cập nhật kiến thức; năng lực nghiên cứu, ứng dụng khoa học và công nghệ trên nguyên tắc khách quan, minh bạch, linh hoạt, bám sát mục tiêu của mỗi học phần và của CTĐT.

5. Bố trí trợ giảng cho học phần thuộc khối kiến thức chuyên ngành (nếu cần thiết).

6. Bố trí đủ cán bộ hướng dẫn thảo luận, thực hành, thí nghiệm, thực tập; đảm bảo mỗi nhóm thảo luận không quá 30 sinh viên, nhóm thực hành không quá 15 sinh viên, nhóm làm thí nghiệm tại phòng thí nghiệm không quá 05 sinh viên/thiết bị.

#### Điều 12. Đánh giá học phần

1. Đánh giá học phần CTĐTCLC và CTĐTTT được áp dụng theo Quy định công tác học vụ dành cho sinh viên trình độ đại học hình thức chính quy hiện hành của Trường ĐHCT.

2. Tổ chức đánh giá theo phương pháp đánh giá tiên tiến phù hợp với từng học phần nhằm mục tiêu phát triển năng lực và phẩm chất của sinh viên. Hình thức đánh giá và tính điểm học phần được ghi rõ trong đề cương chi tiết của học phần và được giảng viên phổ biến cụ thể đến sinh viên trong buổi học đầu tiên của học phần.

3. Sử dụng ngoại ngữ trong đánh giá đối với các học phần được giảng dạy bằng tiếng nước ngoài.

4. Viết và báo cáo tiểu luận tốt nghiệp, luận văn tốt nghiệp bằng ngoại ngữ được sử dụng giảng dạy CTĐTCLC và CTĐTTT. Khuyến khích viết và báo cáo các học phần thực hành, thực tập, báo cáo chuyên đề, đồ án, niên luận bằng ngoại ngữ được sử dụng giảng dạy CTĐTCLC và CTĐTTT.

#### Điều 13. Văn bằng tốt nghiệp

Sinh viên đủ điều kiện tốt nghiệp CTĐTCLC và CTĐTTT được Hiệu trưởng cấp quyết định công nhận tốt nghiệp, văn bằng tốt nghiệp và phụ lục văn bằng theo quy định hiện hành

---

10

<!-- page: 10 -->

có ghi rõ bằng tiếng Việt là “chương trình chất lượng cao” hoặc “chương trình tiên tiến” và bằng tiếng Anh là “high quality program” hoặc “advanced program” trong dấu ngoặc đơn ngay sau tên ngành ĐTCLC hoặc ĐTTT tương ứng bằng tiếng Việt và tiếng Anh.

# CHƯƠNG IV
# GIẢNG VIÊN, TRỢ GIẢNG, SINH VIÊN

#### Điều 14. Điều kiện đối với giảng viên và trợ giảng

1. Giảng viên tham gia giảng dạy CTĐTCLC và CTĐTTT phải đáp ứng các tiêu chuẩn, điều kiện chung của giảng viên theo quy định và các điều kiện sau:

a) Trình độ chuyên môn: Giảng viên dạy lý thuyết các học phần thuộc khối kiến thức ngành, chuyên ngành phải có trình độ tiến sĩ hoặc có trình độ thạc sĩ tốt nghiệp ở các cơ sở đào tạo của các nước phát triển đúng ngành hoặc thuộc ngành gần;

b) Có năng lực chuyên môn, NCKH đáp ứng yêu cầu của CTĐTCLC và CTĐTTT (*có tối thiểu 01 công trình NCKH được công bố hoặc được nghiệm thu có nội dung liên quan đến ngành ĐTCLC và ĐTTT*); có kinh nghiệm giảng dạy liên quan đến ngành ĐTCLC và ĐTTT từ 3 năm trở lên; được đơn vị quản lý chuyên môn và người học đánh giá có phương pháp giảng dạy hiệu quả, áp dụng tốt công nghệ thông tin trong giảng dạy và NCKH;

c) Giảng viên dạy các học phần chuyên môn bằng ngoại ngữ, ngoài các tiêu chuẩn nêu tại điểm a, b khoản này, phải có trình độ ngoại ngữ bậc 5/6 trở lên theo Khung năng lực ngoại ngữ 6 bậc dùng cho Việt Nam (*hoặc tương đương*) hoặc được đào tạo trình độ đại học trở lên toàn thời gian ở nước ngoài bằng ngôn ngữ đó;

d) Có giảng viên uy tín của các trường đại học nước ngoài (*bao gồm cả giảng viên Việt Nam có quốc tịch nước ngoài*) hoặc giảng viên Việt Nam đã tham gia giảng dạy trình độ đại học trở lên ở nước ngoài hoặc giảng viên đã được đào tạo trình độ tiến sĩ ở nước ngoài, đáp ứng yêu cầu của CTĐTCLC và CTĐTTT tham gia giảng dạy các học phần được quy định tại khoản 2 Điều 11 của Quy định này;

đ) Nhà khoa học, nhà quản lý và những người có nhiều kinh nghiệm, được đơn vị quản lý CTĐTCLC và CTĐTTT đánh giá có chuyên môn phù hợp, được mời tham gia giảng dạy một phần nội dung của học phần.

e) Danh sách giảng viên tham gia giảng dạy CTĐTCLC và CTĐTTT do Hiệu trưởng phê duyệt theo đề nghị của trưởng đơn vị quản lý ngành đào tạo và của Phòng Hợp tác quốc tế (*nếu là người nước ngoài bao gồm cả giảng viên Việt Nam có quốc tịch nước ngoài*), được công bố công khai trên trang thông tin điện tử của Trường ĐHCT. Danh sách giảng viên dạy CTĐTCLC và CTĐTTT nếu có điều chỉnh, bổ sung phải được Hiệu trưởng phê duyệt trước thời điểm bắt đầu học kỳ.

2. Trợ giảng

a) Trợ giảng phải có đủ năng lực chuyên môn, ngoại ngữ đáp ứng yêu cầu của học phần; sử dụng tốt các thiết bị hiện đại phục vụ giảng dạy để hỗ trợ giảng viên trong việc hướng dẫn sinh viên thực hiện bài tập, hướng dẫn thực hành, thảo luận, báo cáo chuyên đề, đồ án, niên luận, tiểu luận tốt nghiệp, luận văn tốt nghiệp;

---

11

<!-- page: 11 -->

b) Nghiên cứu sinh, học viên cao học, sinh viên giỏi tốt nghiệp CTĐTCLC và CTĐTTT có thể được xem xét mời tham gia hoạt động trợ giảng.

#### Điều 15. Nhiệm vụ và quyền của giảng viên

1. Nhiệm vụ của giảng viên

Ngoài những nhiệm vụ đối với giảng viên theo quy định của Luật Giáo dục đại học và của Trường ĐHCT, giảng viên tham gia giảng dạy CTĐTCLC và CTĐTTT còn có những nhiệm vụ như sau:

- Tổ chức giảng dạy và tổ chức đánh giá lớp học phần được phân công theo đúng đề cương chi tiết học phần và kế hoạch giảng dạy của Trường ĐHCT. Trong tiết dạy thứ nhất của học phần, giảng viên thông tin và giải thích đến sinh viên các nội dung và yêu cầu của học phần được đề cập trong đề cương chi tiết học phần; giới thiệu các tài liệu và nguồn tài liệu học tập sinh viên cần tham khảo;

- Thực hiện giảng dạy lớp học phần bằng ngoại ngữ đối với các học phần được yêu cầu giảng dạy bằng tiếng nước ngoài;

- Hướng dẫn hoặc tổ chức cho trợ giảng hướng dẫn sinh viên thực hiện các nội dung trong giờ tự học, bài tập, câu hỏi lý thuyết để sinh viên chuẩn bị cho thảo luận, làm việc nhóm;

- Thường xuyên cập nhật nâng cao chất lượng nội dung giảng dạy; cải tiến phương pháp giảng dạy, đánh giá kết quả học tập và chuẩn đầu ra;

- Khai thác và sử dụng cơ sở vật chất kỹ thuật phục vụ cải tiến và đổi mới phương pháp giảng dạy;

- Đóng góp ý kiến nhằm nâng cao chất lượng đào tạo và quản lý CTĐTCLC và CTĐTTT.

2. Quyền của giảng viên

Ngoài những quyền của giảng viên theo quy định của Luật Giáo dục đại học và của Trường ĐHCT, giảng viên tham gia giảng dạy CTĐTCLC và CTĐTTT còn có những quyền như sau:

- Được ưu tiên sử dụng trang thiết bị phục vụ cho việc giảng dạy và NCKH để đáp ứng các yêu cầu của CTĐTCLC và CTĐTTT;

- Được tạo điều kiện để áp dụng các phương pháp dạy học tiên tiến phù hợp với điều kiện thực tiễn của Trường ĐHCT;

- Được chủ động liên hệ và đề xuất với bộ phận phụ trách chuyên môn ngành đào tạo và Trường đối tác trong và ngoài nước hợp tác giảng dạy và NCKH;

- Được tạo điều kiện tham gia các hội thảo trong nước và quốc tế do Trường ĐHCT và các đơn vị đối tác tổ chức.

#### Điều 16. Nhiệm vụ và quyền của sinh viên

1. Nhiệm vụ của sinh viên

Sinh viên CTĐTCLC và CTĐTTT thực hiện nhiệm vụ đối với người học theo quy định của Luật Giáo dục đại học và của Trường ĐHCT

---

12

<!-- page: 12 -->

2. Quyền của sinh viên

Ngoài những quyền của sinh viên theo quy định của Luật Giáo dục đại học và các quyền lợi khác của sinh viên CTĐT đại trà theo quy định của Bộ GD&ĐT và của Trường ĐHCT, sinh viên CTĐTCLC và CTDTTT còn có những quyền như sau:

- Được giảng dạy bởi các giảng viên như quy định đối với ĐTCLC và ĐTTT;

- Được ưu tiên bố trí học tập tại phòng học với các trang thiết bị hiện đại; sử dụng tài liệu học tập; phương tiện, trang thiết bị kỹ thuật, thư viện và hệ thống internet phục vụ cho học tập và NCKH;

- Được ưu tiên xét duyệt giao thực hiện đề tài NCKH.

- Được tạo điều kiện tham gia các hội thảo trong nước và quốc tế do Trường ĐHCT và các đơn vị đối tác tổ chức; các hoạt động chuyên môn; tham quan thực tế và các hoạt động ngoại khóa;

- Được ưu tiên xét chọn đi học tập ở nước ngoài theo các chương trình hợp tác quốc tế; chương trình trao đổi sinh viên với các cơ sở đào tạo nước ngoài của Trường ĐHCT;

- Ưu tiên xét cấp học bổng khuyến khích của các tổ chức, cá nhân trong và ngoài nước; xét vào ở ký túc xá của Trường ĐHCT; giới thiệu nơi thực tập và giới thiệu việc làm sau khi tốt nghiệp;

- Được tham gia đóng góp ý kiến để nâng cao chất lượng đào tạo và quản lý đào tạo CTĐTCLC và CTDTTT;

- Được hỗ trợ học phí một (01) lần khi học lần đầu học phần Thi đánh giá năng lực ngoại ngữ (*sinh viên phải đóng học phí học phần này cho Trường ĐHCT nếu có nhu cầu đăng ký học phần Thi đánh giá năng lực ngoại ngữ trong các lần tiếp theo*). Thời khóa biểu lần đầu học phần Thi đánh giá năng lực ngoại ngữ của sinh viên được Trường ĐHCT sắp xếp.

# CHƯƠNG V
# ĐIỀU KIỆN CƠ SỞ VẬT CHẤT PHỤC VỤ ĐÀO TẠO

#### Điều 17. Phòng học

Phòng học lý thuyết dành cho các lớp CTĐTCLC và CTDTTT được phủ sóng wifi với tốc độ kết nối cao; được trang bị máy tính kết nối mạng internet (*nếu cần thiết để phục vụ giảng dạy*), thiết bị trình chiếu (*ti vi màn hình lớn hoặc projector*) và hệ thống âm thanh để phục vụ giảng dạy; được trang bị máy điều hòa nhiệt độ.

#### Điều 18. Tài liệu giảng dạy

1. Tài liệu giảng dạy cho sinh viên CTĐTCLC và CTDTTT gồm: giáo trình hoặc bài giảng và tài liệu tham khảo; nội dung bài giảng; bài tập, câu hỏi... phục vụ học tập tại lớp và/hoặc giờ tự học của sinh viên; tài liệu hướng dẫn thực hành, thực tập; các tài liệu khác phục vụ cho việc học tập của sinh viên. Tài liệu giảng dạy được ghi rõ trong đề cương chi tiết học phần.

---

13

<!-- page: 13 -->

2. Học phần lý thuyết phải có đủ giáo trình hoặc bài giảng, tài liệu tham khảo trong, ngoài nước và được cập nhật thường xuyên. Nội dung bài giảng được cung cấp bởi giảng viên giảng dạy học phần; phải có phần nội dung cơ bản đáp ứng mục tiêu đào tạo của học phần và phần nội dung nâng cao có cập nhật các thành tựu, tiến bộ mới của ngành đào tạo trong nước và quốc tế.

3. Học phần thực hành, thực tập phải có tài liệu hướng dẫn đầy đủ.

4. Học phần phải có tài liệu là hệ thống bài tập, câu hỏi... phục vụ việc học tập tại lớp và/hoặc giờ tự học của sinh viên. Nội dung bài tập, câu hỏi... phải giúp sinh viên tiếp thu và hệ thống kiến thức cơ bản; phát triển kiến thức chuyên môn chuyên sâu hơn; đồng thời thúc đẩy sinh viên rèn luyện các kỹ năng mềm. Nội dung yêu cầu sinh viên thực hiện trong giờ tự học phải được đưa vào nội dung đánh giá học phần.

5. Tài liệu giảng dạy là bản cứng (giấy) hoặc bản mềm (e-file). Sinh viên có thể tiếp cận, tra cứu được tài liệu học tập từ Trung tâm Học liệu hoặc từ hệ thống các thư viện của Trường ĐHCT.

#### Điều 19. Cơ sở vật chất phục vụ thực tập, thực hành

1. Có đủ các phòng thí nghiệm, xưởng thực hành, cơ sở thực tập với các thiết bị, dụng cụ, phần mềm cần thiết phục vụ giảng dạy thực tập, thực hành cho sinh viên theo yêu cầu của CTĐTCLC và CTĐTTT.

2. Có thư viện và thư viện điện tử cho giảng viên và sinh viên CTĐTCLC và CTĐTTT tra cứu và sử dụng trong giảng dạy, học tập và NCKH.

# CHƯƠNG VI

## NGHIÊN CỨU KHOA HỌC VÀ HỢP TÁC QUỐC TẾ

#### Điều 20. Nghiên cứu khoa học

1. Hàng năm, mỗi giảng viên cơ hữu tham gia giảng dạy học phần lý thuyết ngành ĐTCLC và ĐTTT phải có tối thiểu 01 công trình NCKH được đăng tạp chí khoa học (thuộc danh mục của Hội đồng Giáo sư Nhà nước) hoặc được nghiệm thu có nội dung liên quan đến ngành ĐTCLC và ĐTTT.

2. Trong cả khoá học, mỗi sinh viên CTĐTCLC và CTĐTTT phải tham gia NCKH theo nhóm nghiên cứu do các giảng viên hướng dẫn hoặc tham gia đề tài NCKH với giảng viên. Khuyến khích sinh viên tham dự các cuộc thi (trong và ngoài nước) có liên quan đến hoạt động khoa học và công nghệ, hoạt động đổi mới sáng tạo và khởi nghiệp dưới sự hướng dẫn của giảng viên; nếu đạt giải nhất, nhì, ba và khuyến khích từ cấp Trường trở lên, sinh viên được xác định hoàn thành yêu cầu tham gia NCKH (sinh viên nộp minh chứng đến đơn vị quản lý ngành ĐTCLC hoặc ĐTTT để được xem xét). ). Hàng năm, Trường trích tối thiểu 4% từ nguồn thu học phí ĐTCLC và ĐTTT cho hoạt động khoa học, công nghệ và đổi mới sáng tạo cho sinh viên CTĐTCLC và CTĐTTT.

3. Nếu có bài báo khoa học được đăng tạp chí khoa học trong nước hoặc quốc tế (thuộc danh mục của Hội đồng Giáo sư Nhà nước), sinh viên được cộng tối đa 1 (một)

---

14

<!-- page: 14 -->

điểm vào điểm học phần luận văn tốt nghiệp (*LVTN*) do Hội đồng bảo vệ LVTN chấm điểm (theo thang điểm 10), cụ thể: nếu học phần LVTN được chấm điểm ít hơn 9 điểm thì được cộng thêm 1 điểm; nếu học phần LVTN được chấm điểm từ 9 điểm trở lên thì được cộng điểm để điểm học phần LVTN là 10 điểm.

#### Điều 21. Hợp tác quốc tế

1. Thực hiện một số hoặc tất cả các hình thức hợp tác quốc tế để hỗ trợ phát triển CTĐTCLC và CTĐTTT: bồi dưỡng, trao đổi giảng viên và sinh viên; tổ chức hợp tác NCKH, tổ chức hội nghị, hội thảo khoa học, giao lưu học thuật; liên kết thư viện, trao đổi kinh nghiệm, thông tin, tài liệu, ấn phẩm khoa học; bảo đảm chất lượng giáo dục, kiểm định chất lượng CTĐT; tham gia các tổ chức khoa học, nghề nghiệp quốc tế liên quan đến CTĐTCLC và CTĐTTT.

2. Quản lý chuyên gia, giảng viên và sinh viên là người nước ngoài được thực hiện theo các quy định hiện hành của Nhà nước và của Trường ĐHCT.

# CHƯƠNG VII
# BẢO ĐẢM CHẤT LƯỢNG ĐÀO TẠO

#### Điều 22. Bảo đảm chất lượng và kiểm định chất lượng chương trình đào tạo

1. Tổ chức đào tạo CTĐTCLC và CTĐTTT phải tuân thủ các quy định về ĐTCLC và ĐTTT của Trường ĐHCT và quy định khác của pháp luật có liên quan.

2. Trung tâm Quản lý chất lượng phối hợp Tổ Đảm bảo chất lượng của đơn vị quản lý ngành ĐTCLC và ĐTTT định kỳ tổ chức lấy ý kiến của sinh viên sau mỗi học kỳ về nội dung, phương pháp giảng dạy, phương pháp đánh giá kết quả học tập và chuẩn đầu ra của giảng viên; công tác quản lý; điều kiện hỗ trợ về cơ sở vật chất; điều kiện và hỗ trợ NCKH; hợp tác quốc tế; các hoạt động tư vấn, hướng nghiệp và phục vụ sinh viên; và các vấn đề khác.

3. Tổ quản lý CTĐTCLC và Tổ quản lý CTĐTTT có trách nhiệm tổ chức trả lời những ý kiến, phản ánh của sinh viên và viên chức có liên quan đến CTĐTCLC và CTĐTTT; báo cáo, đề xuất và kiến nghị với Ban quản lý CTĐTCLC và Ban quản lý CTĐTTT những vấn đề không thuộc thẩm quyền giải quyết.

4. Ban quản lý CTĐTCLC và Ban quản lý CTĐTTT có trách nhiệm giải quyết và phản hồi các báo cáo, đề xuất, kiến nghị và phản ánh của Trung tâm Quản lý chất lượng, Tổ quản lý CTĐTCLC và Tổ quản lý CTĐTTT, giảng viên, viên chức và sinh viên.

5. Sau mỗi khóa tốt nghiệp, đơn vị quản lý ngành ĐTCLC và ĐTTT có trách nhiệm tổ chức rà soát, đánh giá và đề xuất với Trường ĐHCT các điều chỉnh sửa đổi, bổ sung CTĐTCLC và CTĐTTT nếu có. Những điều chỉnh sửa đổi, bổ sung CTĐTCLC và CTĐTTT do Hiệu trưởng quyết định.

6. Kiểm định chất lượng CTĐTCLC và CTĐTTT

Trung tâm Quản lý chất lượng và đơn vị quản lý ngành ĐTCLC và ĐTTT phối hợp thực hiện:

---

15

<!-- page: 15 -->

a) Tổ chức tự đánh giá chất lượng CTĐTCLC và CTĐTTT và có kế hoạch chuẩn bị các điều kiện cho kiểm định chất lượng CTĐTCLC và CTĐTTT;

b) Đăng ký kiểm định chất lượng CTĐTCLC và CTĐTTT, đáp ứng quy định về kiểm định chất lượng CTĐT của Bộ GD&ĐT;

c) Lập kế hoạch, lộ trình và thực hiện đăng ký kiểm định chất lượng CTĐTCLC và CTĐTTT với tổ chức kiểm định chất lượng được Bộ GD&ĐT công nhận.

# CHƯƠNG VIII

# HỌC PHÍ VÀ MIỄN GIẢM HỌC PHÍ, QUỸ HỌC BỔNG VÀ HỌC BỔNG

#### Điều 23. Học phí và miễn, giảm học phí

1. Học phí của từng CTĐTCLC và CTĐTTT được xác định trên cơ sở tính đúng, tính đủ chi phí đào tạo cho toàn khóa học. Đề án của từng CTĐTCLC và CTĐTTT phải ghi rõ mức học phí; lộ trình điều chỉnh mức học phí cho những khóa học tiếp theo (nếu cần thiết); phương án thu, chi và quản lý kinh phí để đảm bảo thực hiện đầy đủ các tiêu chí của CTĐTCLC (bao gồm cả miễn, giảm học phí cho sinh viên thuộc diện chính sách được nhận hỗ trợ tài chính của Nhà nước); thực hiện trích lập các quỹ theo quy định hiện hành đối với phần chênh lệch thu chi còn lại. Mức học phí và lộ trình điều chỉnh mức học phí cho phù hợp với chi phí đào tạo thực tế (nếu có) của CTĐTCLC và CTĐTTT được ghi rõ trong thông báo tuyển sinh, thông báo về học phí hàng năm của Trường ĐHCT; được công bố công khai trên trang thông tin điện tử của Trường ĐHCT.

2. Sinh viên CTĐTCLC và CTĐTTT thuộc diện chính sách được nhận hỗ trợ tài chính của Nhà nước; sinh viên được miễn, giảm học phí theo quy định của Nhà nước vẫn phải thực hiện nghĩa vụ nộp phần học phí chênh lệch (nếu có) của CTĐTCLC và CTĐTTT so với CTĐT đại trà.

3. Sinh viên CTĐTCLC và CTĐTTT là người nước ngoài đóng học phí theo Quy định hiện hành về tiếp nhận và đào tạo sinh viên nước ngoài đến học tập, nghiên cứu tại Trường ĐHCT.

#### Điều 24. Quỹ học bổng và học bổng

1. Trường dành tối thiểu bằng 8% tổng thu học phí ĐTCLC và ĐTTT để chi trả học bổng khuyến khích học tập cho sinh viên CTĐTCLC và CTĐTT.

2. “Quỹ học bổng khuyến khích học tập dành cho sinh viên CTĐTCLC và CTĐTTT” được sử dụng để cấp học bổng cho sinh viên CTĐTCLC và CTĐTTT theo quy định của Trường ĐHCT. Hiệu trưởng quyết định mức học bổng và số lượng sinh viên được nhận học bổng cho từng ngành ĐTCLC và ĐTTT.

3. Ngoài việc được hưởng học bổng theo quy định tại khoản 2 Điều này, sinh viên CTĐTCLC và CTĐTTT được xem xét nhận các học bổng khác theo quy định của Nhà nước hoặc học bổng của các tổ chức, cá nhân tài trợ nếu đáp ứng các điều kiện của học bổng.

---

16

<!-- page: 16 -->

# CHƯƠNG IX
# KHEN THƯỞNG VÀ KỶ LUẬT

#### Điều 25. Khen thưởng, kỷ luật đối với sinh viên

Nội dung, hình thức khen thưởng, kỷ luật đối với sinh viên CTĐTCLC và CTĐTTT được áp dụng theo Quy định công tác học vụ dành cho sinh viên trình độ đại học hình thức chính quy của Trường ĐHCT và các quy định khác có liên quan của Bộ GD&ĐT và của Trường ĐHCT.

#### Điều 26. Khen thưởng, kỷ luật đối với viên chức

Nội dung, hình thức khen thưởng, kỷ luật đối với viên chức tham gia quản lý, giảng dạy, cố vấn học tập CTĐTCLC và CTĐTTT được áp dụng theo Luật Viên chức, pháp luật về lao động và các quy định khác có liên quan của Nhà nước và của Trường ĐHCT.

# CHƯƠNG X
# TỔ CHỨC THỰC HIỆN

#### Điều 27. Trách nhiệm tổ chức thực hiện

1. Thủ trưởng đơn vị có đào tạo CTĐTCLC và CTĐTTT chịu trách nhiệm tổ chức phổ biến Quy định này cho giảng viên, viên chức và sinh viên tại đơn vị; kiểm tra việc thực hiện Quy định này và báo cáo cho Hiệu trưởng khi được yêu cầu.

2. Phòng Thanh tra - Pháp chế, Phòng Đào tạo phối hợp với các đơn vị tổ chức kiểm tra việc thực hiện Quy định này và báo cáo cho Hiệu trưởng.

#### Điều 28. Điều khoản thi hành

1. Trong trường hợp các văn bản quy phạm pháp luật hoặc văn bản của Trường ban hành được dẫn chiếu hoặc là căn cứ ban hành Quy định này được sửa đổi, bổ sung, thay thế thì thực hiện theo các quy định tại các văn bản sửa đổi, bổ sung, thay thế đó.

2. Lãnh đạo các đơn vị và cá nhân có liên quan chịu trách nhiệm thực hiện Quy định này; báo cáo kịp thời những vấn đề phát sinh trong quá trình thực hiện để Hiệu trưởng xem xét và quyết định./.

**KT. HIỆU TRƯỞNG**
**PHÓ HIỆU TRƯỞNG**

Dấu mộc Trường Đại học Cần Thơ và chữ ký của Trần Trung Tính

**Trần Trung Tính**

---

17

<!-- page: 17 -->

<u>**Phụ lục: Quy đổi tương đương chứng chỉ ngoại ngữ theo Khung năng lực ngoại ngữ 6 bậc dùng cho Việt Nam**</u>

1. Tiếng Anh

- Chứng chỉ IELTS (*International English Language Testing System*) do Hội đồng Anh (*British Council*) và Tổ chức Giáo dục quốc tế IDP (*IDP Education Viet Nam*) cấp.

- Chứng chỉ TOEIC (*Test of English for International Communication*), TOEFL (*Test of English as a Foreign Language*) do Educational Testing Service (ETS) và IIG Việt Nam cấp.

- Chứng chỉ Cambridge ESOL do Tổ chức Cambridge English cấp.

- Chứng chỉ ngoại ngữ tiếng Anh theo Khung năng lực Ngoại ngữ 6 bậc dùng cho Việt Nam do các đơn vị được Bộ Giáo dục và Đào tạo công nhận cấp.

## BẢNG QUY ĐỔI CHUẨN TRÌNH ĐỘ NGOẠI NGỮ TIẾNG ANH

| Khung NLNN 6 bậc dùng cho Việt Nam | Khung tham chiếu Châu Âu (CEFR) | IELTS | TOEIC (L&R) | TOEIC Bridge | TOEFL ITP | TOEFL CBT | TOEFL iBT | Cambridge Tests |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | A1 |  | 120-220 | 30-42 |  | 60 |  | 100-120 KET |
| 2 | A2 | 4.0 | 225-445 | 43-75 | 360-449 | 96 | 30 | 120-140 KET<br>120-140 PET |
| 3 | B1 | 4.5-5.0 | 450-595 | 76-89 | 450-499 | 133 | 31-45 | 140-150 KET<br>140-160 PET<br>140-160 FCE |
| 4 | B2 | 5.5-6.5 | 600-845 | 90-100 | 500-589 | 173 | 46-93 | 160-170 PET<br>160-180 FCE<br>160-180 CAE |
| 5 | C1 | 7.0-7.5 | 850-940 |  | 590-649 | 213 | 94-109 | 180-190 FCE<br>180-200 CAE<br>180-200 CPE |
| 6 | C2 | 8.0-9.0 | 945-990 |  | 650-677 | 250 | 110-120 | 200-210 CAE<br>200-230 CPE |
|  |  | Top Score 9 | Top Score 990 | Top Score 100 | Top Score 677 | Top Score 300 | Top Score 120 IBT |  |

---

18

<!-- page: 18 -->

### 2. Tiếng Pháp

- Bằng DELF (*Diplôme d'Etudes en Langue Française*), DALF (*Diplôme Approfondi de Langue Française*) của Trung tâm Nghiên cứu Sư phạm Quốc tế Sèvres - Pháp (*Centre International d'Etudes Pédagogiques de Sèvres*).

- Chứng chỉ TCF (*Test de Connaissance du Français*) của Trung tâm Nghiên cứu Sư phạm Quốc tế Sèvres - Pháp (*Centre International d'Etudes Pédagogiques de Sèvres*) cấp.

- Chứng chỉ TEF (*Test d'Evaluation de Français*) của CCIP (*Chambre d'Industrie et de Commerce de Paris*) cấp.

- Chứng chỉ ngoại ngữ tiếng Pháp theo Khung năng lực Ngoại ngữ 6 bậc dùng cho Việt Nam do các đơn vị được Bộ Giáo dục và Đào tạo công nhận cấp.

### BẢNG QUY ĐỔI CHUẨN TRÌNH ĐỘ NGOẠI NGỮ TIẾNG PHÁP

| Khung NLNN 6 bậc dùng cho Việt Nam | Khung tham chiếu Châu Âu (CEFR) | DELF | TCF | TEF |
| --- | --- | --- | --- | --- |
| 1 | A1 | **DELF A1**<br>trình độ giao tiếp ban đầu sơ cấp khám phá (découverte) | TCF1 (100-199) | TEF1 (69-203) |
| 2 | A2 | **DELF A2**<br>trình độ giao tiếp sơ trung cấp (survie) | TCF2 (200-299) | TEF2 (204-360) |
| 3 | B1 | **DELF B1**<br>trình độ giao tiếp ngưỡng (seuil) | TCF3 (300-399) | TEF3 (361-540) |
| 4 | B2 | **DELF B2**<br>trình độ giao tiếp độc lập (indépendant) | TCF4 (400-499) | TEF4 (541-698) |
| 5 | C1 | **DALF C1**<br>trình độ giao tiếp tự chủ (autonome) | TCF5 (500-599) | TEF5 (699-833) |
| 6 | C2 | **DALF C2**<br>giao tiếp ở trình độ cao (maîtrise) | TCF6 (600-699) | TEF5 (834-900) |

---

19

<!-- page: 19 -->

### 3. Tiếng Nga

- Chứng chỉ TORFL, TRKI, ТБУ do Trung tâm Văn hóa Nga cấp (*Kỳ thi TRKI có tên gọi tiếng Anh là: Test of Russian as a Foreign Language*).

- Chứng chỉ ngoại ngữ tiếng Nga theo Khung năng lực Ngoại ngữ 6 bậc dùng cho Việt Nam do các đơn vị được Bộ Giáo dục và Đào tạo công nhận cấp.

**BẢNG QUY ĐỔI CHUẨN TRÌNH ĐỘ NGOẠI NGỮ TIẾNG NGA**

| Khung NLNN 6 bậc dùng cho Việt Nam | Khung tham chiếu Châu Âu (CEFR) | ТРКИ (TRKI) | Ghi chú |
| --- | --- | --- | --- |
| 1 | A1<br>(Breakthrough) | ТЭУ (TEU)<br>Elementary Level | Chứng nhận có khả năng tối thiểu để giao tiếp hàng ngày |
| 2 | A2<br>(Waystage) | ТБУ (TBU)<br>Immediate Level | Chứng nhận có trình độ sơ cấp về khả năng giao tiếp trong nghề nghiệp, xã hội và văn hóa |
| 3 | B1<br>(Threshold) | ТРКИ-1 (TRKI-1)<br>Certificate Level 1 | Chứng nhận có trình độ trung cấp về khả năng giao tiếp trong nghề nghiệp, văn hóa và xã hội. (Đây là chứng chỉ bắt buộc để học ở các trường ĐH của Nga) |
| 4 | B2<br>(Vantage) | ТРКИ-2 (TRKI-2)<br>Certificate Level 2 | Chứng nhận có trình độ cao để giao tiếp trong tất cả các lĩnh vực của cuộc sống. Người học có thể làm việc bằng tiếng Nga trong các lĩnh vực khác nhau. (Đây là chứng chỉ bắt buộc để nhận bằng cử nhân hoặc thạc sĩ) |
| 5 | C1<br>(Effective Operational Proficiency) | ТРКИ-3 (TRKI-3)<br>Certificate Level 3 | Chứng nhận đạt được trình độ cao để giao tiếp trong các lĩnh vực, cho phép người học làm việc bằng tiếng Nga với tư cách là một nhà ngôn ngữ học, nhà dịch thuật, chủ biên của một tạp chí, nhà ngoại giao và nhà lãnh đạo của một cộng đồng nói tiếng Nga |
| 6 | C2<br>(Mastery) | ТРКИ-4 (TRKI-4)<br>Certificate Level 4 | Chứng nhận đạt được khả năng nắm vững tiếng Nga một cách thông thạo, gần với trình độ của một người bản ngữ. (Đây là chứng chỉ bắt buộc để nhận bằng tốt nghiệp thạc sĩ và tiến sĩ ngôn ngữ học) |

---

20

<!-- page: 20 -->

### 4. Tiếng Trung Quốc

- Chứng chỉ HSK với "tiêu chuẩn năng lực Hán ngữ quốc tế" theo khung tham chiếu châu Âu do Tổ chức Hán Ban, Trung Quốc cấp.

- Chứng chỉ ngoại ngữ tiếng Trung Quốc theo Khung năng lực Ngoại ngữ 6 bậc dùng cho Việt Nam do các đơn vị được Bộ Giáo dục và Đào tạo công nhận cấp.

### BẢNG QUY ĐỔI CHUẨN TRÌNH ĐỘ NGOẠI NGỮ TIẾNG TRUNG QUỐC

| Khung NLNN 6 bậc dùng cho Việt Nam | Khung tham chiếu Châu Âu (CEFR) | Tiêu chuẩn năng lực tiếng Trung quốc tế | HSK mới | Lượng từ vựng |
| --- | --- | --- | --- | --- |
| 1 | A1 | Cấp 1 | HSK cấp 1 | 150 |
| 2 | A2 | Cấp 2 | HSK cấp 2 | 300 |
| 3 | B1 | Cấp 3 | HSK cấp 3 | 600 |
| 4 | B2 | Cấp 4 | HSK cấp 4 | 1200 |
| 5 | C1 | Cấp 5 | HSK cấp 5 | 2500 |
| 6 | C2 | Cấp 6 | HSK cấp 6 | Hơn 5000 |

### 5. Tiếng Hàn

- Chứng chỉ Topik (*Bằng topik*) là kỳ thi năng lực tiếng Hàn do Viện giáo dục quốc tế Quốc gia Hàn Quốc cấp.

- Chứng chỉ ngoại ngữ tiếng Hàn Quốc theo Khung năng lực Ngoại ngữ 6 bậc dùng cho Việt Nam do các đơn vị được Bộ Giáo dục và Đào tạo công nhận cấp.

### BẢNG QUY ĐỔI CHUẨN TRÌNH ĐỘ NGOẠI NGỮ TIẾNG HÀN

| Khung NLNN 6 bậc dùng cho Việt Nam | Khung tham chiếu Châu Âu (CEFR) | TOPIK |
| --- | --- | --- |
| 1 | A1 | Cấp 1 |
| 2 | A2 | Cấp 2 |
| 3 | B1 | Cấp 3 |
| 4 | B2 | Cấp 4 |
| 5 | C1 | Cấp 5 |
| 6 | C2 | Cấp 6 |

### 6. Tiếng Nhật

- Chứng chỉ tiếng Nhật JLPT được cấp bởi Trung tâm Giao lưu Văn hoá Nhật Bản và Hiệp hội hỗ trợ giáo dục Quốc tế Nhật Bản.

---

21

<!-- page: 21 -->

- Chứng chỉ tiếng Nhật NAT-TEST được cấp bởi Ban tổ chức thi tiếng Nhật NAT-TEST (*Senmon Kyouiku Publishing Co., Ltd.*).

- Chứng chỉ tiếng Nhật J-TOP được cấp bởi Quỹ học bổng giao lưu quốc tế Châu Á (AF).

- Chứng chỉ ngoại ngữ tiếng Nhật theo Khung năng lực Ngoại ngữ 6 bậc dùng cho Việt Nam do các đơn vị được Bộ Giáo dục và Đào tạo công nhận cấp.

**BẢNG QUY ĐỔI CHUẨN TRÌNH ĐỘ NGOẠI NGỮ TIẾNG NHẬT**

| Khung NLNN 6 bậc dùng cho Việt Nam | Khung tham chiếu Châu Âu (CEFR) | JLPT | NAT-TEST | TOP-J |
| --- | --- | --- | --- | --- |
| 1 | A1 |  |  |  |
| 2 | A2 | N5 | 5Q | Sơ cấp A |
| 3 | B1 | N4 | 4Q | Trung cấp B |
| 4 | B2 | N3 | 3Q | Trung cấp A |
| 5 | C1 | N2 | 2Q | Nâng cao B |
| 6 | C2 | N1 | 1Q | Nâng cao A |

### 7. Tiếng Đức

- Chứng chỉ tiếng Đức được cấp bởi Viện Goethe là Tổ chức Văn hóa của Cộng hòa Liên bang Đức.

- Chứng chỉ ngoại ngữ tiếng Đức theo Khung năng lực Ngoại ngữ 6 bậc dùng cho Việt Nam do các đơn vị được Bộ Giáo dục và Đào tạo công nhận cấp.

**BẢNG QUY ĐỔI CHUẨN TRÌNH ĐỘ NGOẠI NGỮ TIẾNG ĐỨC**

| Khung NLNN 6 bậc dùng cho Việt Nam | Khung tham chiếu Châu Âu (CEFR) | Goethe- Zertifikat | TestDaF |
| --- | --- | --- | --- |
| 1 | A1 | Start Deutsch 1 |  |
| 2 | A2 | Start Deutsch 2 |  |
| 3 | B1 | Zertifikat Deutsch (ZD) | TestDaF-Niveaustufe 3<br>(TDN 3) |
| 4 | B2 | Goethe-Zertifikat B2 | TestDaF-Niveaustufe 4<br>(TDN 4) |
| 5 | C1 | Goethe-Zertifikat C1 | TestDaF-Niveaustufe 5<br>(TDN 5) |
| 6 | C2 | Kleines/Groes Deutsches (KDS/GDS) Sprachdiplom |  |

---

22

<!-- page: 22 -->

### 8. Tiếng Ý

- Chứng chỉ tiếng Ý CELI được cấp bởi Đại học dành cho người nước ngoài Perugia (*Università per Stranieri di Perugia*).

- Chứng chỉ tiếng Ý PLIDA được cấp bởi Đại học Rome La Sapienza.

- Chứng chỉ ngoại ngữ tiếng Ý theo Khung năng lực Ngoại ngữ 6 bậc dùng cho Việt Nam do các đơn vị được Bộ Giáo dục và Đào tạo công nhận cấp.

### BẢNG QUY ĐỔI CHUẨN TRÌNH ĐỘ NGOẠI NGỮ TIẾNG Ý

| Khung NLNN 6 bậc dùng cho Việt Nam | Khung tham chiếu Châu Âu (CEFR) | CELI | PLIDA |
| --- | --- | --- | --- |
| 1 | A1 | Impatto | A1 |
| 2 | A2 | 1 | A2 |
| 3 | B1 | 2 | B1 |
| 4 | B2 | 3 | B2 |
| 5 | C1 | 4 | C1 |
| 6 | C2 | 5 | C2 |

### 9. Tiếng Tây Ban Nha

- Chứng chỉ tiếng Tây Ban Nha được cấp bởi Viện Cervantes.

- Chứng chỉ ngoại ngữ tiếng Tây Ban Nha theo Khung năng lực Ngoại ngữ 6 bậc dùng cho Việt Nam do các đơn vị được Bộ Giáo dục và Đào tạo công nhận cấp.

### BẢNG QUY ĐỔI CHUẨN TRÌNH ĐỘ NGOẠI NGỮ TIẾNG TÂY BAN NHA

| Khung NLNN 6 bậc dùng cho Việt Nam | Khung tham chiếu Châu Âu (CEFR) | DELE |
| --- | --- | --- |
| 1 | A1 | A1 |
| 2 | A2 | A2 |
| 3 | B1 | B1 |
| 4 | B2 | B2 |
| 5 | C1 | C1 |
| 6 | C2 | C2 |
