1

<!-- page: 1 -->

**BỘ GIÁO DỤC VÀ ĐÀO TẠO**
**CỘNG HOÀ XÃ HỘI CHỦ NGHĨA VIỆT NAM**
**Độc lập - Tự do - Hạnh phúc**

Số: 04 /2011/TT-BGDĐT
Hà Nội, ngày 28 tháng 1 năm 2011

# THÔNG TƯ

## Ban hành Quy định việc biên soạn, lựa chọn, thẩm định, duyệt và sử dụng giáo trình giáo dục đại học

Căn cứ Nghị định số 178/2007/NĐ-CP ngày 03 tháng 12 năm 2007 của Chính phủ quy định chức năng, nhiệm vụ, quyền hạn và cơ cấu tổ chức của Bộ, cơ quan ngang Bộ;
Căn cứ Nghị định số 32/2008/NĐ- CP ngày 19 tháng 3 năm 2008 của Chính phủ quy định chức năng, nhiệm vụ, quyền hạn và cơ cấu tổ chức của Bộ Giáo dục và Đào tạo;
Căn cứ Nghị định số 75/2006/NĐ-CP ngày 02 tháng 8 năm 2006 của Chính phủ quy định chi tiết và hướng dẫn thi hành một số điều của Luật Giáo dục;
Theo đề nghị của Vụ trưởng Vụ Giáo dục Đại học;
Bộ trưởng Bộ Giáo dục và Đào tạo quyết định:

#### Điều 1. Ban hành kèm theo Thông tư này Quy định việc biên soạn, lựa chọn, thẩm định, duyệt và sử dụng giáo trình giáo dục đại học

#### Điều 2. Thông tư này có hiệu lực kể từ ngày 15 tháng 3 năm 2011.

#### Điều 3. Chánh Văn phòng, Vụ trưởng Vụ Giáo dục Đại học, Thủ trưởng các đơn vị có liên quan thuộc Bộ Giáo dục và Đào tạo; Giám đốc các đại học, học viện, Hiệu trưởng các trường đại học, cao đẳng chịu trách nhiệm thi hành Thông tư này.

***Nơi nhận:***

- Văn phòng Chính phủ;
- Văn phòng Chủ tịch nước;
- UBVHGDTTN, NĐ của Quốc hội;
- Ban Tuyên giáo TW;
- Kiểm toán Nhà nước;
- Bộ trưởng Phạm Vũ Luận;
- Các Bộ, cơ quan ngang Bộ, cơ quan thuộc Chính phủ;
- Như điều 3;
- Bộ Tư pháp (Cục K.tr.VBQPPL);
- Công báo;
- Website Chính phủ;
- Website Bộ GD&ĐT;
- Lưu VT, Vụ PC, Vụ GDĐH.

**KT. BỘ TRƯỞNG**
**THỨ TRƯỞNG**

Đã ký

**Bùi Văn Ga**

---

2

<!-- page: 2 -->

**BỘ GIÁO DỤC VÀ ĐÀO TẠO**
**CỘNG HOÀ XÃ HỘI CHỦ NGHĨA VIỆT NAM**
**Độc lập - Tự do - Hạnh phúc**

# QUY ĐỊNH

## Về việc biên soạn, lựa chọn, thẩm định, duyệt và sử dụng giáo trình giáo dục đại học

*(Ban hành kèm theo Thông tư số 04 /2011/TT-BGDĐT ngày 28 tháng 1 năm 2011 của Bộ trưởng Bộ Giáo dục và Đào tạo)*

---

## Chương I - QUY ĐỊNH CHUNG

#### Điều 1. Phạm vi điều chỉnh và đối tượng áp dụng

1. Văn bản này quy định về việc biên soạn, lựa chọn, thẩm định, duyệt và sử dụng giáo trình giáo dục đại học, sau đây gọi chung là giáo trình.
2. Quy định này áp dụng đối với các đại học, học viện, trường đại học, trường cao đẳng (sau đây gọi chung là cơ sở giáo dục đại học) trong hệ thống giáo dục quốc dân.
3. Quy định này không áp dụng đối với việc tổ chức biên soạn và duyệt giáo trình sử dụng chung cho các đại học, học viện, trường đại học, trường cao đẳng.

#### Điều 2. Giáo trình dùng trong các cơ sở giáo dục đại học.

1. Giáo trình phục vụ cho việc giảng dạy, chuẩn bị bài giảng của giảng viên và học tập của sinh viên đối với các môn học có trong chương trình đào tạo.
2. Giáo trình do cơ sở giáo dục đại học tổ chức biên soạn hoặc tổ chức lựa chọn đối với trình độ cao đẳng, đại học, thạc sĩ.

#### Điều 3. Ngôn ngữ dùng để biên soạn giáo trình

1. Ngôn ngữ dùng để biên soạn giáo trình là tiếng Việt.
2. Giáo trình một số môn học của cơ sở giáo dục đại học thực hiện chương trình tiên tiến, chương trình đào tạo ngôn ngữ và văn hóa nước ngoài, chương trình liên kết đào tạo với nước ngoài và một số chương trình đào tạo khác giảng dạy bằng tiếng nước ngoài được biên soạn bằng tiếng nước ngoài.

#### Điều 4. Yêu cầu đối với giáo trình

1. Giáo trình cụ thể hóa yêu cầu về nội dung kiến thức, kỹ năng và thái độ quy định trong chương trình đào tạo đối với mỗi môn học, ngành học, trình độ đào tạo, đáp ứng yêu cầu đổi mới phương pháp giáo dục đại học và kiểm tra, đánh giá chất lượng đào tạo.
2. Nội dung giáo trình phải phù hợp với mục tiêu, chương trình đào tạo, đảm bảo chuẩn kiến thức, kỹ năng và chuẩn đầu ra đã ban hành.
3. Kiến thức trong giáo trình được trình bày khoa học, logic, đảm bảo cân đối giữa lý luận và thực hành, phù hợp với thực tiễn và cập nhật những tri thức mới nhất của khoa học và công nghệ.
4. Những nội dung được trích dẫn trong tài liệu tham khảo để biên soạn giáo trình phải có nguồn gốc và chú thích rõ ràng, đáp ứng đầy đủ các yêu cầu về quyền tác giả theo quy định hiện hành.
5. Cuối mỗi chương giáo trình phải có danh mục tài liệu tham khảo, câu hỏi hướng dẫn ôn tập, định hướng thảo luận và bài tập thực hành.
6. Hình thức và cấu trúc của giáo trình đảm bảo tính đồng bộ và tuân thủ các quy định cụ thể của cơ sở giáo dục đại học.

---

3

<!-- page: 3 -->

#### Điều 5. Sử dụng giáo trình

1. Cơ sở giáo dục đại học tổ chức biên soạn hoặc lựa chọn giáo trình để sử dụng, đảm bảo mỗi môn học có ít nhất một giáo trình phục vụ công tác giảng dạy của giảng viên và học tập của sinh viên.
2. Các giáo trình đã xuất bản, cơ sở giáo dục đại học có thể bán, cho thuê, cho mượn,... để phục vụ giảng dạy của giảng viên và học tập của sinh viên theo Luật xuất bản và các quy định hiện hành.

#### Điều 6. Kinh phí biên soạn, lựa chọn, thẩm định và duyệt giáo trình

Thủ trưởng cơ sở giáo dục đại học chịu trách nhiệm về kinh phí tổ chức biên soạn, lựa chọn, thẩm định và duyệt giáo trình theo quy định hiện hành.

# Chương II - BIÊN SOẠN VÀ THẨM ĐỊNH NỘI DUNG GIÁO TRÌNH

#### Điều 7. Quy trình tổ chức biên soạn giáo trình

1. Trên cơ sở đề nghị của Khoa, Hiệu trưởng chỉ đạo, tổ chức biên soạn giáo trình để phục vụ giảng dạy, học tập cho các môn học trong chương trình đào tạo của Khoa.
2. Hội đồng Khoa học-Đào tạo Khoa đề xuất với Hiệu trưởng thành lập Ban biên soạn giáo trình hoặc giao nhiệm vụ trực tiếp cho cá nhân nhà khoa học có trình độ, đúng chuyên môn và kinh nghiệm biên soạn giáo trình.
3. Ban biên soạn giáo trình hoặc cá nhân nhà khoa học chịu trách nhiệm xây dựng dự thảo đề cương chi tiết giáo trình môn học và báo cáo Hội đồng Khoa học-Đào tạo Khoa.
4. Hiệu trưởng duyệt đề cương chi tiết giáo trình môn học và giao nhiệm vụ cho Ban biên soạn hoặc cá nhân nhà khoa học thực hiện biên soạn giáo trình.
5. Ban biên soạn giáo trình hoặc cá nhân nhà khoa học chịu trách nhiệm biên soạn giáo trình theo đề cương đã được duyệt.
6. Hiệu trưởng quyết định thành lập Hội đồng thẩm định giáo trình. Hội đồng thẩm định giáo trình tổ chức thẩm định giáo trình đã biên soạn, báo cáo ý kiến đánh giá của Hội đồng lên Hiệu trưởng.
7. Căn cứ vào ý kiến của Hội đồng thẩm định, Hiệu trưởng xem xét, quyết định đưa giáo trình in ấn, xuất bản.
8. Hàng năm, trên cơ sở đề xuất của Khoa, Hiệu trưởng xem xét, quyết định việc tiếp thu, chỉnh lý giáo trình đang sử dụng cho phù hợp với thực tiễn.

#### Điều 8. Thành phần Ban biên soạn giáo trình

1. Thành phần Ban biên soạn giáo trình gồm có:

a) Chủ biên hoặc đồng chủ biên và các thành viên (nếu có). Chủ biên hoặc đồng chủ biên giáo trình các môn học của chương trình đào tạo trình độ cao đẳng, đại học, thạc sĩ phải có chức danh giáo sư, phó Giáo sư hoặc trình độ tiến sỹ thuộc chuyên ngành của giáo trình đó.

Đối với giáo trình trình độ cao đẳng, trong trường hợp không có tiến sĩ cùng chuyên ngành thì chủ biên hoặc đồng chủ biên tối thiểu phải có trình độ thạc sỹ.

b) Các thành viên tham gia Ban biên soạn giáo trình phải có chuyên môn phù hợp với nội dung giáo trình và đang trực tiếp giảng dạy trình độ cao đẳng, đại học, thạc sỹ hoặc các nhà khoa học có uy tín đang tham gia thỉnh giảng tại trường và do Hiệu trưởng quyết định.

2. Hiệu trưởng quyết định số lượng thành viên tham gia Ban biên soạn giáo trình hoặc cá nhân nhà khoa học biên soạn giáo trình.

---

4

<!-- page: 4 -->

3. Hiệu trưởng quy định thành phần, tổ chức và hoạt động của Ban biên soạn giáo trình bằng văn bản.

#### Điều 9. Nhiệm vụ và quyền của chủ biên/đồng chủ biên

1. Tổ chức biên soạn giáo trình theo đúng đề cương giáo trình đã được Hiệu trưởng phê duyệt.
2. Chịu trách nhiệm về nội dung khoa học của giáo trình, tiếp thu, sửa chữa nội dung giáo trình theo góp ý của các nhà khoa học và ý kiến kết luận của Hội đồng thẩm định.
3. Đề xuất với Hiệu trưởng thay thế hoặc bổ sung thành viên tham gia biên soạn giáo trình khi thấy cần thiết.
4. Được hưởng các chế độ theo quy định hiện hành của Nhà nước và các chính sách của cơ sở giáo dục đại học đối với việc biên soạn giáo trình.

#### Điều 10. Trách nhiệm, nghĩa vụ và quyền của tác giả

1. Trách nhiệm, nghĩa vụ:

a) Tác giả chịu trách nhiệm về nội dung khoa học của giáo trình, chịu sự chỉ đạo về mặt chuyên môn của chủ biên hoặc đồng chủ biên và Hội đồng Khoa học-Đào tạo Khoa trong quá trình biên soạn giáo trình và về bản quyền tác giả theo quy định hiện hành của Nhà nước;

b) Tác giả có nghĩa vụ tuân thủ các phân công công việc của chủ biên, đảm bảo trung thực và làm việc khoa học đối với phần được phân công viết, đảm bảo thực hiện đúng tiến độ thời gian, sử dụng ngôn ngữ, văn phong,… thống nhất chung của toàn bộ giáo trình, thực hiện biểu quyết theo đa số.

2. Quyền lợi:

a) Tác giả được hưởng các chế độ nhuận bút, bản quyền tác giả theo quy định hiện hành của Nhà nước;

b) Tác giả được ưu tiên khai thác những tài liệu, cơ sở dữ liệu các loại của cơ sở giáo dục đại học;

c) Tác giả được quyền góp ý về cấu trúc, nội dung của các phần không được phân công viết trong giáo trình nhưng phải tuân thủ quyết định của chủ biên hoặc đồng chủ biên.

#### Điều 11. Tổ chức thẩm định giáo trình

1. Hiệu trưởng quyết định thành lập Hội đồng thẩm định giáo trình để thẩm định giáo trình.
2. Số lượng thành viên Hội đồng thẩm định giáo trình do Hiệu trưởng quyết định, trong đó có 1 Chủ tịch Hội đồng, 2 phản biện, 1 ủy viên thư ký và các ủy viên. Tham gia Hội đồng thẩm định giáo trình phải có ít nhất 02 thành viên ngoài trường, đại diện cho đơn vị sử dụng lao động.
3. Thành viên Hội đồng thẩm định phải là những người có chuyên môn phù hợp với nội dung giáo trình, là các nhà khoa học có trình độ chuyên môn cao, có uy tín và kinh nghiệm giảng dạy đại học.
4. Hội đồng thẩm định tổ chức thẩm định và đề xuất với chủ biên/đồng chủ biên hoặc cá nhân các nhà khoa học tham gia biên soạn giáo trình xem xét, chỉnh sửa, hoàn thiện giáo trình. Hội đồng có thể mời một số thành viên đại biểu ngoài Hội đồng tham dự phiên họp thẩm định.
5. Quy định về tổ chức và hoạt động của Hội đồng thẩm định giáo trình do Hiệu trưởng quy định bằng văn bản.

---

5

<!-- page: 5 -->

# Chương III - LỰA CHỌN VÀ DUYỆT GIÁO TRÌNH

#### Điều 12. Tổ chức lựa chọn, duyệt giáo trình

Các cơ sở giáo dục đại học không đủ điều kiện tổ chức biên soạn giáo trình thì Hiệu trưởng tổ chức lựa chọn, duyệt giáo trình phù hợp với chương trình trình đào tạo để làm tài liệu giảng dạy, học tập chính thức.

#### Điều 13. Quy trình lựa chọn, duyệt giáo trình

1. Hội đồng Khoa học-Đào tạo Khoa đề xuất danh mục các giáo trình cần đưa vào giảng dạy, học tập theo chương trình đào tạo để trình Hiệu trưởng xem xét, tổ chức lựa chọn giáo trình phù hợp với chương trình đào tạo.
2. Hiệu trưởng thành lập Hội đồng lựa chọn giáo trình, duyệt danh mục giáo trình để đưa vào sử dụng chính thức trong nhà trường.
3. Căn cứ ý kiến của Hội đồng lựa chọn giáo trình, Hiệu trưởng xem xét và quyết định chọn giáo trình đã lựa chọn để phục vụ giảng dạy, học tập.
4. Hiệu trưởng có trách nhiệm xin phép chủ biên, tập thể tác giả hoặc cá nhân nhà khoa học và cơ sở đào tạo đã biên soạn giáo trình để được sử dụng giáo trình theo quy định của pháp luật về quyền tác giả và quyền sở hữu trí tuệ.
5. Hiệu trưởng quy định số lượng thành viên hội đồng và tổ chức hoạt động của Hội đồng lựa chọn giáo trình bằng văn bản.

# Chương IV - KIỂM TRA, KHEN THƯỞNG, XỬ LÝ VI PHẠM

#### Điều 14. Kiểm tra

Bộ Giáo dục và Đào tạo tổ chức kiểm tra trách nhiệm của Thủ trưởng cơ sở giáo dục đại học về công tác chỉ đạo, tổ chức biên soạn, lựa chọn, duyệt và thẩm định giáo trình của đơn vị theo quy định này.

#### Điều 15. Khen thưởng

Các cơ sở giáo dục đại học, các cá nhân thực hiện tốt Thông tư này, có nhiều đóng góp trong việc tổ chức, tham gia biên soạn, nâng cao chất lượng giáo trình được xét khen thưởng theo quy định của luật thi đua, khen thưởng.

#### Điều 16. Xử lý khiếu nại

Trong quá trình sử dụng giáo trình, nếu xảy ra khiếu nại về bản quyền, nội dung khoa học thì Thủ trưởng cơ sở giáo dục đại học xem xét và xử lý theo quy định hiện hành.

**KT. BỘ TRƯỞNG**
**THỨ TRƯỞNG**

Đã ký

**Bùi Văn Ga**
