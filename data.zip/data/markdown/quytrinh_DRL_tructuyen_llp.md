1

<!-- page: 1 -->

# QUY TRÌNH CÔNG TÁC ĐÁNH GIÁ ĐIỂM RÈN LUYỆN

## I. QUY TRÌNH CÔNG TÁC

### 1. CƠ SỞ THỰC HIỆN

#### 1.1 Mục đích, yêu cầu, phạm vi áp dụng

a. Mục đích: Kết quả điểm rèn luyện được dùng để xét học bổng khuyến khích, khen thưởng năm học, khen thưởng tốt nghiệp, …

b. Yêu cầu: Mỗi học kỳ, sinh viên thực hiện “Bảng đánh giá kết quả rèn luyện” qua hệ thống quản lý trực tuyến của Trường.

c. Phạm vi áp dụng: Sinh viên đang học tại Trường hệ chính quy (theo quy định hiện hành của Bộ Giáo dục và Đào tạo).

#### 1.2 Văn bản áp dụng:

- Thông tư số16/2016/TT-BGDĐT, ngày 05/04/2016 ban hành Quy chế công tác sinh viên đối với chương trình đào tạo đại học chính quy và các văn bản có liên quan;
- Thông tư số 16/2015/TT-BGDĐT, ngày 12/8/2015 ban hành Quy chế đánh giá kết quả rèn luyện của người học được đào tạo trình độ đại học hệ chính quy;
- Quyết định số 73/QĐ-ĐHCT, ngày 11/01/2017 của Hiệu trưởng Trường Đại học Cần Thơ ban hành Bảng đánh giá kết quả rèn luyện của sinh viên;

#### 1.3 Giải thích từ ngữ, từ viết tắt

- CTSV: Công tác Sin viên.
- ĐRL: Điểm rèn uyện.
- CVHT: Cố vấn học tập.
- QĐ: Quyết định.
- BGH: Ban Giám hiệu.
- SV: Sinh viên.

### 2 . QUY TRÌNH THỰC HIỆN

**Bước 1:** Thông báo kế hoạch triển khai đánh giá rèn luyện vào giữa mỗi học kỳ chính có quy định cụ thể thời gian thực hiện cập nhật dữ liệu từng giai đoạn;

**Bước 2:** Các đơn vị nhập liệu, đối tượng có liên quan vào Phân hệ **“Đánh giá rèn luyện”** trong Hệ thống quản lý của Trường thực hiện các nội dung sau:

### 1. Sinh viên: Tự kê khai

- Bài báo khoa học, đồng thời mang minh chứng nộp tại Phòng CTSV *(Điều 4.b.1)*;
- Tự kê khai chứng chỉ ngoại ngữ, tin học *(Điều 4.b.2)*.

### 2. Đoàn khoa:

- Nhập danh sách và điểm hoàn thành nhiệm vụ của Ban chấp hành chi đoàn *(Điều 8.a.1; Điều 8.b.1)*;

---

2

<!-- page: 2 -->

- Nhập danh sách SV tham gia hoạt động phong trào do Khoa chịu trách nhiệm tổ chức (*Điều 7.b.1; Điều 8.c.1*);
- Nhập danh sách SV là lực lượng nòng cốt của các phong trào cấp Khoa, bộ môn, lớp (*Điều 6.b.1*);
- Nhập danh sách SV tham gia các cuộc thi Olympic chuyên ngành do Khoa phụ trách (*Điều 4.b.3*);
- Nhập đề tài NCKH của SV (*Điều 4.b.1*);
- Đánh giá điểm (*định tính*) các nội dung: giữ gìn an ninh, trật tự công cộng, Giữ gìn vệ sinh, bảo vệ cảnh quan môi trường, nếp sống văn minh (do Đoàn Khoa xác nhận) (*Điều 5.b.1*);

### 3. Đoàn Trường:

- Nhập danh sách và điểm hoàn thành nhiệm vụ của Ban chấp hành Đoàn Khoa, Đoàn Trường, Hội SV (*Điều 8.a.1; Điều 8.b.2*);
- Nhập danh sách SV tham gia hoạt động phong trào do Đoàn Trường chịu trách nhiệm tổ chức (*Điều 7.b.1; Điều 8.c.1*);
- Nhập danh sách SV hiến máu tình nguyện (*Điều 7.b.1*);
- Nhập danh sách SV được khen thưởng về phong trào của hệ thống Đoàn, Hội SV (*Điều 6.c.1*);
- Nhập danh sách SV là lực lượng nòng cốt của các phong trào cấp Trường (*Điều 6.b.1*);
- Nhập danh sách SV tham gia các cuộc thi Olympic chuyên ngành do Đoàn Trường phục trách (*Điều 4.b.3*);
- Đánh giá điểm (*định tính*) các nội dung: giữ gìn an ninh, trật tự công cộng, Giữ gìn vệ sinh, bảo vệ cảnh quan môi trường, nếp sống văn minh (do Đoàn Trường xác nhận) (*Điều 5.b.1*).

### 4. Phòng CTSV:

- Nhập danh sách và điểm hoàn thành nhiệm vụ của Hội đồng tự quản, Đội An ninh xung kích KTX (*Điều 8.b.1*);
- Nhập danh sách SV là lực lượng nòng cốt của các phong trào trong KTX (*Điều 6.b.1*);
- Nhập danh sách SV được khen thưởng về phong trào cấp Trường và ngoài Trường (*Điều 6.c.1*);
- Duyệt bài báo khoa học SV kê khai (*Điều 4.b.1*);
- Nhập danh sách SV tham gia các cuộc thi Olympic chuyên ngành cấp Quốc gia (*Điều 4.b.3*).

### 5. Các đơn vị chức năng khác có liên quan:

- Gửi danh sách SV đề nghị khen thưởng hoặc kỷ luật về Phòng Công tác Sinh viên để tập hợp đưa dữ liệu vào hệ thống quản lý.

**Bước 3:** Sau khi kết thúc thời gian các đơn vị nhập liệu, Khoa tiến hành tổng hợp dữ liệu có liên quan để SV bắt đầu tự chấm điểm các cột điểm định tính theo quy định.

---

3

<!-- page: 3 -->

**Bước 4:** SV vào hệ thống quản lý:

- SV thực hiện tự chấm điểm các tiêu chí định tính.

**Bước 5:** CVHT vào hệ thống:

- Duyệt chứng chỉ ngoại ngữ, tin học của SV;
- Nhập danh sách SV không tham gia các hoạt động bắt buộc;
- Nhập danh sách và điểm hoàn thành nhiệm vụ của ban cán sự lớp.
- Thực hiện chấm điểm các cột điểm định tính theo quy định.
- Công bố kết quả rèn luyện cho SV

**Bước 6:** Kết thúc thời gian CVHT thực hiện đánh giá hoặc khi CVHT đã hoàn tất việc chấm điểm sẽ tiến hành công bố kết quả rèn luyện cho SV. SV xem kết quả đánh giá,và thông tin chi tiết các thành phần điểm được tổng hợp từ các đơn vị có liên quan trên tài khoản của từng cá nhân.

**Bước 7:** Trợ lý CTSV của đơn vị chịu trách nhiệm tiếp nhận các thông tin hoặc các ý kiến, kiến nghị của SV; trực tiếp giải đáp các khiếu nại của SV theo đúng thẩm quyền trong thời gian đã quy định cho phép sinh viên phản hồi.

**Bước 8:** Sau thời gian tiếp nhận thông tin, Hội đồng đánh giá ĐRL cấp Khoa tổng hợp lập danh sách có xác nhận của thủ trưởng đơn vị đề nghị với Hội đồng đánh giá ĐRL cấp Trường công nhận ĐRL cho SV.

**Bước 9:** Căn cứ kết quả từ các đơn vị đã đánh giá, Phòng CTSV trình BGH ký QĐ công nhận ĐRL cho SV.

---

4

<!-- page: 4 -->

## II. LƯU ĐỒ:

| QUY TRÌNH CÔNG TÁC ĐÁNH GIÁ ĐIỂM RÈN LUYỆN / Bước | QUY TRÌNH CÔNG TÁC ĐÁNH GIÁ ĐIỂM RÈN LUYỆN / Lưu đồ | QUY TRÌNH CÔNG TÁC ĐÁNH GIÁ ĐIỂM RÈN LUYỆN / Nội dung công việc                                                                                                                                                                                                                             | QUY TRÌNH CÔNG TÁC ĐÁNH GIÁ ĐIỂM RÈN LUYỆN / Người thực hiện | QUY TRÌNH CÔNG TÁC ĐÁNH GIÁ ĐIỂM RÈN LUYỆN / Thời gian thực hiện | QUY TRÌNH CÔNG TÁC ĐÁNH GIÁ ĐIỂM RÈN LUYỆN / Ghi chú |
| ------------------------------------------------------------- | ---------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------- | ----------------------------------------------------------------------------- | --------------------------------------------------------------- |
| 1                                                             | Thông báo thời gian triển khai đánh giá                   | - Thông báo kế hoạch đánh giá rèn luyện trực tuyến                                                                                                                                                                                                                                            | P.CSTV                                                                     | HK1: 01/10;HK2: 01/03;                                                        |                                                                 |
| 2                                                             | Đơn vị tiến hành Nhập dữ liệu                            | - Kê khai CCNN,TH,- Nhập dữ liệu hoạt động phong trà của SV;- Chấm điểm hoàn thành nhiệm vụ của BCH Đoàn, Hội SV;- Nhập danh sách SV là nồng cốt các phong trào;- Danh sách khen thưởng, kỷ luật các cấp;- Chấm điểm giữ gìn vệ sinh, an ninh trật tự của SV. | SV,p. CTSVĐoàn khoa,Đoàn trường,Đơn vị liên quan                 | Hạn cuối:HK1: 15/12;HK2: 15/05;                                             |                                                                 |
| 3                                                             | Tổng hợp dữ liệu                                             | - Tổng hợp, đồng bộ dữ liệu từ nhiều nguồn nhập vào hệ thống.                                                                                                                                                                                                                              | Đoàn khoa                                                                | HK1: từ 16/12 đến 19/12.HK2: từ 16/05 đến 19/05.                        |                                                                 |
| 4                                                             | SV tự đánh giá                                               | - Chấm điểm các tiêu chí định tính theo quy định.                                                                                                                                                                                                                                             | SV                                                                         | HK1: từ 20/12 đến 31/12.HK2: từ 20/05 đến 31/05.                        |                                                                 |
| 5                                                             | CVHT đánh giá                                                 | - Duyệt kê khai CCNN,TH;- Chấm điểm hoàn thành nhiệm vụ của BCS;- Chấm điểm các tiêu chí định tính theo quy định.                                                                                                                                                                   | CVHT                                                                       | HK1: từ 25/12 đến 05/01.HK2: từ 25/05 đến 05/06.                        |                                                                 |
| 6                                                             | Thông báo kết quả cho SV                                     | - Công bố kết quả đánh giá điểm rèn luyện                                                                                                                                                                                                                                                     | CVHT                                                                       | HK1: 06/01;HK2: 06/06.                                                        |                                                                 |
| 7                                                             | Tiếp nhận giải quyết khiếu nại của SV                     | - SV xem kết quả đánh giá, điểm chi tiết thành phần trên tài khoản cá nhân. Nếu có khiếu nại liên hệ trực tiếp văn phòng Khoa để được hướng dẫn giải quyết theo chức năng.                                                                                          | Đoàn khoa                                                                | HK1: từ 06/01 đến 15/01.HK2: từ 06/06 đến 15/06.                        |                                                                 |
| 8                                                             | Khoa lập danh sách kết quả đánh giá gửi về Trường     | Sau khi tổng hợp ý kiến phản hồi điều chỉnh kết quả, lập danh sách kết quả đánh giá luyện gửi về Trường.                                                                                                                                                                          | Đoàn khoa                                                                | HK1: 16/01;HK2: 16/06.                                                        |                                                                 |
| 9                                                             | Lập Quyết định công nhận ĐRL                              | Căn cứ kết quả của đơn vị, Phòng CTSV trình BGH ký ban hành QĐ công nhận                                                                                                                                                                                                                  | P.CSTV                                                                     | HK1: 16/01;HK2: 16/06.                                                        |                                                                 |

---

5

<!-- page: 5 -->
