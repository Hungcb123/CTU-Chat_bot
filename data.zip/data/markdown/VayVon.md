# Hướng dẫn — Quy trình vay vốn học sinh, sinh viên theo Quyết định 157/2007/QĐ-TTg — Có cập nhật mức vay năm 2022

NGÂN HÀNG CHÍNH SÁCH XÃ HỘI
Hà Nội, ngày 02 tháng 10 năm 2007


## Thực hiện cho vay đối với học sinh, sinh viên theo Quyết định số 157/2007/QĐ-TTg ngày 27/9/2007 của Thủ tướng Chính phủ

Căn cứ Quyết định số 157/2007/QĐ-TTg ngày 27/9/2007 của Thủ tướng Chính phủ về tín dụng đối với học sinh, sinh viên, Tổng giám đốc Ngân hàng Chính sách xã hội (NHCSXH) hướng dẫn thủ tục và quy trình nghiệp vụ cho vay như sau:

## I. Một số nội dung được hiểu và thực hiện thống nhất trong văn bản hướng dẫn:

### 1. Người vay vốn tại NHCSXH:
- Chủ hộ là người đại diện cho hộ gia đình trực tiếp vay vốn và có trách nhiệm trả nợ NHCSXH, là cha hoặc mẹ hoặc người đại diện cho gia đình nhưng đã thành niên (đủ 18 tuổi) được Uỷ ban nhân dân (UBND) cấp xã sở tại xác nhận.
- Học sinh, sinh viên mồ côi cả cha lẫn mẹ hoặc chỉ mồ côi cha hoặc mẹ nhưng người còn lại không có khả năng lao động được trực tiếp vay vốn tại NHCSXH nơi nhà trường đóng trụ sở.

### 2. Nơi cư trú hợp pháp của người vay vốn là nơi người đó thường xuyên sinh sống. Trường hợp không xác định được nơi cư trú của người vay vốn theo quy định thì nơi cư trú là nơi người đó đang sinh sống được UBND cấp xã xác nhận.

### 3. Thời hạn cho vay:
**3.1. Thời hạn cho vay:** Là khoảng thời gian được tính từ ngày người vay nhận món vay đầu tiên cho đến ngày trả hết nợ gốc và lãi được thoả thuận trong Khế ước nhận nợ.
Thời hạn cho vay bao gồm thời hạn phát tiền vay và thời hạn trả nợ.
a. Thời hạn phát tiền vay: Là khoảng thời gian tính từ ngày người vay nhận món vay đầu tiên cho đến ngày học sinh, sinh viên (sau đây viết tắt là HSSV) kết thúc khoá học, kể cả thời gian HSSV được nhà trường cho phép nghỉ học có thời hạn và được bảo lưu kết quả học tập (nếu có).
Trong thời hạn phát tiền vay, người vay chưa phải trả nợ gốc và lãi tiền vay; lãi tiền vay được tính kể từ ngày người vay nhận món vay đầu tiên đến ngày trả hết nợ gốc.
b. Thời hạn trả nợ: Là khoảng thời gian được tính từ ngày người vay trả món nợ đầu tiên đến ngày trả hết nợ gốc và lãi. Người vay và ngân hàng thoả thuận thời hạn trả nợ cụ thể nhưng không vượt quá thời hạn trả nợ tối đa được quy định cụ thể như sau:
- Đối với các chương trình đào tạo có thời gian đào tạo đến một năm, thời gian trả nợ tối đa bằng 2 lần thời hạn phát tiền vay.
- Đối với các chương trình đào tạo trên một năm, thời gian trả nợ tối đa bằng thời hạn phát tiền vay.

**3.2.** Trường hợp một hộ gia đình vay vốn cho nhiều HSSV cùng một lúc, nhưng thời hạn ra trường của từng HSSV khác nhau, thì thời hạn cho vay được xác định theo HSSV có thời gian còn phải theo học tại trường dài nhất.

### 4. Mức vốn cho vay:

**4.1. Mức vay hiện hành:** Mức 800.000 đồng/tháng trong hướng dẫn nghiệp vụ năm 2007 là mức lịch sử và không còn dùng làm mức vay hiện hành. Theo Quyết định 05/2022/QĐ-TTg, mức vay vốn tối đa hiện hành là **4.000.000 đồng/tháng/học sinh, sinh viên**, áp dụng đối với các khoản giải ngân mới kể từ ngày 19/05/2022.

4.2. Đối với HSSV đang trực tiếp thực hiện Hợp đồng vay vốn với Ngân hàng nơi trường đóng trụ sở hoặc đã vay thông qua hộ gia đình theo các cơ chế cho vay trước đây và đang trong quá trình giải ngân dở dang, thì kể từ ngày 01/10/2007 được áp dụng theo mức cho vay mới và lãi suất mới.

### 5. Lãi suất cho vay:

a. Các khoản cho vay từ 01/10/2007 trở đi được áp dụng lãi suất cho vay 0,5%/tháng.

b. Các khoản cho vay từ 30/9/2007 trở về trước còn dư nợ đến ngày 30/9/2007 vẫn được áp dụng lãi suất cho vay đã ghi trên Hợp đồng tín dụng hoặc Sổ Tiết kiệm và vay vốn hoặc Khế ước nhận nợ (sau đây gọi chung là Khế ước nhận nợ) cho đến khi thu hồi hết nợ.

c. Lãi suất nợ quá hạn được tính bằng 130% lãi suất khi cho vay.

### 6. Phương thức cho vay: NHCSXH áp dụng theo 2 phương thức cho vay:

6.1. HSSV vay vốn thông qua hộ gia đình:

- Đại diện hộ gia đình là người trực tiếp vay vốn và có trách nhiệm trả nợ NHCSXH.

- Người vay không phải thế chấp tài sản nhưng phải gia nhập và là thành viên Tổ Tiết kiệm và vay vốn (TK&VV) tại thôn, ấp, bản, buôn (gọi chung là thôn) nơi hộ gia đình đang sinh sống, được Tổ bình xét đủ điều kiện vay vốn, lập thành danh sách đề nghị vay vốn NHCSXH gửi UBND cấp xã xác nhận.

- Việc cho vay của NHCSXH được thực hiện uỷ thác từng phần qua các tổ chức chính trị - xã hội theo cơ chế hiện hành của NHCSXH.

6.2. Đối với HSSV mồ côi cả cha lẫn mẹ hoặc chỉ mồ côi cha hoặc mẹ nhưng người còn lại không có khả năng lao động được vay vốn và trả nợ trực tiếp tại NHCSXH nơi địa bàn nhà trường đóng trụ sở.

### 7. NHCSXH không cho vay những HSSV bị các cơ quan xử phạt hành chính trở lên về các hành vi: cờ bạc, nghiện hút, trộm cắp, buôn lậu.

**II. Thủ tục và quy trình nghiệp vụ cho vay:**

### 1. Đối với hộ gia đình:

1.1. Hồ sơ cho vay:

- Giấy đề nghị vay vốn kiêm Khế ước nhận nợ (mẫu số 01/TD) kèm Giấy xác nhận của nhà trường (bản chính) hoặc Giấy báo nhập học (bản chính hoặc bản photo có công chứng).

- Danh sách hộ gia đình có HSSV đề nghị vay vốn NHCSXH (mẫu số 03/TD).

- Biên bản họp Tổ TK&VV (mẫu số 10/TD).

- Thông báo kết quả phê duyệt cho vay (mẫu số 04/TD)

1.2. Quy trình cho vay:

a. Người vay viết Giấy đề nghị vay vốn (mẫu số 01/TD) kèm Giấy xác nhận của nhà trường hoặc Giấy báo nhập học gửi cho Tổ TK&VV.

b. Tổ TK&VV nhận được hồ sơ xin vay của người vay, tiến hành họp Tổ để bình xét cho vay, kiểm tra các yếu tố trên Giấy đề nghị vay vốn, đối chiếu với đối tượng xin vay đúng với chính sách vay vốn của Chính phủ. Trường hợp người vay

chưa là thành viên của Tổ TK&VV thì Tổ TK&VV tại thôn đang hoạt động hiện nay tổ chức kết nạp thành viên bổ sung hoặc thành lập Tổ mới nếu đủ điều kiện. Nếu chỉ có từ 1 đến 4 người vay mới thì kết nạp bổ sung vào Tổ cũ kể cả Tổ đã có 50 thành viên. Sau đó lập Danh sách hộ gia đình đề nghị vay vốn NHCSXH (mẫu số 03/TD) kèm Giấy đề nghị vay vốn, Giấy xác nhận của nhà trường hoặc Giấy báo nhập học trình UBND cấp xã xác nhận.

c. Sau khi có xác nhận của UBND cấp xã, Tổ TK&VV gửi toàn bộ hồ sơ đề nghị vay vốn cho NHCSXH để làm thủ tục phê duyệt cho vay.

d. NHCSXH nhận được hồ sơ do Tổ TK&VV gửi đến, cán bộ NHCSXH được Giám đốc phân công thực hiện việc kiểm tra, đối chiếu tính hợp pháp, hợp lệ của bộ hồ sơ vay vốn, trình Trưởng phòng tín dụng (Tổ trưởng Tổ tín dụng) và Giám đốc phê duyệt cho vay. Sau khi phê duyệt, NHCSXH lập thông báo kết quả phê duyệt cho vay (mẫu số 04/TD) gửi UBND cấp xã.

đ. UBND cấp xã thông báo cho tổ chức chính trị - xã hội cấp xã (đơn vị nhận uỷ thác cho vay) và Tổ TK&VV để thông báo cho người vay đến điểm giao dịch tại xã hoặc trụ sở NHCSXH nơi cho vay để nhận tiền vay.

### 2. Đối với HSSV mồ côi vay trực tiếp tại NHCSXH:

2.1. Hồ sơ cho vay: Giấy đề nghị vay vốn kiêm khế ước nhận nợ (mẫu số 01/TD) kèm Giấy xác nhận của nhà trường (bản chính) hoặc Giấy báo nhập học (bản chính hoặc bản photo có công chứng).

2.2. Quy trình cho vay:

a. Người vay viết Giấy đề nghị vay vốn (mẫu số 01/TD) có xác nhận của nhà trường đang theo học tại trường và là HSSV mồ côi có hoàn cảnh khó khăn gửi NHCSXH nơi nhà trường đóng trụ sở.

b. Nhận được hồ sơ xin vay, NHCSXH xem xét cho vay, thu hồi nợ (gốc, lãi) và thực hiện các nội dung khác theo quy định tại văn bản này.

### 3. Đối với HSSV và hộ gia đình đã được vay vốn nhưng đang theo học và đang thực hiện các Khế ước nhận nợ dở dang, nếu có nhu cầu xin vay theo mức cho vay mới, thì kể từ ngày 01/10/2007 được điều chỉnh theo mức cho vay mới và lãi suất mới theo Quyết định số 157/2007/QĐ-TTg của Thủ tướng Chính phủ:

3.1. Hồ sơ cho vay: Người vay tiếp tục sử dụng hồ sơ cho vay cũ đã nhận nợ trước đây để tiếp tục nhận nợ vay theo mức mới ở NHCSXH nơi đã cho vay.

3.2. Quy trình cho vay:

a. Đối với cho vay thông qua hộ gia đình: Người vay mang Khế ước nhận nợ đã ký trước đây gửi Tổ TK&VV và nêu đề nghị nhu cầu điều chỉnh mức vay theo mức cho vay mới. Tổ TK&VV tập hợp Khế ước nhận nợ của các thành viên trong Tổ và gửi NHCSXH.

b. Đối với cho vay trực tiếp HSSV: Người vay mang Khế ước nhận nợ đã ký trước đây đến NHCSXH.

c. Sau khi nhận được Khế ước nhận nợ (liên lưu người vay), Giám đốc NHCSXH nơi cho vay thực hiện việc điều chỉnh mức cho vay mới hàng tháng và lãi suất cho vay mới theo quy định tại văn bản này vào Khế ước nhận nợ cả liên lưu NHCSXH và liên lưu người vay (Phương pháp ghi chép trên Khế ước nhận nợ được thực hiện theo phụ lục hướng dẫn đính kèm).

d. NHCSXH thực hiện việc giải ngân, thu hồi nợ theo quy định tại văn bản này.

### 4. Tổ chức giải ngân:

4.1. Việc giải ngân của NHCSXH được thực hiện một năm 2 lần vào các kỳ học.

- Số tiền giải ngân từng lần căn cứ vào mức cho vay tháng và số tháng của từng học kỳ.
- Giấy xác nhận của nhà trường hoặc Giấy báo nhập học được sử dụng làm căn cứ giải ngân cho 2 lần của năm học đó. Để giải ngân cho năm học tiếp theo phải có Giấy xác nhận mới của nhà trường.

4.2. Đến kỳ giải ngân, người vay mang Chứng minh nhân dân, Khế ước nhận nợ đến điểm giao dịch quy định của NHCSXH để nhận tiền vay. Trường hợp, người vay không trực tiếp đến nhận tiền vay được uỷ quyền cho thành viên trong hộ lĩnh tiền nhưng phải có giấy uỷ quyền có xác nhận của UBND cấp xã. Mỗi lần giải ngân, cán bộ Ngân hàng ghi đầy đủ nội dung và yêu cầu người vay ký xác nhận tiền vay theo quy định.

4.3. NHCSXH có thể giải ngân bằng tiền mặt hoặc chuyển khoản cho người vay theo phương thức NHCSXH nơi cho vay chuyển tiền cho HSSV nhận tiền mặt tại trụ sở NHCSXH nơi gần trường học của HSSV hoặc chuyển khoản cho HSSV đóng học phí cho nhà trường theo đề nghị của người vay.

### 5. Định kỳ hạn trả nợ, thu nợ, thu lãi tiền vay:

5.1. Định kỳ hạn trả nợ:

a. Khi giải ngân số tiền cho vay của kỳ học cuối cùng, NHCSXH nơi cho vay cùng người vay thoả thuận việc định kỳ hạn trả nợ của toàn bộ số tiền cho vay. Người vay phải trả nợ gốc và lãi tiền vay lần đầu tiên khi HSSV có việc làm, có thu nhập nhưng không quá 12 tháng kể từ ngày HSSV kết thúc khoá học. Số tiền cho vay được phân kỳ trả nợ tối đa 6 tháng 1 lần, phù hợp với khả năng trả nợ của người vay do Ngân hàng và người vay thoả thuận ghi vào Khế ước nhận nợ.

b. Trường hợp người vay vốn cho nhiều HSSV cùng một lúc, nhưng thời hạn ra trường của từng HSSV khác nhau, thì việc định kỳ hạn trả nợ được thực hiện khi giải ngân số tiền cho vay kỳ học cuối của HSSV ra trường sau cùng.

5.2. Thu nợ gốc:

a. Việc thu nợ gốc được thực hiện theo phân kỳ trả nợ đã thoả thuận trong Khế ước nhận nợ.

b. Trường hợp người vay có khó khăn chưa trả được nợ gốc theo đúng kỳ hạn trả nợ thì được theo dõi vào kỳ hạn trả nợ tiếp theo.

5.3. Thu lãi tiền vay:

a. Lãi tiền vay được tính kể từ ngày người vay nhận món vay đầu tiên đến ngày trả hết nợ gốc. NHCSXH thoả thuận với người vay trả lãi theo định kỳ tháng hoặc quý trong thời hạn trả nợ. Trường hợp, người vay có nhu cầu trả lãi theo định kỳ hàng tháng, quý trong thời hạn phát tiền vay thì NHCSXH thực hiện thu theo yêu cầu của người vay kể cả các khoản nợ cho HSSV vay trước đây theo văn bản số 2162/NHCS-KH ngày 19/9/2006.

b. Nhà nước có chính sách giảm lãi suất đối với trường hợp người vay trả nợ trước hạn. Hướng dẫn cụ thể về giảm lãi để khuyến khích trả nợ trước hạn được thực hiện theo văn bản riêng của NHCSXH.

c. Đối với các khoản nợ quá hạn, thu nợ gốc đến đâu thì thu lãi đến đó; trường hợp người vay thực sự khó khăn có thể ưu tiên thu gốc trước, thu lãi sau.

### 6. Gia hạn nợ:

- Đến thời điểm trả nợ cuối cùng, nếu người vay có khó khăn khách quan chưa trả được nợ thì được NHCSXH xem xét cho gia hạn nợ.

- Thủ tục gia hạn nợ: Người vay viết Giấy đề nghị gia hạn nợ (theo mẫu số 09/TD) gửi NHCSXH nơi cho vay xem xét cho gia hạn nợ.

- Thời gian cho gia hạn nợ: tuỳ từng trường hợp cụ thể, ngân hàng có thể gia hạn nợ một hoặc nhiều lần cho một khoản vay, nhưng thời gian gia hạn nợ tối đa bằng 1/2 thời hạn trả nợ.

### 7. Chuyển nợ quá hạn:
Trường hợp, người vay không trả nợ đúng hạn theo kỳ hạn trả nợ cuối cùng và không được NHCSXH cho gia hạn nợ thì chuyển toàn bộ số dư nợ sang nợ quá hạn.

Sau khi chuyển nợ quá hạn, ngân hàng nơi cho vay phối hợp với chính quyền sở tại, các tổ chức chính trị xã hội, Tổ TK&VV và tổ chức, cá nhân sử dụng lao động là HSSV đã được vay vốn để thu hồi nợ. Trường hợp, người vay có khả năng trả nợ nhưng không trả thì xem xét chuyển hồ sơ sang cơ quan pháp luật để xử lý thu hồi vốn theo quy định của pháp luật.

### 8. Kiểm tra vốn vay:
#### 8.1. Đối với hộ gia đình:
**a. Tổ TK&VV:**
- Tổ TK&VV có nhiệm vụ kiểm tra điều kiện vay vốn của người vay khi nhận hồ sơ vay vốn từ người vay để xác định đúng đối tượng được vay.
- Thường xuyên làm nhiệm vụ kiểm tra, giám sát đôn đốc người vay trong Tổ TK&VV sử dụng vốn vay đúng mục đích, trả nợ, trả lãi đúng kỳ hạn cam kết; chứng kiến và giám sát các buổi giải ngân cho vay, thu nợ, thu lãi.
- Cùng với các tổ chức chính trị - xã hội bàn bạc thống nhất ý kiến đề xuất xử lý các khoản nợ bị rủi ro trình UBND cấp xã xác nhận.

**b. Tổ chức chính trị - xã hội cấp xã:**
- Chỉ đạo và tham gia cùng Tổ TK&VV tổ chức họp Tổ để bình xét công khai người vay có nhu cầu xin vay vốn và đủ điều kiện vay đưa vào danh sách hộ gia đình đề nghị vay vốn NHCSXH (mẫu số 03/TD).
- Kiểm tra, giám sát quá trình sử dụng vốn vay của người vay theo hình thức đối chiếu công khai (mẫu số 06/TD) và thông báo kịp thời cho Ngân hàng nơi cho vay về các trường hợp sử dụng vốn vay sai mục đích, vay ké, bỏ trốn, chết, mất tích, bị rủi ro do nguyên nhân khách quan (thiên tai, dịch bệnh, hoả hoạn…) để có biện pháp xử lý kịp thời. Kết hợp với Tổ TK&VV và chính quyền địa phương xử lý các trường hợp nợ chây ỳ, nợ quá hạn và hướng dẫn người vay lập hồ sơ đề nghị xử lý nợ rủi ro do nguyên nhân khách quan (nếu có).
- Chỉ đạo và giám sát Ban quản lý Tổ TK&VV trong việc thực hiện Hợp đồng uỷ nhiệm đã ký với NHCSXH.

**c. NHCSXH:**
- Thực hiện kiểm tra đối chiếu Danh sách đề nghị vay vốn NHCSXH (mẫu số 03/TD) với Danh sách thành viên Tổ TK&VV (mẫu số 10/TD). Kiểm tra tính pháp lý của bộ hồ sơ xin vay theo quy định.
- Định kỳ hoặc đột xuất, lãnh đạo NHCSXH mời các thành viên trong Ban đại diện HĐQT NHCSXH cùng cấp thực hiện chương trình kiểm tra, giám sát hoạt động của Tổ TK&VV, của người vay và của tổ chức Hội cấp dưới trong việc chấp hành chính sách tín dụng và hiệu quả sử dụng vốn vay của người vay.
- Chủ động tổ chức giao ban định kỳ tại các Điểm giao dịch tại xã để trao đổi về kết quả uỷ thác, tồn tại, vướng mắc, bàn giải pháp và kiến nghị xử lý nợ đến hạn, nợ quá hạn, nợ bị rủi ro, nợ bị xâm tiêu (nếu có)…

#### 8.2. Đối với HSSV vay tại NHCSXH nơi trường đóng trụ sở:
NHCSXH nơi cho vay kiểm tra tính hợp lệ, hợp pháp của bộ hồ sơ xin vay và kiểm tra thực tế việc sử dụng vốn vay (mẫu số 06/TD).

### 9. Lưu trữ hồ sơ vay vốn:
Toàn bộ hồ sơ cho vay được lưu giữ tại bộ phận kế toán NHCSXH nơi cho vay.

**III. Tổ chức thực hiện:**
### 1. Công tác kế hoạch: Hàng năm, Ngân hàng cơ sở lập kế hoạch nhu cầu vốn cho vay đối với HSSV có hoàn cảnh khó khăn gửi ngân hàng cấp trên trực tiếp theo các quy định hiện hành của NHCSXH.
### 2. Hạch toán kế toán: Dư nợ cho vay HSSV theo văn bản này được hạch toán vào tài khoản thích hợp trong hệ thống tài khoản kế toán do Tổng giám đốc NHCSXH ban hành.
### 3. Chế độ báo cáo thống kê:
Ngày 7 hàng tháng, chi nhánh NHCSXH cấp tỉnh lập và gửi báo cáo kết quả cho vay HSSV có hoàn cảnh khó khăn theo mẫu biểu số 02.2A/BCTD theo văn bản hướng dẫn cập nhật chương trình thông tin báo cáo tín dụng hiện hành.
### 4. Đối với những người vay Ngân hàng đã kết thúc việc giải ngân trước ngày 01/10/2007, thì việc quản lý và thu hồi nợ được thực hiện theo Khế ước nhận nợ đã ký.
### 5. Văn bản này có hiệu lực kể từ ngày ký và thay thế văn bản số 2162/NHCS-TD ngày 19/9/2006 của Tổng giám đốc NHCSXH về việc hướng dẫn nghiệp vụ cho vay đối với HSSV có hoàn cảnh khó khăn. Việc sửa đổi, bổ sung nội dung văn bản này do Tổng giám đốc NHCSXH quyết định.
